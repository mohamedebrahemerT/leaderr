-- MySQL dump 10.19  Distrib 10.3.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: mohamedebrahem_pos
-- ------------------------------------------------------
-- Server version	10.3.32-MariaDB-log-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `initial_balance` double DEFAULT NULL,
  `total_balance` double NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` (`id`, `account_no`, `name`, `initial_balance`, `total_balance`, `note`, `is_default`, `is_active`, `created_at`, `updated_at`) VALUES (1,'11111','Sales Account',500000,500000,'رصيد افتاححي',1,1,'2018-12-18 02:58:02','2021-11-28 08:47:21');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adjustments`
--

DROP TABLE IF EXISTS `adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adjustments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_qty` double NOT NULL,
  `item` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adjustments`
--

LOCK TABLES `adjustments` WRITE;
/*!40000 ALTER TABLE `adjustments` DISABLE KEYS */;
/*!40000 ALTER TABLE `adjustments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendances`
--

DROP TABLE IF EXISTS `attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `employee_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `checkin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checkout` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendances`
--

LOCK TABLES `attendances` WRITE;
/*!40000 ALTER TABLE `attendances` DISABLE KEYS */;
INSERT INTO `attendances` (`id`, `date`, `employee_id`, `user_id`, `checkin`, `checkout`, `status`, `note`, `created_at`, `updated_at`) VALUES (7,'2023-04-27',1,1,'10:00am','6:00pm',1,NULL,'2023-04-26 23:19:16','2023-04-26 23:19:16'),(8,'2023-04-28',6,1,'10:00am','6:00pm',1,NULL,'2023-04-28 12:42:49','2023-04-28 12:42:49');
/*!40000 ALTER TABLE `attendances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billers`
--

DROP TABLE IF EXISTS `billers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vat_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billers`
--

LOCK TABLES `billers` WRITE;
/*!40000 ALTER TABLE `billers` DISABLE KEYS */;
INSERT INTO `billers` (`id`, `name`, `image`, `company_name`, `vat_number`, `email`, `phone_number`, `address`, `city`, `state`, `postal_code`, `country`, `is_active`, `created_at`, `updated_at`) VALUES (1,'القائد','.jpg','شركة القائد','%0','info@top-gift.com','01008532687','توب جفت','القائد',NULL,NULL,'مصر',1,'2018-05-12 21:49:30','2023-03-19 10:54:37'),(2,'tariq',NULL,'big tree',NULL,'tariq@bigtree.com','321312','khulshi','chittagong',NULL,NULL,NULL,1,'2018-05-12 21:57:54','2021-08-15 07:48:14'),(3,'test',NULL,'test',NULL,'test@test.com','3211','erewrwqre','afsf',NULL,NULL,NULL,1,'2018-05-30 02:38:58','2018-05-30 02:39:57'),(5,'modon','mogaTel.jpg','mogaTel','','modon@gmail.com','32321','nasirabad','chittagong','','','bd',0,'2018-09-01 03:59:54','2022-01-26 10:57:46'),(6,'a',NULL,'a',NULL,'a@a.com','q','q','q',NULL,NULL,NULL,1,'2018-10-07 02:33:39','2018-10-07 02:34:18'),(7,'a',NULL,'a',NULL,'a@a.com','a','a','a',NULL,NULL,NULL,1,'2018-10-07 02:34:36','2018-10-07 02:36:07'),(8,'x','x.png','x',NULL,'x@x.com','x','x','x',NULL,NULL,NULL,1,'2019-03-18 11:02:42','2021-08-15 07:48:14');
/*!40000 ALTER TABLE `billers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` (`id`, `title`, `image`, `is_active`, `created_at`, `updated_at`) VALUES (3,'HP','HP.jpg',0,'2018-05-12 09:06:14','2023-04-30 09:27:00'),(4,'samsung','samsung.jpg',0,'2018-05-12 09:08:41','2023-04-30 09:27:09'),(5,'Apple','Apple.jpg',0,'2018-08-31 23:34:49','2023-04-30 09:27:16'),(6,'jjjj','20201019093419.jpg',0,'2020-10-19 15:33:52','2020-10-19 15:35:58'),(7,'Lotto',NULL,1,'2020-11-16 04:13:41','2020-11-16 04:13:41'),(8,'مستورد',NULL,1,'2021-08-15 08:36:12','2021-08-15 08:36:12'),(9,'standard',NULL,1,'2021-08-17 20:05:43','2021-08-17 20:05:43'),(10,'food',NULL,1,'2021-08-17 20:15:39','2021-08-17 20:15:39'),(11,'dwt',NULL,1,'2023-04-30 08:33:08','2023-04-30 08:33:08'),(12,'apk',NULL,1,'2023-04-30 08:33:39','2023-04-30 08:33:39'),(13,'apt',NULL,1,'2023-04-30 08:33:48','2023-04-30 08:33:48'),(14,'kwg',NULL,1,'2023-04-30 08:34:06','2023-04-30 08:34:06'),(15,'DCA صينى',NULL,1,'2023-04-30 08:37:05','2023-04-30 08:37:05'),(16,'BEST TOOLS  صينى',NULL,1,'2023-04-30 09:30:15','2023-04-30 09:30:15'),(17,'ماليزى',NULL,1,'2023-04-30 09:30:54','2023-04-30 09:30:54'),(18,'ايطالى',NULL,1,'2023-04-30 09:31:07','2023-04-30 09:31:07'),(19,'المانى',NULL,1,'2023-04-30 09:31:16','2023-04-30 09:31:16'),(20,'فرنساوى',NULL,1,'2023-04-30 09:31:27','2023-04-30 09:31:27'),(21,'مصرى',NULL,1,'2023-04-30 09:31:48','2023-04-30 09:31:48'),(22,'اماراتى',NULL,1,'2023-04-30 09:31:59','2023-04-30 09:31:59'),(23,'هندى',NULL,1,'2023-04-30 09:32:08','2023-04-30 09:32:08'),(24,'كورى',NULL,1,'2023-04-30 09:32:46','2023-04-30 09:32:46'),(25,'امريكى',NULL,1,'2023-04-30 09:33:00','2023-04-30 09:33:00'),(26,'robtek',NULL,1,'2023-04-30 09:34:27','2023-04-30 09:34:27'),(27,'keen',NULL,1,'2023-04-30 09:34:55','2023-04-30 09:34:55'),(28,'كيداس',NULL,1,'2023-04-30 09:35:21','2023-04-30 09:35:21'),(29,'الباز',NULL,1,'2023-04-30 10:43:16','2023-04-30 10:43:16'),(30,'صينى',NULL,1,'2023-04-30 10:43:45','2023-04-30 10:43:45'),(31,'ايثاب',NULL,1,'2023-04-30 10:44:01','2023-04-30 10:44:01'),(32,'ALBEN',NULL,1,'2023-04-30 10:57:15','2023-04-30 10:57:15'),(33,'TNT',NULL,1,'2023-04-30 11:10:35','2023-04-30 11:10:35'),(34,'BAKSTANE',NULL,1,'2023-04-30 11:30:24','2023-04-30 11:30:24'),(35,'روسى',NULL,1,'2023-04-30 11:44:15','2023-04-30 11:44:15'),(36,'تركى',NULL,1,'2023-04-30 12:37:05','2023-04-30 12:37:05'),(37,'جاترو فلاكس',NULL,1,'2023-04-30 12:47:28','2023-04-30 12:47:28');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_registers`
--

DROP TABLE IF EXISTS `cash_registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_registers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cash_in_hand` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_registers`
--

LOCK TABLES `cash_registers` WRITE;
/*!40000 ALTER TABLE `cash_registers` DISABLE KEYS */;
INSERT INTO `cash_registers` (`id`, `cash_in_hand`, `user_id`, `warehouse_id`, `status`, `created_at`, `updated_at`) VALUES (9,0,1,2,0,'2021-11-28 12:20:08','2023-05-02 12:00:12'),(10,0,1,1,1,'2022-10-02 18:02:43','2022-10-02 18:02:43'),(11,0,1,2,1,'2023-04-26 23:06:00','2023-04-26 23:06:00');
/*!40000 ALTER TABLE `cash_registers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `image`, `parent_id`, `is_active`, `created_at`, `updated_at`) VALUES (1,'تصنيف عام',NULL,NULL,1,'2023-03-19 10:59:52','2023-03-19 10:59:52'),(2,'صينى',NULL,4,1,'2023-04-30 06:48:52','2023-04-30 10:21:18'),(3,'مستلزمات لحام','20230430112623.jpg',NULL,1,'2023-04-30 08:26:23','2023-04-30 08:26:23'),(4,'عدد و الات',NULL,NULL,1,'2023-04-30 10:20:17','2023-04-30 10:20:17'),(5,'عدد كهربائية',NULL,NULL,1,'2023-04-30 10:22:07','2023-04-30 10:22:07'),(6,'صنفرة',NULL,NULL,1,'2023-04-30 10:22:59','2023-04-30 10:22:59'),(7,'مستلزمات هوا',NULL,NULL,1,'2023-04-30 10:23:41','2023-04-30 10:23:41'),(8,'سبريهات وسليكونات',NULL,NULL,1,'2023-04-30 10:24:04','2023-04-30 10:24:04');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `minimum_amount` double DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `used` int(11) NOT NULL,
  `expired_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchange_rate` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` (`id`, `name`, `code`, `exchange_rate`, `created_at`, `updated_at`) VALUES (1,'الجنية','الجنية',1,'2020-11-01 00:22:58','2023-04-28 12:05:47'),(2,'Euro','Euro',0.85,'2020-11-01 01:29:12','2020-11-10 23:15:34');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_groups`
--

DROP TABLE IF EXISTS `customer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_groups`
--

LOCK TABLES `customer_groups` WRITE;
/*!40000 ALTER TABLE `customer_groups` DISABLE KEYS */;
INSERT INTO `customer_groups` (`id`, `name`, `percentage`, `is_active`, `created_at`, `updated_at`) VALUES (1,'general','0',1,'2018-05-12 08:09:36','2019-03-02 06:01:35'),(2,'distributor','-10',1,'2018-05-12 08:12:14','2019-03-02 06:02:12'),(3,'reseller','5',1,'2018-05-12 08:12:26','2018-05-30 01:18:14'),(4,'test','12',0,'2018-05-30 01:17:16','2018-05-30 01:17:57'),(5,'test','0',0,'2018-08-03 09:10:27','2018-08-03 09:10:34');
/*!40000 ALTER TABLE `customer_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_group_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deposit` double DEFAULT NULL,
  `expense` double DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` (`id`, `customer_group_id`, `user_id`, `name`, `company_name`, `email`, `phone_number`, `tax_no`, `address`, `city`, `state`, `postal_code`, `country`, `deposit`, `expense`, `is_active`, `created_at`, `updated_at`) VALUES (1,1,NULL,'زبون','زبون',NULL,'06565565',NULL,'.','.',NULL,NULL,NULL,NULL,NULL,1,'2023-03-19 10:43:05','2023-03-19 10:43:05'),(2,1,NULL,'زبون 2','زبون 2','wer@sdf.com','0646565','0','0','0','0',NULL,'0',NULL,NULL,1,'2023-04-28 12:23:03','2023-04-28 12:23:03'),(3,1,NULL,'مؤسسة الجمهورية احمد دحروج','الجمهورية','aaaa@aaa','01143218446',NULL,'القاهره','القاهره',NULL,NULL,'Egypt',NULL,NULL,1,'2023-04-30 08:48:23','2023-04-30 08:48:23');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliveries`
--

DROP TABLE IF EXISTS `deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliveries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sale_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivered_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recieved_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliveries`
--

LOCK TABLES `deliveries` WRITE;
/*!40000 ALTER TABLE `deliveries` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliveries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` (`id`, `name`, `is_active`, `created_at`, `updated_at`) VALUES (1,'Sale',1,'2018-12-27 05:16:47','2018-12-27 10:40:23'),(2,'xyz',1,'2018-12-27 10:28:47','2018-12-27 10:28:47'),(3,'محاسبة',1,'2023-04-28 12:29:42','2023-04-28 12:29:42');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposits`
--

DROP TABLE IF EXISTS `deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deposits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `customer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposits`
--

LOCK TABLES `deposits` WRITE;
/*!40000 ALTER TABLE `deposits` DISABLE KEYS */;
INSERT INTO `deposits` (`id`, `amount`, `customer_id`, `user_id`, `note`, `created_at`, `updated_at`) VALUES (1,90,1,1,'first deposit','2018-08-25 22:48:23','2018-08-26 01:18:55'),(3,100,2,1,NULL,'2018-08-26 00:53:16','2018-08-26 21:42:39'),(4,50,1,1,NULL,'2018-09-04 22:56:19','2018-09-04 22:56:19'),(5,50,1,1,NULL,'2018-09-10 00:08:40','2018-09-10 00:08:40'),(6,618,53,1,NULL,'2022-01-26 10:43:34','2022-01-26 10:43:34'),(7,1000,112,1,NULL,'2022-04-23 21:41:06','2022-04-23 21:41:06');
/*!40000 ALTER TABLE `deposits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` (`id`, `name`, `email`, `phone_number`, `department_id`, `user_id`, `image`, `address`, `city`, `country`, `is_active`, `created_at`, `updated_at`) VALUES (1,'john','john@gmail.com','10001',2,12,'johngmailcom.jpg','GEC','chittagong','Bangladesh',1,'2018-12-30 00:48:37','2019-03-02 06:50:23'),(3,'tests','test@test.com','111',1,NULL,NULL,NULL,NULL,NULL,1,'2018-12-30 22:20:51','2019-01-03 00:03:54'),(6,'استاذ  احمد','ahmed@ahmed.com','565656',3,31,NULL,'3556563','2323','23',1,'2023-04-28 12:30:13','2023-04-28 12:30:13');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense_categories`
--

DROP TABLE IF EXISTS `expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense_categories`
--

LOCK TABLES `expense_categories` WRITE;
/*!40000 ALTER TABLE `expense_categories` DISABLE KEYS */;
INSERT INTO `expense_categories` (`id`, `code`, `name`, `is_active`, `created_at`, `updated_at`) VALUES (1,'23742710','مصاريف عامة',0,'2023-04-26 23:08:09','2023-04-28 12:00:54'),(2,'03508922','مصاريف عامة',0,'2023-04-28 12:27:55','2023-04-28 12:46:50'),(3,'01220637','مصاريف عامة',1,'2023-04-30 08:53:31','2023-04-30 08:53:31');
/*!40000 ALTER TABLE `expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cash_register_id` int(11) DEFAULT NULL,
  `amount` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` (`id`, `reference_no`, `expense_category_id`, `warehouse_id`, `account_id`, `user_id`, `cash_register_id`, `amount`, `note`, `created_at`, `updated_at`) VALUES (37,'er-20230430-115407',3,2,1,1,9,200,'مصاريف كهرباء','2023-04-30 08:54:07','2023-04-30 08:54:07');
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `general_settings`
--

DROP TABLE IF EXISTS `general_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `general_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `staff_access` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `developed_by` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `currency_position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `general_settings`
--

LOCK TABLES `general_settings` WRITE;
/*!40000 ALTER TABLE `general_settings` DISABLE KEYS */;
INSERT INTO `general_settings` (`id`, `site_title`, `site_logo`, `currency`, `staff_access`, `date_format`, `developed_by`, `invoice_format`, `state`, `theme`, `created_at`, `updated_at`, `currency_position`) VALUES (1,'القائد','Capture-removebg-preview.png','1','own','d/m/Y','محمد ابراهيم 01149880297','standard',1,'default.css','2018-07-06 06:13:11','2023-03-19 11:06:13','prefix');
/*!40000 ALTER TABLE `general_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_card_recharges`
--

DROP TABLE IF EXISTS `gift_card_recharges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_card_recharges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gift_card_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_card_recharges`
--

LOCK TABLES `gift_card_recharges` WRITE;
/*!40000 ALTER TABLE `gift_card_recharges` DISABLE KEYS */;
INSERT INTO `gift_card_recharges` (`id`, `gift_card_id`, `amount`, `user_id`, `created_at`, `updated_at`) VALUES (1,2,100,1,'2018-08-24 23:08:29','2018-08-24 23:08:29'),(2,1,200,1,'2018-08-24 23:08:50','2018-08-24 23:08:50'),(3,1,100,1,'2018-09-04 23:50:41','2018-09-04 23:50:41'),(4,1,50,1,'2018-09-04 23:51:38','2018-09-04 23:51:38'),(5,1,50,1,'2018-09-04 23:53:36','2018-09-04 23:53:36'),(6,2,50,1,'2018-09-04 23:54:34','2018-09-04 23:54:34'),(7,5,10,1,'2018-09-30 00:19:48','2018-09-30 00:19:48'),(8,5,10,1,'2018-09-30 00:20:04','2018-09-30 00:20:04'),(9,2,100,1,'2018-10-07 03:13:05','2018-10-07 03:13:05'),(10,1,200,1,'2018-10-07 03:13:39','2018-10-07 03:13:39'),(11,1,300,1,'2018-10-23 00:22:49','2018-10-23 00:22:49');
/*!40000 ALTER TABLE `gift_card_recharges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_cards`
--

DROP TABLE IF EXISTS `gift_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_cards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `card_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `expense` double NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `expired_date` date DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_cards`
--

LOCK TABLES `gift_cards` WRITE;
/*!40000 ALTER TABLE `gift_cards` DISABLE KEYS */;
INSERT INTO `gift_cards` (`id`, `card_no`, `amount`, `expense`, `customer_id`, `user_id`, `expired_date`, `created_by`, `is_active`, `created_at`, `updated_at`) VALUES (1,'3571097513020486',1400,50,1,NULL,'2020-12-31',1,1,'2018-08-18 01:57:40','2021-11-28 08:45:55'),(2,'0452297501931931',370,0,2,NULL,'2020-12-31',1,1,'2018-08-18 02:46:43','2021-11-28 08:45:55'),(3,'123',13123,0,1,NULL,'2018-08-19',1,0,'2018-08-18 22:38:21','2018-08-18 22:38:28'),(4,'1862381252690499',100,0,NULL,1,'2018-10-04',1,0,'2018-09-30 00:16:28','2018-09-30 00:17:21'),(5,'2300813717254199',143,0,NULL,1,'2018-10-04',1,0,'2018-09-30 00:18:49','2018-09-30 00:20:20'),(6,'8327019475026421',1,0,1,NULL,'2018-10-07',1,0,'2018-10-07 03:12:41','2018-10-07 03:12:55'),(7,'2063379780590151',1,0,1,NULL,'2018-10-23',1,0,'2018-10-23 00:23:22','2018-10-23 00:23:39');
/*!40000 ALTER TABLE `gift_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holidays` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_approved` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holidays`
--

LOCK TABLES `holidays` WRITE;
/*!40000 ALTER TABLE `holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hrm_settings`
--

DROP TABLE IF EXISTS `hrm_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hrm_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `checkin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checkout` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hrm_settings`
--

LOCK TABLES `hrm_settings` WRITE;
/*!40000 ALTER TABLE `hrm_settings` DISABLE KEYS */;
INSERT INTO `hrm_settings` (`id`, `checkin`, `checkout`, `created_at`, `updated_at`) VALUES (1,'10:00am','6:00pm','2019-01-02 02:20:08','2019-01-02 04:20:53');
/*!40000 ALTER TABLE `hrm_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` (`id`, `code`, `created_at`, `updated_at`) VALUES (1,'en','2018-07-07 22:59:17','2019-12-24 17:34:20');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_02_17_060412_create_categories_table',1),(4,'2018_02_20_035727_create_brands_table',1),(5,'2018_02_25_100635_create_suppliers_table',1),(6,'2018_02_27_101619_create_warehouse_table',1),(7,'2018_03_03_040448_create_units_table',1),(8,'2018_03_04_041317_create_taxes_table',1),(9,'2018_03_10_061915_create_customer_groups_table',1),(10,'2018_03_10_090534_create_customers_table',1),(11,'2018_03_11_095547_create_billers_table',1),(12,'2018_04_05_054401_create_products_table',1),(13,'2018_04_06_133606_create_purchases_table',1),(14,'2018_04_06_154600_create_product_purchases_table',1),(15,'2018_04_06_154915_create_product_warhouse_table',1),(16,'2018_04_10_085927_create_sales_table',1),(17,'2018_04_10_090133_create_product_sales_table',1),(18,'2018_04_10_090254_create_payments_table',1),(19,'2018_04_10_090341_create_payment_with_cheque_table',1),(20,'2018_04_10_090509_create_payment_with_credit_card_table',1),(21,'2018_04_13_121436_create_quotation_table',1),(22,'2018_04_13_122324_create_product_quotation_table',1),(23,'2018_04_14_121802_create_transfers_table',1),(24,'2018_04_14_121913_create_product_transfer_table',1),(25,'2018_05_13_082847_add_payment_id_and_change_sale_id_to_payments_table',2),(26,'2018_05_13_090906_change_customer_id_to_payment_with_credit_card_table',3),(27,'2018_05_20_054532_create_adjustments_table',4),(28,'2018_05_20_054859_create_product_adjustments_table',4),(29,'2018_05_21_163419_create_returns_table',5),(30,'2018_05_21_163443_create_product_returns_table',5),(31,'2018_06_02_050905_create_roles_table',6),(32,'2018_06_02_073430_add_columns_to_users_table',7),(33,'2018_06_03_053738_create_permission_tables',8),(36,'2018_06_21_063736_create_pos_setting_table',9),(37,'2018_06_21_094155_add_user_id_to_sales_table',10),(38,'2018_06_21_101529_add_user_id_to_purchases_table',11),(39,'2018_06_21_103512_add_user_id_to_transfers_table',12),(40,'2018_06_23_061058_add_user_id_to_quotations_table',13),(41,'2018_06_23_082427_add_is_deleted_to_users_table',14),(42,'2018_06_25_043308_change_email_to_users_table',15),(43,'2018_07_06_115449_create_general_settings_table',16),(44,'2018_07_08_043944_create_languages_table',17),(45,'2018_07_11_102144_add_user_id_to_returns_table',18),(46,'2018_07_11_102334_add_user_id_to_payments_table',18),(47,'2018_07_22_130541_add_digital_to_products_table',19),(49,'2018_07_24_154250_create_deliveries_table',20),(50,'2018_08_16_053336_create_expense_categories_table',21),(51,'2018_08_17_115415_create_expenses_table',22),(55,'2018_08_18_050418_create_gift_cards_table',23),(56,'2018_08_19_063119_create_payment_with_gift_card_table',24),(57,'2018_08_25_042333_create_gift_card_recharges_table',25),(58,'2018_08_25_101354_add_deposit_expense_to_customers_table',26),(59,'2018_08_26_043801_create_deposits_table',27),(60,'2018_09_02_044042_add_keybord_active_to_pos_setting_table',28),(61,'2018_09_09_092713_create_payment_with_paypal_table',29),(62,'2018_09_10_051254_add_currency_to_general_settings_table',30),(63,'2018_10_22_084118_add_biller_and_store_id_to_users_table',31),(65,'2018_10_26_034927_create_coupons_table',32),(66,'2018_10_27_090857_add_coupon_to_sales_table',33),(67,'2018_11_07_070155_add_currency_position_to_general_settings_table',34),(68,'2018_11_19_094650_add_combo_to_products_table',35),(69,'2018_12_09_043712_create_accounts_table',36),(70,'2018_12_17_112253_add_is_default_to_accounts_table',37),(71,'2018_12_19_103941_add_account_id_to_payments_table',38),(72,'2018_12_20_065900_add_account_id_to_expenses_table',39),(73,'2018_12_20_082753_add_account_id_to_returns_table',40),(74,'2018_12_26_064330_create_return_purchases_table',41),(75,'2018_12_26_144210_create_purchase_product_return_table',42),(76,'2018_12_26_144708_create_purchase_product_return_table',43),(77,'2018_12_27_110018_create_departments_table',44),(78,'2018_12_30_054844_create_employees_table',45),(79,'2018_12_31_125210_create_payrolls_table',46),(80,'2018_12_31_150446_add_department_id_to_employees_table',47),(81,'2019_01_01_062708_add_user_id_to_expenses_table',48),(82,'2019_01_02_075644_create_hrm_settings_table',49),(83,'2019_01_02_090334_create_attendances_table',50),(84,'2019_01_27_160956_add_three_columns_to_general_settings_table',51),(85,'2019_02_15_183303_create_stock_counts_table',52),(86,'2019_02_17_101604_add_is_adjusted_to_stock_counts_table',53),(87,'2019_04_13_101707_add_tax_no_to_customers_table',54),(89,'2019_10_14_111455_create_holidays_table',55),(90,'2019_11_13_145619_add_is_variant_to_products_table',56),(91,'2019_11_13_150206_create_product_variants_table',57),(92,'2019_11_13_153828_create_variants_table',57),(93,'2019_11_25_134041_add_qty_to_product_variants_table',58),(94,'2019_11_25_134922_add_variant_id_to_product_purchases_table',58),(95,'2019_11_25_145341_add_variant_id_to_product_warehouse_table',58),(96,'2019_11_29_182201_add_variant_id_to_product_sales_table',59),(97,'2019_12_04_121311_add_variant_id_to_product_quotation_table',60),(98,'2019_12_05_123802_add_variant_id_to_product_transfer_table',61),(100,'2019_12_08_114954_add_variant_id_to_product_returns_table',62),(101,'2019_12_08_203146_add_variant_id_to_purchase_product_return_table',63),(102,'2020_02_28_103340_create_money_transfers_table',64),(103,'2020_07_01_193151_add_image_to_categories_table',65),(105,'2020_09_26_130426_add_user_id_to_deliveries_table',66),(107,'2020_10_11_125457_create_cash_registers_table',67),(108,'2020_10_13_155019_add_cash_register_id_to_sales_table',68),(109,'2020_10_13_172624_add_cash_register_id_to_returns_table',69),(110,'2020_10_17_212338_add_cash_register_id_to_payments_table',70),(111,'2020_10_18_124200_add_cash_register_id_to_expenses_table',71),(112,'2020_10_21_121632_add_developed_by_to_general_settings_table',72),(113,'2019_08_19_000000_create_failed_jobs_table',73),(114,'2020_10_30_135557_create_notifications_table',73),(115,'2020_11_01_044954_create_currencies_table',74),(116,'2020_11_01_140736_add_price_to_product_warehouse_table',75),(117,'2020_11_02_050633_add_is_diff_price_to_products_table',76),(118,'2020_11_09_055222_add_user_id_to_customers_table',77),(119,'2020_11_17_054806_add_invoice_format_to_general_settings_table',78);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `money_transfers`
--

DROP TABLE IF EXISTS `money_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `money_transfers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_account_id` int(11) NOT NULL,
  `to_account_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `money_transfers`
--

LOCK TABLES `money_transfers` WRITE;
/*!40000 ALTER TABLE `money_transfers` DISABLE KEYS */;
INSERT INTO `money_transfers` (`id`, `reference_no`, `from_account_id`, `to_account_id`, `amount`, `created_at`, `updated_at`) VALUES (2,'mtr-20200228-071852',1,3,100,'2020-02-28 13:18:52','2020-02-28 13:18:52');
/*!40000 ALTER TABLE `money_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES ('249beded-5431-40a3-ba1e-d255ffb047a3','App\\Notifications\\SendNotification','App\\User',9,'{\"message\":\"Please delete all pending purchase.\"}','2020-11-01 01:33:32','2020-11-01 01:33:07','2020-11-01 01:33:32');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_with_cheque`
--

DROP TABLE IF EXISTS `payment_with_cheque`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_with_cheque` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `cheque_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_with_cheque`
--

LOCK TABLES `payment_with_cheque` WRITE;
/*!40000 ALTER TABLE `payment_with_cheque` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_with_cheque` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_with_credit_card`
--

DROP TABLE IF EXISTS `payment_with_credit_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_with_credit_card` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `customer_stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charge_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_with_credit_card`
--

LOCK TABLES `payment_with_credit_card` WRITE;
/*!40000 ALTER TABLE `payment_with_credit_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_with_credit_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_with_gift_card`
--

DROP TABLE IF EXISTS `payment_with_gift_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_with_gift_card` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `gift_card_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_with_gift_card`
--

LOCK TABLES `payment_with_gift_card` WRITE;
/*!40000 ALTER TABLE `payment_with_gift_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_with_gift_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_with_paypal`
--

DROP TABLE IF EXISTS `payment_with_paypal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_with_paypal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_with_paypal`
--

LOCK TABLES `payment_with_paypal` WRITE;
/*!40000 ALTER TABLE `payment_with_paypal` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_with_paypal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `cash_register_id` int(11) DEFAULT NULL,
  `account_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `change` double NOT NULL,
  `paying_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1314 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` (`id`, `payment_reference`, `user_id`, `purchase_id`, `sale_id`, `cash_register_id`, `account_id`, `amount`, `change`, `paying_method`, `payment_note`, `created_at`, `updated_at`) VALUES (415,'spr-20211221-101814',1,NULL,21,9,1,4400,0,'Cash',NULL,'2021-12-21 20:18:14','2021-12-21 20:18:14'),(416,'spr-20211221-105011',1,NULL,22,9,1,4464,0,'Cash',NULL,'2021-12-21 20:50:11','2021-12-21 20:50:11'),(417,'spr-20211221-110520',1,NULL,23,9,1,80,0,'Cash',NULL,'2021-12-21 21:05:20','2021-12-21 21:05:20'),(418,'spr-20211222-093757',1,NULL,24,9,1,1580,0,'Cash',NULL,'2021-12-22 07:37:57','2021-12-22 07:37:57'),(419,'spr-20211222-094501',1,NULL,25,9,1,900,0,'Cash',NULL,'2021-12-22 07:45:01','2021-12-22 07:45:01'),(420,'spr-20211222-095103',1,NULL,26,9,1,1700,100,'Cash',NULL,'2021-12-22 07:51:03','2021-12-22 07:51:03'),(421,'spr-20211222-095309',1,NULL,27,9,1,3000,0,'Cash',NULL,'2021-12-22 07:53:09','2021-12-22 07:53:09'),(422,'spr-20211222-095612',1,NULL,28,9,1,1000,0,'Cash',NULL,'2021-12-22 07:56:12','2021-12-22 07:56:12'),(423,'spr-20211222-100337',1,NULL,30,9,1,3240,0,'Cash',NULL,'2021-12-22 08:03:37','2021-12-22 08:03:37'),(424,'spr-20211222-100528',1,NULL,31,9,1,1540,0,'Cash',NULL,'2021-12-22 08:05:28','2021-12-22 08:05:28'),(425,'spr-20211222-100937',1,NULL,32,9,1,1480,0,'Cash',NULL,'2021-12-22 08:09:37','2021-12-22 08:09:37'),(426,'spr-20211222-101126',1,NULL,33,9,1,165,0,'Cash',NULL,'2021-12-22 08:11:26','2021-12-22 08:11:26'),(427,'spr-20211222-101219',1,NULL,34,9,1,360,0,'Cash',NULL,'2021-12-22 08:12:19','2021-12-22 08:12:19'),(428,'spr-20211222-101400',1,NULL,35,9,1,935,0,'Cash',NULL,'2021-12-22 08:14:00','2021-12-22 08:14:00'),(429,'spr-20211222-101618',1,NULL,36,9,1,1550,0,'Cash',NULL,'2021-12-22 08:16:18','2021-12-22 08:16:18'),(430,'spr-20211222-101856',1,NULL,37,9,1,400,0,'Cash',NULL,'2021-12-22 08:18:56','2021-12-22 08:18:56'),(431,'spr-20211222-102046',1,NULL,38,9,1,850,0,'Cash',NULL,'2021-12-22 08:20:46','2021-12-22 08:20:46'),(432,'spr-20211222-102155',1,NULL,39,9,1,1165,0,'Cash',NULL,'2021-12-22 08:21:55','2021-12-22 08:21:55'),(433,'spr-20211222-102409',1,NULL,40,9,1,3402,0,'Cash',NULL,'2021-12-22 08:24:09','2021-12-22 08:24:09'),(434,'spr-20211222-102736',1,NULL,41,9,1,1800,0,'Cash',NULL,'2021-12-22 08:27:36','2021-12-22 08:27:36'),(435,'spr-20211222-104058',1,NULL,42,9,1,1405,0,'Cash',NULL,'2021-12-22 08:40:58','2021-12-22 08:40:58'),(436,'spr-20211222-104208',1,NULL,43,9,1,765,0,'Cash',NULL,'2021-12-22 08:42:08','2021-12-22 08:42:08'),(437,'spr-20211222-104304',1,NULL,44,9,1,585,0,'Cash',NULL,'2021-12-22 08:43:04','2021-12-22 08:43:04'),(438,'spr-20211222-104403',1,NULL,45,9,1,760,0,'Cash',NULL,'2021-12-22 08:44:03','2021-12-22 08:44:03'),(439,'spr-20211222-104615',1,NULL,46,9,1,620,0,'Cash',NULL,'2021-12-22 08:46:15','2021-12-22 08:46:15'),(440,'spr-20211222-105403',1,NULL,47,9,1,720,0,'Cash',NULL,'2021-12-22 08:54:03','2021-12-22 08:54:03'),(441,'spr-20211222-105450',1,NULL,48,9,1,530,0,'Cash',NULL,'2021-12-22 08:54:50','2021-12-22 08:54:50'),(442,'spr-20211222-110256',1,NULL,49,9,1,1480,401,'Cash',NULL,'2021-12-22 09:02:56','2021-12-22 09:02:56'),(443,'spr-20211222-110411',1,NULL,50,9,1,415,0,'Cash',NULL,'2021-12-22 09:04:11','2021-12-22 09:04:11'),(444,'spr-20211222-110647',1,NULL,52,9,1,330,0,'Cash',NULL,'2021-12-22 09:06:47','2021-12-22 09:06:47'),(445,'spr-20211222-111318',1,NULL,54,9,1,2934,0,'Cash',NULL,'2021-12-22 09:13:18','2021-12-22 09:13:18'),(446,'spr-20211222-111430',1,NULL,55,9,1,1030,100,'Cash',NULL,'2021-12-22 09:14:30','2021-12-22 09:14:30'),(447,'spr-20211222-111659',1,NULL,56,9,1,630,0,'Cash',NULL,'2021-12-22 09:16:59','2021-12-22 09:16:59'),(448,'spr-20211222-111849',1,NULL,57,9,1,3177,0,'Cash',NULL,'2021-12-22 09:18:49','2021-12-22 09:18:49'),(449,'spr-20211222-112032',1,NULL,58,9,1,380,320,'Cash',NULL,'2021-12-22 09:20:32','2021-12-22 09:20:32'),(450,'spr-20211222-112537',1,NULL,59,9,1,4356,0,'Cash',NULL,'2021-12-22 09:25:37','2021-12-22 09:25:37'),(451,'spr-20211222-113019',1,NULL,60,9,1,3033,0,'Cash',NULL,'2021-12-22 09:30:19','2021-12-22 09:30:19'),(452,'spr-20211222-113317',1,NULL,61,9,1,465,0,'Cash',NULL,'2021-12-22 09:33:17','2021-12-22 09:33:17'),(453,'spr-20211222-113828',1,NULL,62,9,1,400,0,'Cash',NULL,'2021-12-22 09:38:28','2021-12-22 09:38:28'),(454,'spr-20211222-114030',1,NULL,63,9,1,345,0,'Cash',NULL,'2021-12-22 09:40:30','2021-12-22 09:40:30'),(455,'spr-20211222-114156',1,NULL,64,9,1,5679,0,'Cash',NULL,'2021-12-22 09:41:56','2021-12-22 09:41:56'),(456,'spr-20211222-114314',1,NULL,65,9,1,1025,0,'Cash',NULL,'2021-12-22 09:43:14','2021-12-22 09:43:14'),(457,'spr-20211222-114921',1,NULL,66,9,1,1466,217,'Cash',NULL,'2021-12-22 09:49:21','2021-12-22 09:49:21'),(458,'spr-20211222-122346',1,NULL,67,9,1,1220,0,'Cash',NULL,'2021-12-22 10:23:46','2021-12-22 10:23:46'),(459,'spr-20211222-122459',1,NULL,68,9,1,200,0,'Cash',NULL,'2021-12-22 10:24:59','2021-12-22 10:24:59'),(460,'spr-20211222-010535',1,NULL,69,9,1,2775,0,'Cash',NULL,'2021-12-22 11:05:35','2021-12-22 11:05:35'),(461,'spr-20211225-121116',1,NULL,70,9,1,560,0,'Cash',NULL,'2021-12-25 10:11:16','2021-12-25 10:11:16'),(462,'spr-20211225-121531',1,NULL,71,9,1,1080,0,'Cash',NULL,'2021-12-25 10:15:31','2021-12-25 10:15:31'),(463,'spr-20211225-025948',1,NULL,72,9,1,1825,0,'Cash',NULL,'2021-12-25 12:59:48','2021-12-25 12:59:48'),(464,'spr-20211226-114922',1,NULL,73,9,1,355,0,'Cash',NULL,'2021-12-26 09:49:22','2021-12-26 09:49:22'),(465,'spr-20211226-115108',1,NULL,74,9,1,370,0,'Cash',NULL,'2021-12-26 09:51:08','2021-12-26 09:51:08'),(466,'spr-20211227-110950',1,NULL,75,9,1,560,0,'Cash',NULL,'2021-12-27 09:09:50','2021-12-27 09:09:50'),(467,'spr-20211227-063629',1,NULL,76,9,1,240,0,'Cash',NULL,'2021-12-27 16:36:29','2021-12-27 16:36:29'),(468,'spr-20211227-064329',1,NULL,77,9,1,370,0,'Cash',NULL,'2021-12-27 16:43:29','2021-12-27 16:43:29'),(469,'spr-20211227-064749',1,NULL,78,9,1,1320,0,'Cash',NULL,'2021-12-27 16:47:49','2021-12-27 16:47:49'),(470,'spr-20211227-073208',1,NULL,79,9,1,325,0,'Cash',NULL,'2021-12-27 17:32:08','2021-12-27 17:32:08'),(471,'spr-20211227-073634',1,NULL,80,9,1,80,0,'Cash',NULL,'2021-12-27 17:36:34','2021-12-27 17:36:34'),(472,'spr-20211227-074939',1,NULL,81,9,1,290,0,'Cash',NULL,'2021-12-27 17:49:39','2021-12-27 17:49:39'),(473,'spr-20211227-075530',1,NULL,82,9,1,632,0,'Cash',NULL,'2021-12-27 17:55:30','2021-12-27 17:55:30'),(474,'spr-20211227-075740',1,NULL,83,9,1,65,0,'Cash',NULL,'2021-12-27 17:57:40','2021-12-27 17:57:40'),(475,'spr-20211227-075903',1,NULL,84,9,1,100,0,'Cash',NULL,'2021-12-27 17:59:03','2021-12-27 17:59:03'),(476,'spr-20211227-080046',1,NULL,85,9,1,600,0,'Cash',NULL,'2021-12-27 18:00:46','2021-12-27 18:00:46'),(477,'spr-20211227-081405',1,NULL,86,9,1,1285,0,'Cash',NULL,'2021-12-27 18:14:05','2021-12-27 18:14:05'),(478,'spr-20211227-081612',1,NULL,87,9,1,355,0,'Cash',NULL,'2021-12-27 18:16:12','2021-12-27 18:16:12'),(479,'spr-20211227-082131',1,NULL,88,9,1,1010,0,'Cash',NULL,'2021-12-27 18:21:31','2021-12-27 18:21:31'),(480,'spr-20211227-082413',1,NULL,89,9,1,1800,0,'Cash',NULL,'2021-12-27 18:24:13','2021-12-27 18:24:13'),(481,'spr-20211227-083433',1,NULL,90,9,1,984,0,'Cash',NULL,'2021-12-27 18:34:33','2021-12-27 18:34:33'),(482,'spr-20211228-013038',1,NULL,91,9,1,490,0,'Cash',NULL,'2021-12-28 11:30:38','2021-12-28 11:30:38'),(483,'spr-20211229-102229',1,NULL,92,9,1,645,0,'Cash',NULL,'2021-12-29 08:22:29','2021-12-29 08:22:29'),(484,'spr-20220101-053651',1,NULL,53,9,1,3500,172,'Cash',NULL,'2022-01-01 15:36:51','2022-01-01 15:36:51'),(485,'spr-20220101-075451',1,NULL,94,9,1,40,0,'Cash',NULL,'2022-01-01 17:54:51','2022-01-01 17:54:51'),(486,'spr-20220102-092822',1,NULL,95,9,1,690,0,'Cash',NULL,'2022-01-02 07:28:22','2022-01-02 07:28:22'),(487,'spr-20220103-125735',1,NULL,96,9,1,510,0,'Cash',NULL,'2022-01-03 10:57:35','2022-01-03 10:57:35'),(488,'spr-20220103-011405',1,NULL,97,9,1,620,0,'Cash',NULL,'2022-01-03 11:14:05','2022-01-03 11:14:05'),(489,'spr-20220104-032800',1,NULL,98,9,1,1098,0,'Cash',NULL,'2022-01-04 13:28:00','2022-01-04 13:28:00'),(490,'spr-20220104-065220',1,NULL,99,9,1,850,0,'Cash',NULL,'2022-01-04 16:52:20','2022-01-04 16:52:20'),(491,'spr-20220105-014747',1,NULL,100,9,1,255,0,'Cash',NULL,'2022-01-05 11:47:47','2022-01-05 11:47:47'),(492,'spr-20220106-093406',1,NULL,101,9,1,2952,0,'Cash',NULL,'2022-01-06 07:34:06','2022-01-06 07:34:06'),(493,'spr-20220106-065228',1,NULL,102,9,1,40,0,'Cash',NULL,'2022-01-06 16:52:28','2022-01-06 16:52:28'),(494,'spr-20220110-102948',1,NULL,103,9,1,100,0,'Cash',NULL,'2022-01-10 08:29:48','2022-01-10 08:29:48'),(495,'spr-20220110-102950',1,NULL,104,9,1,100,0,'Cash',NULL,'2022-01-10 08:29:50','2022-01-10 08:29:50'),(496,'spr-20220112-105955',1,NULL,105,9,1,1310,0,'Cash',NULL,'2022-01-12 08:59:55','2022-01-12 08:59:55'),(497,'spr-20220112-044143',1,NULL,106,9,1,100,300,'Cash',NULL,'2022-01-12 14:41:43','2022-01-12 14:41:43'),(498,'spr-20220113-013957',1,NULL,107,9,1,685,0,'Cash',NULL,'2022-01-13 11:39:57','2022-01-13 11:39:57'),(499,'spr-20220115-014127',1,NULL,108,9,1,90,0,'Cash',NULL,'2022-01-15 11:41:27','2022-01-15 11:41:27'),(500,'spr-20220118-125555',1,NULL,109,9,1,1021,0,'Cash',NULL,'2022-01-18 10:55:55','2022-01-18 10:55:55'),(501,'spr-20220123-120847',1,NULL,110,9,1,710,0,'Cash',NULL,'2022-01-23 10:08:47','2022-01-23 10:08:47'),(502,'spr-20220125-021346',1,NULL,111,9,1,90,0,'Cash',NULL,'2022-01-25 12:13:46','2022-01-25 12:13:46'),(503,'spr-20220129-095307',1,NULL,112,9,1,445,0,'Cash',NULL,'2022-01-29 07:53:07','2022-01-29 07:53:07'),(504,'spr-20220131-104824',1,NULL,113,9,1,2700,0,'Cash',NULL,'2022-01-31 08:48:24','2022-01-31 08:48:24'),(505,'spr-20220205-060309',1,NULL,115,9,1,900,0,'Cash',NULL,'2022-02-05 16:03:09','2022-02-05 16:03:09'),(506,'spr-20220207-114828',1,NULL,116,9,1,2916,0,'Cash',NULL,'2022-02-07 09:48:28','2022-02-07 09:48:28'),(507,'spr-20220207-045001',1,NULL,117,9,1,800,0,'Cash',NULL,'2022-02-07 14:50:01','2022-02-07 14:50:01'),(508,'spr-20220207-073041',1,NULL,118,9,1,180,0,'Cash',NULL,'2022-02-07 17:30:41','2022-02-07 17:30:41'),(509,'spr-20220208-092445',1,NULL,119,9,1,507,0,'Cash',NULL,'2022-02-08 07:24:45','2022-02-08 07:24:45'),(510,'spr-20220208-093301',1,NULL,120,9,1,605,0,'Cash',NULL,'2022-02-08 07:33:01','2022-02-08 07:33:01'),(511,'spr-20220208-093415',1,NULL,121,9,1,100,0,'Cash',NULL,'2022-02-08 07:34:15','2022-02-08 07:34:15'),(512,'spr-20220208-094024',1,NULL,122,9,1,40,0,'Cash',NULL,'2022-02-08 07:40:24','2022-02-08 07:40:24'),(513,'spr-20220208-094746',1,NULL,123,9,1,2430,0,'Cash',NULL,'2022-02-08 07:47:46','2022-02-08 07:47:46'),(514,'spr-20220208-043103',1,NULL,124,9,1,970,0,'Cash',NULL,'2022-02-08 14:31:03','2022-02-08 14:31:03'),(515,'spr-20220208-052351',1,NULL,125,9,1,200,160,'Cash',NULL,'2022-02-08 15:23:51','2022-02-08 15:23:51'),(516,'spr-20220209-101908',1,NULL,126,9,1,480,0,'Cash',NULL,'2022-02-09 08:19:08','2022-02-09 08:19:08'),(517,'spr-20220209-110819',1,NULL,127,9,1,370,0,'Cash',NULL,'2022-02-09 09:08:19','2022-02-09 09:08:19'),(518,'spr-20220209-121112',1,NULL,128,9,1,260,280,'Cash',NULL,'2022-02-09 10:11:12','2022-02-09 10:11:12'),(519,'spr-20220209-122659',1,NULL,93,9,1,80,0,'Cash',NULL,'2022-02-09 10:26:59','2022-02-09 10:26:59'),(520,'spr-20220209-122731',1,NULL,114,9,1,486,0,'Cash',NULL,'2022-02-09 10:27:31','2022-02-09 10:27:31'),(521,'spr-20220209-122751',1,NULL,106,9,1,300,0,'Cash',NULL,'2022-02-09 10:27:51','2022-02-09 10:27:51'),(522,'spr-20220209-122834',1,NULL,66,9,1,217,0,'Cash',NULL,'2022-02-09 10:28:34','2022-02-09 10:28:34'),(523,'spr-20220209-122944',1,NULL,49,9,1,401,0,'Cash',NULL,'2022-02-09 10:29:44','2022-02-09 10:29:44'),(524,'spr-20220209-123036',1,NULL,29,9,1,400,0,'Cash',NULL,'2022-02-09 10:30:36','2022-02-09 10:30:36'),(525,'spr-20220209-123120',1,NULL,51,9,1,130,0,'Cash',NULL,'2022-02-09 10:31:20','2022-02-09 10:31:20'),(526,'spr-20220209-123444',1,NULL,58,9,1,185,135,'Cash',NULL,'2022-02-09 10:34:44','2022-02-09 10:34:44'),(527,'spr-20220209-040206',1,NULL,129,9,1,90,0,'Cash',NULL,'2022-02-09 14:02:06','2022-02-09 14:02:06'),(528,'spr-20220209-040351',1,NULL,130,9,1,43,0,'Cash',NULL,'2022-02-09 14:03:51','2022-02-09 14:03:51'),(529,'spr-20220210-032249',1,NULL,131,9,1,450,0,'Cash',NULL,'2022-02-10 13:22:49','2022-02-10 13:22:49'),(530,'spr-20220210-081348',1,NULL,132,9,1,90,0,'Cash',NULL,'2022-02-10 18:13:48','2022-02-10 18:13:48'),(531,'spr-20220210-081349',1,NULL,133,9,1,90,0,'Cash',NULL,'2022-02-10 18:13:49','2022-02-10 18:13:49'),(532,'spr-20220212-113828',1,NULL,134,9,1,1078,0,'Cash',NULL,'2022-02-12 09:38:28','2022-02-12 09:38:28'),(533,'spr-20220212-114537',1,NULL,135,9,1,450,0,'Cash',NULL,'2022-02-12 09:45:37','2022-02-12 09:45:37'),(534,'spr-20220212-121903',1,NULL,136,9,1,253,0,'Cash',NULL,'2022-02-12 10:19:03','2022-02-12 10:19:03'),(535,'spr-20220212-123517',1,NULL,137,9,1,678,0,'Cash',NULL,'2022-02-12 10:35:17','2022-02-12 10:35:17'),(536,'spr-20220212-124231',1,NULL,138,9,1,300,0,'Cash',NULL,'2022-02-12 10:42:31','2022-02-12 10:42:31'),(537,'spr-20220212-125923',1,NULL,139,9,1,390,0,'Cash',NULL,'2022-02-12 10:59:23','2022-02-12 10:59:23'),(538,'spr-20220212-020614',1,NULL,140,9,1,90,0,'Cash',NULL,'2022-02-12 12:06:14','2022-02-12 12:06:14'),(539,'spr-20220212-020714',1,NULL,141,9,1,270,0,'Cash',NULL,'2022-02-12 12:07:14','2022-02-12 12:07:14'),(540,'spr-20220213-105348',1,NULL,142,9,1,206,0,'Cash',NULL,'2022-02-13 08:53:48','2022-02-13 08:53:48'),(541,'spr-20220213-112056',1,NULL,143,9,1,2592,0,'Cash',NULL,'2022-02-13 09:20:56','2022-02-13 09:20:56'),(542,'spr-20220213-011431',1,NULL,144,9,1,1002,0,'Cash',NULL,'2022-02-13 11:14:31','2022-02-13 11:14:31'),(543,'spr-20220213-015308',1,NULL,145,9,1,390,0,'Cash',NULL,'2022-02-13 11:53:08','2022-02-13 11:53:08'),(544,'spr-20220213-020039',1,NULL,146,9,1,295,0,'Cash',NULL,'2022-02-13 12:00:39','2022-02-13 12:00:39'),(545,'spr-20220213-022649',1,NULL,147,9,1,334,0,'Cash',NULL,'2022-02-13 12:26:49','2022-02-13 12:26:49'),(546,'spr-20220213-045524',1,NULL,148,9,1,360,0,'Cash',NULL,'2022-02-13 14:55:24','2022-02-13 14:55:24'),(547,'spr-20220213-074628',1,NULL,149,9,1,180,0,'Cash',NULL,'2022-02-13 17:46:28','2022-02-13 17:46:28'),(548,'spr-20220214-112629',1,NULL,150,9,1,810,0,'Cash',NULL,'2022-02-14 09:26:29','2022-02-14 09:26:29'),(549,'spr-20220214-112954',1,NULL,151,9,1,90,0,'Cash',NULL,'2022-02-14 09:29:54','2022-02-14 09:29:54'),(550,'spr-20220214-023608',1,NULL,152,9,1,140,0,'Cash',NULL,'2022-02-14 12:36:08','2022-02-14 12:36:08'),(551,'spr-20220219-112231',1,NULL,154,9,1,270,0,'Cash',NULL,'2022-02-19 09:22:31','2022-02-19 09:22:31'),(552,'spr-20220219-112351',1,NULL,155,9,1,1134,0,'Cash',NULL,'2022-02-19 09:23:51','2022-02-19 09:23:51'),(553,'spr-20220221-012640',1,NULL,156,9,1,90,0,'Cash',NULL,'2022-02-21 11:26:40','2022-02-21 11:26:40'),(554,'spr-20220221-040200',1,NULL,157,9,1,117,0,'Cash',NULL,'2022-02-21 14:02:00','2022-02-21 14:02:00'),(555,'spr-20220221-060913',1,NULL,158,9,1,180,0,'Cash',NULL,'2022-02-21 16:09:13','2022-02-21 16:09:13'),(556,'spr-20220221-072249',1,NULL,159,9,1,80,0,'Cash',NULL,'2022-02-21 17:22:49','2022-02-21 17:22:49'),(557,'spr-20220221-080938',1,NULL,160,9,1,450,0,'Cash',NULL,'2022-02-21 18:09:38','2022-02-21 18:09:38'),(558,'spr-20220222-023508',1,NULL,161,9,1,290,0,'Cash',NULL,'2022-02-22 12:35:08','2022-02-22 12:35:08'),(559,'spr-20220223-060550',1,NULL,162,9,1,180,0,'Cash',NULL,'2022-02-23 16:05:50','2022-02-23 16:05:50'),(560,'spr-20220224-041848',1,NULL,163,9,1,180,0,'Cash',NULL,'2022-02-24 14:18:48','2022-02-24 14:18:48'),(561,'spr-20220226-031645',1,NULL,164,9,1,240,0,'Cash',NULL,'2022-02-26 13:16:45','2022-02-26 13:16:45'),(562,'spr-20220310-055556',1,NULL,167,9,1,90,0,'Cash',NULL,'2022-03-10 15:55:56','2022-03-10 15:55:56'),(563,'spr-20220317-054950',1,NULL,168,9,1,414,0,'Cash',NULL,'2022-03-17 15:49:50','2022-03-17 15:49:50'),(564,'spr-20220321-034116',1,NULL,169,9,1,90,0,'Cash',NULL,'2022-03-21 13:41:16','2022-03-21 13:41:16'),(565,'spr-20220323-085641',1,NULL,170,9,1,198,0,'Cash',NULL,'2022-03-23 06:56:41','2022-03-23 06:56:41'),(566,'spr-20220324-015817',1,NULL,171,9,1,285,0,'Cash',NULL,'2022-03-24 11:58:17','2022-03-24 11:58:17'),(567,'spr-20220326-015538',1,NULL,172,9,1,221,0,'Cash',NULL,'2022-03-26 11:55:38','2022-03-26 11:55:38'),(569,'spr-20220402-014300',1,NULL,178,9,1,885,0,'Cash',NULL,'2022-04-02 10:43:00','2022-04-02 10:43:00'),(570,'spr-20220402-015515',1,NULL,165,9,1,1704,0,'Cash',NULL,'2022-04-02 10:55:15','2022-04-02 10:55:15'),(571,'spr-20220402-015604',1,NULL,128,9,1,280,0,'Cash',NULL,'2022-04-02 10:56:04','2022-04-02 10:56:04'),(572,'spr-20220402-024409',1,NULL,179,9,1,1150,0,'Cash',NULL,'2022-04-02 11:44:09','2022-04-02 11:44:09'),(573,'spr-20220402-024635',1,NULL,153,9,1,107,0,'Cash',NULL,'2022-04-02 11:46:35','2022-04-02 11:46:35'),(574,'spr-20220402-084159',1,NULL,180,9,1,18540,0,'Cash',NULL,'2022-04-02 17:41:59','2022-04-02 17:41:59'),(575,'spr-20220403-020037',1,NULL,181,9,1,1920,0,'Cash',NULL,'2022-04-03 11:00:37','2022-04-03 11:00:37'),(576,'spr-20220403-091901',1,NULL,183,9,1,1380,0,'Cash',NULL,'2022-04-03 18:19:01','2022-04-03 18:19:01'),(577,'spr-20220403-092931',1,NULL,182,9,1,505,0,'Cash',NULL,'2022-04-03 18:29:31','2022-04-03 18:29:31'),(579,'spr-20220403-111704',1,NULL,185,9,1,11880,0,'Cash',NULL,'2022-04-03 20:17:04','2022-04-03 20:17:04'),(580,'spr-20220404-105644',1,NULL,186,9,1,160,0,'Cash',NULL,'2022-04-04 07:56:44','2022-04-04 07:56:44'),(581,'spr-20220404-110248',1,NULL,187,9,1,620,0,'Cash',NULL,'2022-04-04 08:02:48','2022-04-04 08:02:48'),(582,'spr-20220404-014930',1,NULL,188,9,1,830,0,'Cash',NULL,'2022-04-04 10:49:30','2022-04-04 10:49:30'),(583,'spr-20220404-015619',1,NULL,189,9,1,1090,0,'Cash',NULL,'2022-04-04 10:56:19','2022-04-04 10:56:19'),(584,'spr-20220404-093743',1,NULL,190,9,1,420,0,'Cash',NULL,'2022-04-04 18:37:43','2022-04-04 18:37:43'),(585,'spr-20220405-124243',1,NULL,191,9,1,830,0,'Cash',NULL,'2022-04-05 09:42:43','2022-04-05 09:42:43'),(586,'spr-20220406-010205',1,NULL,192,9,1,670,0,'Cash',NULL,'2022-04-06 10:02:05','2022-04-06 10:02:05'),(587,'spr-20220407-120335',1,NULL,193,9,1,510,0,'Cash',NULL,'2022-04-07 09:03:35','2022-04-07 09:03:35'),(588,'spr-20220407-122507',1,NULL,194,9,1,155,0,'Cash',NULL,'2022-04-07 09:25:07','2022-04-07 09:25:07'),(589,'spr-20220407-094045',1,NULL,195,9,1,1020,0,'Cash',NULL,'2022-04-07 18:40:45','2022-04-07 18:40:45'),(590,'spr-20220407-094426',1,NULL,196,9,1,140,0,'Cash',NULL,'2022-04-07 18:44:26','2022-04-07 18:44:26'),(591,'spr-20220409-024539',1,NULL,197,9,1,1980,0,'Cash',NULL,'2022-04-09 11:45:39','2022-04-09 11:45:39'),(592,'spr-20220410-032412',1,NULL,198,9,1,450,0,'Cash',NULL,'2022-04-10 12:24:12','2022-04-10 12:24:12'),(593,'spr-20220411-120523',1,NULL,199,9,1,4860,0,'Cash',NULL,'2022-04-11 09:05:23','2022-04-11 09:05:23'),(594,'spr-20220411-013333',1,NULL,200,9,1,625,0,'Cash',NULL,'2022-04-11 10:33:33','2022-04-11 10:33:33'),(595,'spr-20220414-111532',1,NULL,202,9,1,2457,0,'Cash',NULL,'2022-04-14 08:15:32','2022-04-14 08:15:32'),(596,'spr-20220416-123035',1,NULL,203,9,1,4698,0,'Cash',NULL,'2022-04-16 09:30:35','2022-04-16 09:30:35'),(598,'spr-20220416-042300',1,NULL,205,9,1,300,0,'Cash',NULL,'2022-04-16 13:23:00','2022-04-16 13:23:00'),(599,'spr-20220416-081445',1,NULL,206,9,1,100,0,'Cash',NULL,'2022-04-16 17:14:45','2022-04-16 17:14:45'),(600,'spr-20220417-104356',1,NULL,207,9,1,450,0,'Cash',NULL,'2022-04-17 07:43:56','2022-04-17 07:43:56'),(602,'spr-20220417-110914',1,NULL,209,9,1,380,0,'Cash',NULL,'2022-04-17 08:09:14','2022-04-17 08:09:14'),(603,'spr-20220417-111821',1,NULL,210,9,1,940,0,'Cash',NULL,'2022-04-17 08:18:21','2022-04-17 08:18:21'),(604,'spr-20220417-120046',1,NULL,211,9,1,600,0,'Cash',NULL,'2022-04-17 09:00:46','2022-04-17 09:00:46'),(606,'spr-20220417-020314',1,NULL,213,9,1,700,0,'Cash',NULL,'2022-04-17 11:03:14','2022-04-17 11:03:14'),(607,'spr-20220419-101325',1,NULL,214,9,1,3645,450,'Cash',NULL,'2022-04-19 19:13:25','2022-04-19 19:13:25'),(609,'spr-20220420-092218',1,NULL,216,9,1,380,0,'Cash',NULL,'2022-04-20 18:22:18','2022-04-20 18:22:18'),(610,'spr-20220421-041757',1,NULL,217,9,1,200,0,'Cash',NULL,'2022-04-21 13:17:57','2022-04-21 13:17:57'),(611,'spr-20220422-042834',1,NULL,220,9,1,560,600,'Cash',NULL,'2022-04-22 13:28:34','2022-04-22 13:28:34'),(612,'spr-20220422-114441',1,NULL,221,9,1,450,20,'Cash',NULL,'2022-04-22 20:44:41','2022-04-22 20:44:41'),(613,'spr-20220424-124938',1,NULL,219,9,1,1000,930,'Cash',NULL,'2022-04-23 21:49:38','2022-04-23 21:49:38'),(614,'spr-20220424-125116',1,NULL,201,9,1,870,1000,'Cash',NULL,'2022-04-23 21:51:16','2022-04-23 21:51:16'),(615,'spr-20220424-105107',1,NULL,222,9,1,195,85,'Cash',NULL,'2022-04-24 07:51:07','2022-04-24 07:51:07'),(616,'spr-20220424-112157',1,NULL,223,9,1,610,0,'Cash',NULL,'2022-04-24 08:21:57','2022-04-24 08:21:57'),(617,'spr-20220424-010820',1,NULL,224,9,1,1000,560,'Cash',NULL,'2022-04-24 10:08:20','2022-04-24 10:08:20'),(618,'spr-20220424-030942',1,NULL,225,9,1,1145,0,'Cash',NULL,'2022-04-24 12:09:42','2022-04-24 12:09:42'),(620,'spr-20220424-101656',1,NULL,227,9,1,2005,0,'Cash',NULL,'2022-04-24 19:16:56','2022-04-24 19:16:56'),(621,'spr-20220425-095544',1,NULL,228,9,1,500,0,'Cash',NULL,'2022-04-25 06:55:44','2022-04-25 06:55:44'),(624,'spr-20220425-101203',1,NULL,231,9,1,2220,0,'Cash',NULL,'2022-04-25 07:12:03','2022-04-25 07:12:03'),(625,'spr-20220425-103804',1,NULL,232,9,1,1440,0,'Cash',NULL,'2022-04-25 07:38:04','2022-04-25 07:38:04'),(626,'spr-20220425-020731',1,NULL,233,9,1,420,0,'Cash',NULL,'2022-04-25 11:07:31','2022-04-25 11:07:31'),(627,'spr-20220425-051107',1,NULL,234,9,1,700,0,'Cash',NULL,'2022-04-25 14:11:07','2022-04-25 14:11:07'),(628,'spr-20220426-032755',1,NULL,235,9,1,3816,0,'Cash',NULL,'2022-04-26 12:27:55','2022-04-26 12:27:55'),(629,'spr-20220426-084056',1,NULL,236,9,1,1330,550,'Cash',NULL,'2022-04-26 17:40:56','2022-04-26 17:40:56'),(630,'spr-20220426-084808',1,NULL,237,9,1,2000,1240,'Cash',NULL,'2022-04-26 17:48:08','2022-04-26 17:48:08'),(631,'spr-20220427-105633',1,NULL,240,9,1,846,0,'Cash',NULL,'2022-04-27 07:56:33','2022-04-27 07:56:33'),(632,'spr-20220427-124336',1,NULL,241,9,1,280,0,'Cash',NULL,'2022-04-27 09:43:36','2022-04-27 09:43:36'),(633,'spr-20220427-085651',1,NULL,242,9,1,308,0,'Cash',NULL,'2022-04-27 17:56:51','2022-04-27 17:56:51'),(634,'spr-20220427-104409',1,NULL,243,9,1,980,0,'Cash',NULL,'2022-04-27 19:44:09','2022-04-27 19:44:09'),(637,'spr-20220427-114738',1,NULL,246,9,1,513,0,'Cash',NULL,'2022-04-27 20:47:38','2022-04-27 20:47:38'),(638,'spr-20220428-100301',1,NULL,247,9,1,560,20,'Cash',NULL,'2022-04-28 07:03:01','2022-04-28 07:03:01'),(639,'spr-20220428-104527',1,NULL,248,9,1,300,193,'Cash',NULL,'2022-04-28 07:45:27','2022-04-28 07:45:27'),(641,'spr-20220428-030956',1,NULL,251,9,1,70,0,'Cash',NULL,'2022-04-28 12:09:56','2022-04-28 12:09:56'),(642,'spr-20220429-115508',1,NULL,252,9,1,1550,0,'Cash',NULL,'2022-04-29 08:55:08','2022-04-29 08:55:08'),(643,'spr-20220429-044844',1,NULL,250,9,1,540,0,'Cash',NULL,'2022-04-29 13:48:44','2022-04-29 13:48:44'),(644,'spr-20220429-044931',1,NULL,221,9,1,20,0,'Cash',NULL,'2022-04-29 13:49:31','2022-04-29 13:49:31'),(645,'spr-20220430-012423',1,NULL,237,9,1,1240,0,'Cash',NULL,'2022-04-29 22:24:23','2022-04-29 22:24:23'),(646,'spr-20220430-071328',1,NULL,201,9,1,1000,0,'Cash',NULL,'2022-04-30 16:13:28','2022-04-30 16:13:28'),(648,'spr-20220430-102325',1,NULL,220,9,1,600,0,'Cash',NULL,'2022-04-30 19:23:25','2022-04-30 19:23:25'),(649,'spr-20220501-093929',1,NULL,256,9,1,280,180,'Cash',NULL,'2022-05-01 06:39:29','2022-05-01 06:39:29'),(651,'spr-20220505-101045',1,NULL,258,9,1,610,0,'Cash',NULL,'2022-05-05 07:10:45','2022-05-05 07:10:45'),(652,'spr-20220505-103501',1,NULL,259,9,1,450,0,'Cash',NULL,'2022-05-05 07:35:01','2022-05-05 07:35:01'),(653,'spr-20220505-021726',1,NULL,260,9,1,480,0,'Cash',NULL,'2022-05-05 11:17:26','2022-05-05 11:17:26'),(654,'spr-20220507-092659',1,NULL,262,9,1,1060,0,'Cash',NULL,'2022-05-07 06:26:59','2022-05-07 06:26:59'),(655,'spr-20220507-114055',1,NULL,263,9,1,410,0,'Cash',NULL,'2022-05-07 08:40:55','2022-05-07 08:40:55'),(656,'spr-20220507-123611',1,NULL,265,9,1,300,0,'Cash',NULL,'2022-05-07 09:36:11','2022-05-07 09:36:11'),(657,'spr-20220508-113715',1,NULL,266,9,1,480,0,'Cash',NULL,'2022-05-08 08:37:15','2022-05-08 08:37:15'),(659,'spr-20220508-033246',1,NULL,268,9,1,1480,0,'Cash',NULL,'2022-05-08 12:32:46','2022-05-08 12:32:46'),(660,'spr-20220508-044559',1,NULL,269,9,1,540,0,'Cash',NULL,'2022-05-08 13:45:59','2022-05-08 13:45:59'),(661,'spr-20220509-074042',1,NULL,264,9,1,1800,0,'Cash',NULL,'2022-05-09 16:40:42','2022-05-09 16:40:42'),(662,'spr-20220509-074122',1,NULL,26,9,1,100,0,'Cash',NULL,'2022-05-09 16:41:22','2022-05-09 16:41:22'),(663,'spr-20220509-074207',1,NULL,214,9,1,450,0,'Cash',NULL,'2022-05-09 16:42:07','2022-05-09 16:42:07'),(664,'spr-20220509-074225',1,NULL,255,9,1,140,0,'Cash',NULL,'2022-05-09 16:42:25','2022-05-09 16:42:25'),(665,'spr-20220509-074252',1,NULL,224,9,1,560,0,'Cash',NULL,'2022-05-09 16:42:52','2022-05-09 16:42:52'),(666,'spr-20220509-074603',1,NULL,271,9,1,360,0,'Cash',NULL,'2022-05-09 16:46:03','2022-05-09 16:46:03'),(667,'spr-20220509-075200',1,NULL,247,9,1,20,0,'Cash',NULL,'2022-05-09 16:52:00','2022-05-09 16:52:00'),(668,'spr-20220509-075849',1,NULL,272,9,1,370,0,'Cash',NULL,'2022-05-09 16:58:49','2022-05-09 16:58:49'),(669,'spr-20220510-122036',1,NULL,273,9,1,80,0,'Cash',NULL,'2022-05-10 09:20:36','2022-05-10 09:20:36'),(670,'spr-20220510-015421',1,NULL,274,9,1,1710,0,'Cash',NULL,'2022-05-10 10:54:21','2022-05-10 10:54:21'),(671,'spr-20220510-020333',1,NULL,275,9,1,450,0,'Cash',NULL,'2022-05-10 11:03:33','2022-05-10 11:03:33'),(673,'spr-20220511-013205',1,NULL,277,9,1,360,0,'Cash',NULL,'2022-05-11 10:32:05','2022-05-11 10:32:05'),(675,'spr-20220512-033228',1,NULL,279,9,1,740,0,'Cash',NULL,'2022-05-12 12:32:28','2022-05-12 12:32:28'),(676,'spr-20220514-124441',1,NULL,280,9,1,630,0,'Cash',NULL,'2022-05-14 09:44:41','2022-05-14 09:44:41'),(679,'spr-20220515-063001',1,NULL,284,9,1,750,0,'Cash',NULL,'2022-05-15 15:30:01','2022-05-15 15:30:01'),(680,'spr-20220515-071835',1,NULL,285,9,1,1110,0,'Cash',NULL,'2022-05-15 16:18:35','2022-05-15 16:18:35'),(681,'spr-20220516-044140',1,NULL,286,9,1,720,0,'Cash',NULL,'2022-05-16 13:41:40','2022-05-16 13:41:40'),(682,'spr-20220516-044231',1,NULL,261,9,1,1320,0,'Cash',NULL,'2022-05-16 13:42:31','2022-05-16 13:42:31'),(683,'spr-20220518-112348',1,NULL,287,9,1,355,0,'Cash',NULL,'2022-05-18 08:23:48','2022-05-18 08:23:48'),(684,'spr-20220519-094335',1,NULL,289,9,1,425,0,'Cash',NULL,'2022-05-19 06:43:35','2022-05-19 06:43:35'),(685,'spr-20220522-012537',1,NULL,283,9,1,862,0,'Cash',NULL,'2022-05-22 10:25:37','2022-05-22 10:25:37'),(686,'spr-20220522-021545',1,NULL,270,9,1,1400,70,'Cash',NULL,'2022-05-22 11:15:45','2022-05-22 11:15:45'),(687,'spr-20220525-105040',1,NULL,290,9,1,360,0,'Cash',NULL,'2022-05-25 07:50:40','2022-05-25 07:50:40'),(688,'spr-20220602-094118',1,NULL,291,9,1,6240,0,'Cash',NULL,'2022-06-02 06:41:18','2022-06-02 06:41:18'),(689,'spr-20220606-022345',1,NULL,292,9,1,1170,0,'Cash',NULL,'2022-06-06 11:23:45','2022-06-06 11:23:45'),(690,'spr-20220607-054417',1,NULL,293,9,1,298,0,'Cash',NULL,'2022-06-07 14:44:17','2022-06-07 14:44:17'),(691,'spr-20220611-065453',1,NULL,219,9,1,930,0,'Cash',NULL,'2022-06-11 15:54:53','2022-06-11 15:54:53'),(692,'spr-20220613-031410',1,NULL,294,9,1,140,0,'Cash',NULL,'2022-06-13 12:14:10','2022-06-13 12:14:10'),(693,'spr-20220613-031910',1,NULL,144,9,1,54,0,'Cash',NULL,'2022-06-13 12:19:10','2022-06-13 12:19:10'),(694,'spr-20220619-121658',1,NULL,295,9,1,805,0,'Cash',NULL,'2022-06-19 09:16:58','2022-06-19 09:16:58'),(695,'spr-20220619-022847',1,NULL,296,9,1,360,0,'Cash',NULL,'2022-06-19 11:28:47','2022-06-19 11:28:47'),(696,'spr-20220620-102603',1,NULL,297,9,1,640,0,'Cash',NULL,'2022-06-20 07:26:03','2022-06-20 07:26:03'),(698,'spr-20220620-123505',1,NULL,300,9,1,392,0,'Cash',NULL,'2022-06-20 09:35:05','2022-06-20 09:35:05'),(699,'spr-20220621-110626',1,NULL,302,9,1,394,0,'Cash',NULL,'2022-06-21 08:06:26','2022-06-21 08:06:26'),(701,'spr-20220621-085955',1,NULL,304,9,1,230,0,'Cash',NULL,'2022-06-21 17:59:55','2022-06-21 17:59:55'),(702,'spr-20220622-014036',1,NULL,305,9,1,350,0,'Cash',NULL,'2022-06-22 10:40:36','2022-06-22 10:40:36'),(703,'spr-20220623-023553',1,NULL,306,9,1,670,0,'Cash',NULL,'2022-06-23 11:35:53','2022-06-23 11:35:53'),(704,'spr-20220627-094531',1,NULL,307,9,1,300,900,'Cash',NULL,'2022-06-27 06:45:31','2022-06-27 06:45:31'),(705,'spr-20220627-102956',1,NULL,301,9,1,740,0,'Cash',NULL,'2022-06-27 07:29:56','2022-06-27 07:29:56'),(706,'spr-20220627-122537',1,NULL,308,9,1,740,0,'Cash',NULL,'2022-06-27 09:25:37','2022-06-27 09:25:37'),(708,'spr-20220702-074300',1,NULL,311,9,1,760,984,'Cash',NULL,'2022-07-02 16:43:00','2022-07-02 16:43:00'),(710,'spr-20220707-122148',1,NULL,314,9,1,1540,405,'Cash',NULL,'2022-07-07 09:21:48','2022-07-07 09:21:48'),(711,'spr-20220707-122722',1,NULL,315,9,1,2160,0,'Cash',NULL,'2022-07-07 09:27:22','2022-07-07 09:27:22'),(712,'spr-20220707-122801',1,NULL,307,9,1,900,0,'Cash',NULL,'2022-07-07 09:28:01','2022-07-07 09:28:01'),(713,'spr-20220713-110902',1,NULL,316,9,1,270,0,'Cash',NULL,'2022-07-13 08:09:02','2022-07-13 08:09:02'),(720,'spr-20220717-034957',1,NULL,326,9,1,320,0,'Cash',NULL,'2022-07-17 12:49:57','2022-07-17 12:49:57'),(721,'spr-20220717-035205',1,NULL,311,9,1,500,484,'Cash',NULL,'2022-07-17 12:52:05','2022-07-17 12:52:05'),(722,'spr-20220721-042111',1,NULL,327,9,1,257,0,'Cash',NULL,'2022-07-21 13:21:11','2022-07-21 13:21:11'),(723,'spr-20220721-043159',1,NULL,328,9,1,1800,0,'Cash',NULL,'2022-07-21 13:31:59','2022-07-21 13:31:59'),(724,'spr-20220725-080907',1,NULL,331,9,1,270,0,'Cash',NULL,'2022-07-25 05:09:07','2022-07-25 05:09:07'),(726,'spr-20220727-062737',1,NULL,334,9,1,4000,0,'Cash',NULL,'2022-07-27 03:27:37','2022-07-27 03:27:37'),(728,'spr-20220727-063134',1,NULL,337,9,1,90,0,'Cash',NULL,'2022-07-27 03:31:34','2022-07-27 03:31:34'),(729,'spr-20220727-063215',1,NULL,338,9,1,480,0,'Cash',NULL,'2022-07-27 03:32:15','2022-07-27 03:32:15'),(730,'spr-20220727-060510',1,NULL,339,9,1,430,0,'Cash',NULL,'2022-07-27 15:05:10','2022-07-27 15:05:10'),(731,'spr-20220727-061327',1,NULL,340,9,1,450,0,'Cash',NULL,'2022-07-27 15:13:27','2022-07-27 15:13:27'),(732,'spr-20220727-061459',1,NULL,342,9,1,150,30,'Cash',NULL,'2022-07-27 15:14:59','2022-07-27 15:14:59'),(733,'spr-20220727-061626',1,NULL,343,9,1,90,0,'Cash',NULL,'2022-07-27 15:16:26','2022-07-27 15:16:26'),(734,'spr-20220727-061825',1,NULL,344,9,1,40,140,'Cash',NULL,'2022-07-27 15:18:25','2022-07-27 15:18:25'),(735,'spr-20220727-061902',1,NULL,345,9,1,250,0,'Cash',NULL,'2022-07-27 15:19:02','2022-07-27 15:19:02'),(736,'spr-20220727-062120',1,NULL,346,9,1,140,0,'Cash',NULL,'2022-07-27 15:21:20','2022-07-27 15:21:20'),(737,'spr-20220727-062233',1,NULL,347,9,1,535,0,'Cash',NULL,'2022-07-27 15:22:33','2022-07-27 15:22:33'),(738,'spr-20220727-062537',1,NULL,349,9,1,2080,0,'Cash',NULL,'2022-07-27 15:25:37','2022-07-27 15:25:37'),(739,'spr-20220727-062736',1,NULL,350,9,1,100,400,'Cash',NULL,'2022-07-27 15:27:36','2022-07-27 15:27:36'),(740,'spr-20220727-062810',1,NULL,351,9,1,70,0,'Cash',NULL,'2022-07-27 15:28:10','2022-07-27 15:28:10'),(741,'spr-20220727-062957',1,NULL,352,9,1,360,0,'Cash',NULL,'2022-07-27 15:29:57','2022-07-27 15:29:57'),(742,'spr-20220727-063213',1,NULL,353,9,1,180,0,'Cash',NULL,'2022-07-27 15:32:13','2022-07-27 15:32:13'),(743,'spr-20220728-070814',1,NULL,354,9,1,324,0,'Cash',NULL,'2022-07-28 16:08:14','2022-07-28 16:08:14'),(744,'spr-20220728-071831',1,NULL,355,9,1,530,0,'Cash',NULL,'2022-07-28 16:18:31','2022-07-28 16:18:31'),(745,'spr-20220728-071911',1,NULL,356,9,1,280,0,'Cash',NULL,'2022-07-28 16:19:11','2022-07-28 16:19:11'),(746,'spr-20220728-072019',1,NULL,357,9,1,1700,0,'Cash',NULL,'2022-07-28 16:20:19','2022-07-28 16:20:19'),(747,'spr-20220728-072124',1,NULL,358,9,1,160,0,'Cash',NULL,'2022-07-28 16:21:24','2022-07-28 16:21:24'),(748,'spr-20220728-072208',1,NULL,359,9,1,324,0,'Cash',NULL,'2022-07-28 16:22:08','2022-07-28 16:22:08'),(749,'spr-20220728-072909',1,NULL,361,9,1,1395,0,'Cash',NULL,'2022-07-28 16:29:09','2022-07-28 16:29:09'),(750,'spr-20220730-071524',1,NULL,321,9,1,4644,0,'Cash',NULL,'2022-07-30 04:15:24','2022-07-30 04:15:24'),(755,'spr-20220731-120438',1,NULL,368,9,1,2190,0,'Cash',NULL,'2022-07-31 09:04:38','2022-07-31 09:04:38'),(756,'spr-20220731-071223',1,NULL,370,9,1,160,0,'Cash',NULL,'2022-07-31 16:12:23','2022-07-31 16:12:23'),(757,'spr-20220731-071304',1,NULL,371,9,1,440,0,'Cash',NULL,'2022-07-31 16:13:04','2022-07-31 16:13:04'),(758,'spr-20220731-071350',1,NULL,372,9,1,470,0,'Cash',NULL,'2022-07-31 16:13:50','2022-07-31 16:13:50'),(759,'spr-20220731-071425',1,NULL,373,9,1,140,0,'Cash',NULL,'2022-07-31 16:14:25','2022-07-31 16:14:25'),(760,'spr-20220801-090033',1,NULL,374,9,1,600,0,'Cash',NULL,'2022-08-01 06:00:33','2022-08-01 06:00:33'),(765,'spr-20220803-094411',1,NULL,378,9,1,1320,400,'Cash',NULL,'2022-08-03 06:44:11','2022-08-03 06:44:11'),(767,'spr-20220803-071201',1,NULL,380,9,1,250,0,'Cash',NULL,'2022-08-03 16:12:01','2022-08-03 16:12:01'),(768,'spr-20220803-071240',1,NULL,381,9,1,260,0,'Cash',NULL,'2022-08-03 16:12:40','2022-08-03 16:12:40'),(769,'spr-20220803-071324',1,NULL,382,9,1,290,0,'Cash',NULL,'2022-08-03 16:13:24','2022-08-03 16:13:24'),(771,'spr-20220804-100511',1,NULL,384,9,1,990,0,'Cash',NULL,'2022-08-04 07:05:11','2022-08-04 07:05:11'),(772,'spr-20220804-111425',1,NULL,385,9,1,860,0,'Cash',NULL,'2022-08-04 08:14:25','2022-08-04 08:14:25'),(773,'spr-20220804-124753',1,NULL,386,9,1,5800,5000,'Cash',NULL,'2022-08-04 09:47:53','2022-08-04 09:47:53'),(774,'spr-20220804-070956',1,NULL,350,9,1,400,0,'Cash',NULL,'2022-08-04 16:09:56','2022-08-04 16:09:56'),(775,'spr-20220804-071301',1,NULL,329,9,1,720,0,'Cash',NULL,'2022-08-04 16:13:01','2022-08-04 16:13:01'),(776,'spr-20220810-082902',1,NULL,387,9,1,70,0,'Cash',NULL,'2022-08-10 05:29:02','2022-08-10 05:29:02'),(777,'spr-20220810-082902',1,NULL,388,9,1,70,0,'Cash',NULL,'2022-08-10 05:29:02','2022-08-10 05:29:02'),(779,'spr-20220810-083617',1,NULL,391,9,1,300,0,'Cash',NULL,'2022-08-10 05:36:17','2022-08-10 05:36:17'),(780,'spr-20220810-083948',1,NULL,386,9,1,5000,0,'Cash',NULL,'2022-08-10 05:39:48','2022-08-10 05:39:48'),(781,'spr-20220810-025428',1,NULL,393,9,1,980,0,'Cash',NULL,'2022-08-10 11:54:28','2022-08-10 11:54:28'),(782,'spr-20220811-123633',1,NULL,348,9,1,160,0,'Cash',NULL,'2022-08-11 09:36:33','2022-08-11 09:36:33'),(784,'spr-20220813-011500',1,NULL,397,9,1,397,0,'Cash',NULL,'2022-08-13 10:15:00','2022-08-13 10:15:00'),(785,'spr-20220813-063904',1,NULL,401,9,1,70,0,'Cash',NULL,'2022-08-13 15:39:04','2022-08-13 15:39:04'),(786,'spr-20220814-020618',1,NULL,403,9,1,2394,0,'Cash',NULL,'2022-08-14 11:06:18','2022-08-14 11:06:18'),(787,'spr-20220814-021029',1,NULL,396,9,1,3240,0,'Cash',NULL,'2022-08-14 11:10:29','2022-08-14 11:10:29'),(788,'spr-20220814-022349',1,NULL,344,9,1,140,0,'Cash',NULL,'2022-08-14 11:23:49','2022-08-14 11:23:49'),(789,'spr-20220815-090127',1,NULL,400,9,1,1000,0,'Cash',NULL,'2022-08-15 06:01:27','2022-08-15 06:01:27'),(790,'spr-20220815-105203',1,NULL,404,9,1,500,0,'Cash',NULL,'2022-08-15 07:52:03','2022-08-15 07:52:03'),(791,'spr-20220816-103650',1,NULL,405,9,1,2250,0,'Cash',NULL,'2022-08-16 07:36:50','2022-08-16 07:36:50'),(792,'spr-20220816-110253',1,NULL,406,9,1,2250,0,'Cash',NULL,'2022-08-16 08:02:53','2022-08-16 08:02:53'),(793,'spr-20220817-094438',1,NULL,256,9,1,140,40,'Cash',NULL,'2022-08-17 06:44:38','2022-08-17 06:44:38'),(794,'spr-20220817-094457',1,NULL,248,9,1,193,0,'Cash',NULL,'2022-08-17 06:44:57','2022-08-17 06:44:57'),(795,'spr-20220817-094509',1,NULL,222,9,1,85,0,'Cash',NULL,'2022-08-17 06:45:09','2022-08-17 06:45:09'),(796,'spr-20220817-094736',1,NULL,389,9,1,350,0,'Cash',NULL,'2022-08-17 06:47:36','2022-08-17 06:47:36'),(797,'spr-20220817-102944',1,NULL,408,9,1,270,0,'Cash',NULL,'2022-08-17 07:29:44','2022-08-17 07:29:44'),(798,'spr-20220818-105804',1,NULL,409,9,1,635,0,'Cash',NULL,'2022-08-18 07:58:04','2022-08-18 07:58:04'),(799,'spr-20220820-121234',1,NULL,410,9,1,2080,0,'Cash',NULL,'2022-08-20 09:12:34','2022-08-20 09:12:34'),(800,'spr-20220821-014354',1,NULL,399,9,1,832,0,'Cash',NULL,'2022-08-21 10:43:54','2022-08-21 10:43:54'),(801,'spr-20220821-014609',1,NULL,375,9,1,1200,0,'Cash',NULL,'2022-08-21 10:46:09','2022-08-21 10:46:09'),(802,'spr-20220821-014705',1,NULL,58,9,1,135,0,'Cash',NULL,'2022-08-21 10:47:05','2022-08-21 10:47:05'),(803,'spr-20220821-014809',1,NULL,311,9,1,484,0,'Cash',NULL,'2022-08-21 10:48:09','2022-08-21 10:48:09'),(804,'spr-20220821-014826',1,NULL,313,9,1,140,0,'Cash',NULL,'2022-08-21 10:48:26','2022-08-21 10:48:26'),(805,'spr-20220821-045648',1,NULL,411,9,1,700,0,'Cash',NULL,'2022-08-21 13:56:48','2022-08-21 13:56:48'),(806,'spr-20220821-045927',1,NULL,398,9,1,4410,0,'Cash',NULL,'2022-08-21 13:59:27','2022-08-21 13:59:27'),(808,'spr-20220822-041652',1,NULL,417,9,1,630,0,'Cash',NULL,'2022-08-22 13:16:52','2022-08-22 13:16:52'),(809,'spr-20220823-103856',1,NULL,418,9,1,500,0,'Cash',NULL,'2022-08-23 07:38:56','2022-08-23 07:38:56'),(811,'spr-20220825-103855',1,NULL,420,9,1,1080,0,'Cash',NULL,'2022-08-25 07:38:55','2022-08-25 07:38:55'),(813,'spr-20220829-122810',1,NULL,419,9,1,540,0,'Cash',NULL,'2022-08-29 09:28:10','2022-08-29 09:28:10'),(814,'spr-20220829-012845',1,NULL,430,9,1,700,0,'Cash',NULL,'2022-08-29 10:28:45','2022-08-29 10:28:45'),(815,'spr-20220829-030124',1,NULL,416,9,1,280,0,'Cash',NULL,'2022-08-29 12:01:24','2022-08-29 12:01:24'),(816,'spr-20220829-030144',1,NULL,414,9,1,540,0,'Cash',NULL,'2022-08-29 12:01:44','2022-08-29 12:01:44'),(817,'spr-20220829-030200',1,NULL,424,9,1,920,0,'Cash',NULL,'2022-08-29 12:02:00','2022-08-29 12:02:00'),(818,'spr-20220829-030229',1,NULL,412,9,1,500,0,'Cash',NULL,'2022-08-29 12:02:29','2022-08-29 12:02:29'),(819,'spr-20220831-094437',1,NULL,253,9,1,320,0,'Cash',NULL,'2022-08-31 06:44:37','2022-08-31 06:44:37'),(820,'spr-20220831-094506',1,NULL,125,9,1,160,0,'Cash',NULL,'2022-08-31 06:45:06','2022-08-31 06:45:06'),(822,'spr-20220903-121554',1,NULL,433,9,1,4050,0,'Cash',NULL,'2022-09-03 09:15:54','2022-09-03 09:15:54'),(823,'spr-20220905-085620',1,NULL,426,9,1,210,0,'Cash',NULL,'2022-09-05 05:56:20','2022-09-05 05:56:20'),(824,'spr-20220905-090009',1,NULL,55,9,1,100,0,'Cash',NULL,'2022-09-05 06:00:09','2022-09-05 06:00:09'),(825,'spr-20220906-060417',1,NULL,341,9,1,180,430,'Cash',NULL,'2022-09-06 15:04:17','2022-09-06 15:04:17'),(826,'spr-20220906-061500',1,NULL,436,9,1,590,0,'Cash',NULL,'2022-09-06 15:15:00','2022-09-06 15:15:00'),(827,'spr-20220906-061530',1,NULL,437,9,1,260,0,'Cash',NULL,'2022-09-06 15:15:30','2022-09-06 15:15:30'),(828,'spr-20220906-061617',1,NULL,438,9,1,110,500,'Cash',NULL,'2022-09-06 15:16:17','2022-09-06 15:16:17'),(829,'spr-20220906-061712',1,NULL,439,9,1,100,0,'Cash',NULL,'2022-09-06 15:17:12','2022-09-06 15:17:12'),(830,'spr-20220906-062528',1,NULL,378,9,1,300,100,'Cash',NULL,'2022-09-06 15:25:28','2022-09-06 15:25:28'),(831,'spr-20220910-090220',1,NULL,440,9,1,380,0,'Cash',NULL,'2022-09-10 06:02:20','2022-09-10 06:02:20'),(832,'spr-20220910-090444',1,NULL,441,9,1,190,0,'Cash',NULL,'2022-09-10 06:04:44','2022-09-10 06:04:44'),(833,'spr-20220910-093806',1,NULL,442,9,1,320,0,'Cash',NULL,'2022-09-10 06:38:06','2022-09-10 06:38:06'),(834,'spr-20220910-122925',1,NULL,429,9,1,900,0,'Cash',NULL,'2022-09-10 09:29:25','2022-09-10 09:29:25'),(835,'spr-20220910-123002',1,NULL,402,9,1,720,0,'Cash',NULL,'2022-09-10 09:30:02','2022-09-10 09:30:02'),(836,'spr-20220910-123240',1,NULL,443,9,1,170,0,'Cash',NULL,'2022-09-10 09:32:40','2022-09-10 09:32:40'),(837,'spr-20220911-014404',1,NULL,444,9,1,1330,0,'Cash',NULL,'2022-09-11 10:44:04','2022-09-11 10:44:04'),(839,'spr-20220913-052129',1,NULL,446,9,1,100,0,'Cash',NULL,'2022-09-13 14:21:29','2022-09-13 14:21:29'),(840,'spr-20220913-052245',1,NULL,447,9,1,350,100,'Cash',NULL,'2022-09-13 14:22:45','2022-09-13 14:22:45'),(841,'spr-20220914-074436',1,NULL,448,9,1,300,190,'Cash',NULL,'2022-09-14 04:44:36','2022-09-14 04:44:36'),(842,'spr-20220914-074725',1,NULL,449,9,1,180,0,'Cash',NULL,'2022-09-14 04:47:25','2022-09-14 04:47:25'),(843,'spr-20220914-080946',1,NULL,450,9,1,95,0,'Cash',NULL,'2022-09-14 05:09:46','2022-09-14 05:09:46'),(844,'spr-20220914-081149',1,NULL,451,9,1,220,200,'Cash',NULL,'2022-09-14 05:11:49','2022-09-14 05:11:49'),(845,'spr-20220914-081402',1,NULL,452,9,1,200,320,'Cash',NULL,'2022-09-14 05:14:02','2022-09-14 05:14:02'),(846,'spr-20220914-081641',1,NULL,453,9,1,170,0,'Cash',NULL,'2022-09-14 05:16:41','2022-09-14 05:16:41'),(847,'spr-20220914-054305',1,NULL,454,9,1,200,0,'Cash',NULL,'2022-09-14 14:43:05','2022-09-14 14:43:05'),(848,'spr-20220914-055106',1,NULL,455,9,1,475,0,'Cash',NULL,'2022-09-14 14:51:06','2022-09-14 14:51:06'),(849,'spr-20220914-055325',1,NULL,456,9,1,390,0,'Cash',NULL,'2022-09-14 14:53:25','2022-09-14 14:53:25'),(850,'spr-20220914-055422',1,NULL,457,9,1,175,0,'Cash',NULL,'2022-09-14 14:54:22','2022-09-14 14:54:22'),(851,'spr-20220914-055715',1,NULL,458,9,1,275,0,'Cash',NULL,'2022-09-14 14:57:15','2022-09-14 14:57:15'),(852,'spr-20220914-055955',1,NULL,459,9,1,255,0,'Cash',NULL,'2022-09-14 14:59:55','2022-09-14 14:59:55'),(853,'spr-20220921-103516',1,NULL,463,9,1,350,355,'Cash',NULL,'2022-09-21 07:35:16','2022-09-21 07:35:16'),(854,'spr-20220921-103645',1,NULL,465,9,1,180,0,'Cash',NULL,'2022-09-21 07:36:45','2022-09-21 07:36:45'),(855,'spr-20220921-031750',1,NULL,462,9,1,495,0,'Cash',NULL,'2022-09-21 12:17:50','2022-09-21 12:17:50'),(858,'spr-20220922-110900',1,NULL,472,9,1,1200,320,'Cash',NULL,'2022-09-22 08:09:00','2022-09-22 08:09:00'),(859,'spr-20220922-033901',1,NULL,473,9,1,180,0,'Cash',NULL,'2022-09-22 12:39:01','2022-09-22 12:39:01'),(860,'spr-20220924-101526',1,NULL,477,9,1,440,320,'Cash',NULL,'2022-09-24 07:15:26','2022-09-24 07:15:26'),(861,'spr-20220924-102050',1,NULL,469,9,1,865,2000,'Cash',NULL,'2022-09-24 07:20:50','2022-09-24 07:20:50'),(862,'spr-20220924-102146',1,NULL,435,9,1,470,0,'Cash',NULL,'2022-09-24 07:21:46','2022-09-24 07:21:46'),(863,'spr-20220924-102209',1,NULL,53,9,1,172,0,'Cash',NULL,'2022-09-24 07:22:09','2022-09-24 07:22:09'),(864,'spr-20220924-102253',1,NULL,438,9,1,200,300,'Cash',NULL,'2022-09-24 07:22:53','2022-09-24 07:22:53'),(865,'spr-20220925-115205',1,NULL,478,9,1,90,0,'Cash',NULL,'2022-09-25 08:52:05','2022-09-25 08:52:05'),(866,'spr-20220925-115435',1,NULL,479,9,1,255,0,'Cash',NULL,'2022-09-25 08:54:35','2022-09-25 08:54:35'),(867,'spr-20220925-035242',1,NULL,434,9,1,600,0,'Cash',NULL,'2022-09-25 12:52:42','2022-09-25 12:52:42'),(868,'spr-20220927-030105',1,NULL,480,9,1,720,0,'Cash',NULL,'2022-09-27 12:01:05','2022-09-27 12:01:05'),(869,'spr-20220928-110432',1,NULL,469,9,1,2000,0,'Cash',NULL,'2022-09-28 08:04:32','2022-09-28 08:04:32'),(870,'spr-20220928-075154',1,NULL,474,9,1,530,0,'Cash',NULL,'2022-09-28 16:51:54','2022-09-28 16:51:54'),(871,'spr-20220929-104619',1,NULL,482,9,1,940,235,'Cash',NULL,'2022-09-29 07:46:19','2022-09-29 07:46:19'),(872,'spr-20220929-020836',1,NULL,484,9,1,380,0,'Cash',NULL,'2022-09-29 11:08:36','2022-09-29 11:08:36'),(873,'spr-20221003-071349',1,NULL,485,9,1,840,0,'Cash',NULL,'2022-10-03 16:13:49','2022-10-03 16:13:49'),(874,'spr-20221003-071520',1,NULL,486,9,1,250,500,'Cash',NULL,'2022-10-03 16:15:20','2022-10-03 16:15:20'),(875,'spr-20221003-072132',1,NULL,487,9,1,1110,0,'Cash',NULL,'2022-10-03 16:21:32','2022-10-03 16:21:32'),(876,'spr-20221003-073333',1,NULL,488,9,1,10161,0,'Cash',NULL,'2022-10-03 16:33:33','2022-10-03 16:33:33'),(877,'spr-20221003-073518',1,NULL,489,9,1,4275,0,'Cash',NULL,'2022-10-03 16:35:18','2022-10-03 16:35:18'),(878,'spr-20221003-074205',1,NULL,490,9,1,525,0,'Cash',NULL,'2022-10-03 16:42:05','2022-10-03 16:42:05'),(879,'spr-20221004-102906',1,NULL,483,9,1,425,0,'Cash',NULL,'2022-10-04 07:29:06','2022-10-04 07:29:06'),(880,'spr-20221004-105032',1,NULL,492,9,1,540,0,'Cash',NULL,'2022-10-04 07:50:32','2022-10-04 07:50:32'),(882,'spr-20221004-105343',1,NULL,494,9,1,600,0,'Cash',NULL,'2022-10-04 07:53:43','2022-10-04 07:53:43'),(884,'spr-20221004-015920',1,NULL,497,9,1,1150,0,'Cash',NULL,'2022-10-04 10:59:20','2022-10-04 10:59:20'),(885,'spr-20221004-055448',1,NULL,451,9,1,200,0,'Cash',NULL,'2022-10-04 14:54:48','2022-10-04 14:54:48'),(886,'spr-20221005-092517',1,NULL,498,9,1,290,0,'Cash',NULL,'2022-10-05 06:25:17','2022-10-05 06:25:17'),(887,'spr-20221005-105741',1,NULL,499,9,1,570,0,'Cash',NULL,'2022-10-05 07:57:41','2022-10-05 07:57:41'),(888,'spr-20221005-011642',1,NULL,500,9,1,180,0,'Cash',NULL,'2022-10-05 10:16:42','2022-10-05 10:16:42'),(890,'spr-20221005-022747',1,NULL,504,9,1,2015,0,'Cash',NULL,'2022-10-05 11:27:47','2022-10-05 11:27:47'),(891,'spr-20221006-115620',1,NULL,395,9,1,180,0,'Cash',NULL,'2022-10-06 08:56:20','2022-10-06 08:56:20'),(893,'spr-20221006-021002',1,NULL,509,9,1,360,0,'Cash',NULL,'2022-10-06 11:10:02','2022-10-06 11:10:02'),(894,'spr-20221006-034652',1,NULL,508,9,1,650,0,'Cash',NULL,'2022-10-06 12:46:52','2022-10-06 12:46:52'),(895,'spr-20221006-035122',1,NULL,505,9,1,1020,0,'Cash',NULL,'2022-10-06 12:51:22','2022-10-06 12:51:22'),(896,'spr-20221006-035943',1,NULL,510,9,1,640,0,'Cash',NULL,'2022-10-06 12:59:43','2022-10-06 12:59:43'),(897,'spr-20221007-015627',1,NULL,511,9,1,510,0,'Cash',NULL,'2022-10-07 10:56:27','2022-10-07 10:56:27'),(898,'spr-20221008-084003',1,NULL,477,9,1,320,0,'Cash',NULL,'2022-10-08 05:40:03','2022-10-08 05:40:03'),(899,'spr-20221008-084325',1,NULL,512,9,1,1145,680,'Cash',NULL,'2022-10-08 05:43:25','2022-10-08 05:43:25'),(900,'spr-20221008-052905',1,NULL,514,9,1,180,0,'Cash',NULL,'2022-10-08 14:29:05','2022-10-08 14:29:05'),(901,'spr-20221009-125023',1,NULL,516,9,1,90,0,'Cash',NULL,'2022-10-09 09:50:23','2022-10-09 09:50:23'),(902,'spr-20221010-054659',1,NULL,314,9,1,200,205,'Cash',NULL,'2022-10-10 14:46:59','2022-10-10 14:46:59'),(903,'spr-20221011-101730',1,NULL,519,9,1,680,0,'Cash',NULL,'2022-10-11 07:17:30','2022-10-11 07:17:30'),(904,'spr-20221012-104210',1,NULL,520,9,1,600,0,'Cash',NULL,'2022-10-12 07:42:10','2022-10-12 07:42:10'),(905,'spr-20221012-121128',1,NULL,521,9,1,500,0,'Cash',NULL,'2022-10-12 09:11:28','2022-10-12 09:11:28'),(906,'spr-20221013-085433',1,NULL,476,9,1,3850,120,'Cash',NULL,'2022-10-13 05:54:33','2022-10-13 05:54:33'),(907,'spr-20221013-091947',1,NULL,513,9,1,450,0,'Cash',NULL,'2022-10-13 06:19:47','2022-10-13 06:19:47'),(908,'spr-20221013-014447',1,NULL,525,9,1,805,0,'Cash',NULL,'2022-10-13 10:44:47','2022-10-13 10:44:47'),(909,'spr-20221015-031103',1,NULL,526,9,1,559,0,'Cash',NULL,'2022-10-15 12:11:03','2022-10-15 12:11:03'),(910,'spr-20221015-032301',1,NULL,524,9,1,1260,0,'Cash',NULL,'2022-10-15 12:23:01','2022-10-15 12:23:01'),(911,'spr-20221015-032310',1,NULL,517,9,1,720,0,'Cash',NULL,'2022-10-15 12:23:10','2022-10-15 12:23:10'),(912,'spr-20221016-112234',1,NULL,527,9,1,625,0,'Cash',NULL,'2022-10-16 08:22:34','2022-10-16 08:22:34'),(913,'spr-20221017-012620',1,NULL,527,9,1,5,0,'Cash',NULL,'2022-10-17 10:26:20','2022-10-17 10:26:20'),(914,'spr-20221017-012754',1,NULL,518,9,1,270,0,'Cash',NULL,'2022-10-17 10:27:54','2022-10-17 10:27:54'),(915,'spr-20221018-101756',1,NULL,530,9,1,85,0,'Cash',NULL,'2022-10-18 07:17:56','2022-10-18 07:17:56'),(916,'spr-20221020-094452',1,NULL,481,9,1,190,0,'Cash',NULL,'2022-10-20 06:44:52','2022-10-20 06:44:52'),(918,'spr-20221021-035033',1,NULL,532,9,1,500,465,'Cash',NULL,'2022-10-21 12:50:33','2022-10-21 12:50:33'),(919,'spr-20221022-085116',1,NULL,533,9,1,510,720,'Cash',NULL,'2022-10-22 05:51:16','2022-10-22 05:51:16'),(920,'spr-20221022-021246',1,NULL,534,9,1,305,0,'Cash',NULL,'2022-10-22 11:12:46','2022-10-22 11:12:46'),(922,'spr-20221023-035125',1,NULL,536,9,1,805,0,'Cash',NULL,'2022-10-23 12:51:25','2022-10-23 12:51:25'),(923,'spr-20221023-035408',1,NULL,538,9,1,460,0,'Cash',NULL,'2022-10-23 12:54:08','2022-10-23 12:54:08'),(924,'spr-20221023-035719',1,NULL,515,9,1,670,0,'Cash',NULL,'2022-10-23 12:57:19','2022-10-23 12:57:19'),(925,'spr-20221023-035758',1,NULL,503,9,1,870,0,'Cash',NULL,'2022-10-23 12:57:58','2022-10-23 12:57:58'),(926,'spr-20221023-035938',1,NULL,491,9,1,400,80,'Cash',NULL,'2022-10-23 12:59:38','2022-10-23 12:59:38'),(927,'spr-20221023-040049',1,NULL,438,9,1,300,0,'Cash',NULL,'2022-10-23 13:00:49','2022-10-23 13:00:49'),(928,'spr-20221023-040107',1,NULL,486,9,1,500,0,'Cash',NULL,'2022-10-23 13:01:07','2022-10-23 13:01:07'),(929,'spr-20221023-040122',1,NULL,452,9,1,320,0,'Cash',NULL,'2022-10-23 13:01:22','2022-10-23 13:01:22'),(930,'spr-20221023-040139',1,NULL,482,9,1,235,0,'Cash',NULL,'2022-10-23 13:01:39','2022-10-23 13:01:39'),(931,'spr-20221024-052656',1,NULL,270,9,1,70,0,'Cash',NULL,'2022-10-24 14:26:56','2022-10-24 14:26:56'),(932,'spr-20221024-052725',1,NULL,270,9,1,70,0,'Cash',NULL,'2022-10-24 14:27:25','2022-10-24 14:27:25'),(933,'spr-20221025-104020',1,NULL,542,9,1,570,0,'Cash',NULL,'2022-10-25 07:40:20','2022-10-25 07:40:20'),(934,'spr-20221025-113208',1,NULL,543,9,1,600,250,'Cash',NULL,'2022-10-25 08:32:08','2022-10-25 08:32:08'),(935,'spr-20221025-070541',1,NULL,544,9,1,225,0,'Cash',NULL,'2022-10-25 16:05:41','2022-10-25 16:05:41'),(936,'spr-20221031-021547',1,NULL,545,9,1,100,0,'Cash',NULL,'2022-10-31 12:15:47','2022-10-31 12:15:47'),(937,'spr-20221103-102116',1,NULL,546,9,1,30,0,'Cash',NULL,'2022-11-03 08:21:16','2022-11-03 08:21:16'),(938,'spr-20221103-102730',1,NULL,547,9,1,1200,355,'Cash',NULL,'2022-11-03 08:27:30','2022-11-03 08:27:30'),(939,'spr-20221103-103947',1,NULL,548,9,1,644,0,'Cash',NULL,'2022-11-03 08:39:47','2022-11-03 08:39:47'),(940,'spr-20221103-104056',1,NULL,533,9,1,720,0,'Cash',NULL,'2022-11-03 08:40:56','2022-11-03 08:40:56'),(941,'spr-20221103-104251',1,NULL,523,9,1,2000,240,'Cash',NULL,'2022-11-03 08:42:51','2022-11-03 08:42:51'),(942,'spr-20221103-104336',1,NULL,512,9,1,280,400,'Cash',NULL,'2022-11-03 08:43:36','2022-11-03 08:43:36'),(943,'spr-20221103-104731',1,NULL,270,9,1,-70,0,'Cash',NULL,'2022-11-03 08:47:31','2022-11-03 08:47:31'),(944,'spr-20221103-104925',1,NULL,491,9,1,80,0,'Cash',NULL,'2022-11-03 08:49:25','2022-11-03 08:49:25'),(945,'spr-20221103-110539',1,NULL,468,9,1,810,0,'Cash',NULL,'2022-11-03 09:05:39','2022-11-03 09:05:39'),(946,'spr-20221103-030406',1,NULL,549,9,1,600,0,'Cash',NULL,'2022-11-03 13:04:06','2022-11-03 13:04:06'),(948,'spr-20221105-091444',1,NULL,551,9,1,180,0,'Cash',NULL,'2022-11-05 07:14:44','2022-11-05 07:14:44'),(949,'spr-20221105-091539',1,NULL,552,9,1,90,0,'Cash',NULL,'2022-11-05 07:15:39','2022-11-05 07:15:39'),(951,'spr-20221105-102352',1,NULL,336,9,1,500,0,'Cash',NULL,'2022-11-05 08:23:52','2022-11-05 08:23:52'),(952,'spr-20221105-102405',1,NULL,543,9,1,250,0,'Cash',NULL,'2022-11-05 08:24:05','2022-11-05 08:24:05'),(953,'spr-20221105-102548',1,NULL,555,9,1,1215,0,'Cash',NULL,'2022-11-05 08:25:48','2022-11-05 08:25:48'),(954,'spr-20221106-121625',1,NULL,512,9,1,400,0,'Cash',NULL,'2022-11-06 10:16:25','2022-11-06 10:16:25'),(955,'spr-20221107-120012',1,NULL,556,9,1,748,0,'Cash',NULL,'2022-11-07 10:00:12','2022-11-07 10:00:12'),(956,'spr-20221108-080904',1,NULL,557,9,1,210,0,'Cash',NULL,'2022-11-08 06:09:04','2022-11-08 06:09:04'),(957,'spr-20221108-090813',1,NULL,529,9,1,180,0,'Cash',NULL,'2022-11-08 07:08:13','2022-11-08 07:08:13'),(958,'spr-20221109-034200',1,NULL,559,9,1,260,0,'Cash',NULL,'2022-11-09 13:42:00','2022-11-09 13:42:00'),(959,'spr-20221109-034536',1,NULL,560,9,1,740,0,'Cash',NULL,'2022-11-09 13:45:36','2022-11-09 13:45:36'),(960,'spr-20221109-035126',1,NULL,561,9,1,185,0,'Cash',NULL,'2022-11-09 13:51:26','2022-11-09 13:51:26'),(961,'spr-20221109-035315',1,NULL,562,9,1,315,600,'Cash',NULL,'2022-11-09 13:53:15','2022-11-09 13:53:15'),(962,'spr-20221110-081812',1,NULL,460,9,1,690,0,'Cash',NULL,'2022-11-10 06:18:12','2022-11-10 06:18:12'),(963,'spr-20221110-010005',1,NULL,564,9,1,330,0,'Cash',NULL,'2022-11-10 11:00:05','2022-11-10 11:00:05'),(964,'spr-20221110-024857',1,NULL,565,9,1,381,0,'Cash',NULL,'2022-11-10 12:48:57','2022-11-10 12:48:57'),(965,'spr-20221110-035638',1,NULL,566,9,1,160,0,'Cash',NULL,'2022-11-10 13:56:38','2022-11-10 13:56:38'),(966,'spr-20221110-035849',1,NULL,567,9,1,270,0,'Cash',NULL,'2022-11-10 13:58:49','2022-11-10 13:58:49'),(967,'spr-20221110-071355',1,NULL,463,9,1,355,0,'Cash',NULL,'2022-11-10 17:13:55','2022-11-10 17:13:55'),(968,'spr-20221113-083741',1,NULL,541,9,1,665,0,'Cash',NULL,'2022-11-13 06:37:41','2022-11-13 06:37:41'),(970,'spr-20221114-092213',1,NULL,570,9,1,550,0,'Cash',NULL,'2022-11-14 07:22:13','2022-11-14 07:22:13'),(971,'spr-20221114-092453',1,NULL,571,9,1,280,0,'Cash',NULL,'2022-11-14 07:24:53','2022-11-14 07:24:53'),(972,'spr-20221114-092603',1,NULL,572,9,1,510,0,'Cash',NULL,'2022-11-14 07:26:03','2022-11-14 07:26:03'),(973,'spr-20221114-062034',1,NULL,573,9,1,190,0,'Cash',NULL,'2022-11-14 16:20:34','2022-11-14 16:20:34'),(974,'spr-20221114-062227',1,NULL,574,9,1,309,0,'Cash',NULL,'2022-11-14 16:22:27','2022-11-14 16:22:27'),(975,'spr-20221114-062312',1,NULL,575,9,1,85,0,'Cash',NULL,'2022-11-14 16:23:12','2022-11-14 16:23:12'),(976,'spr-20221114-062433',1,NULL,576,9,1,275,0,'Cash',NULL,'2022-11-14 16:24:33','2022-11-14 16:24:33'),(977,'spr-20221114-062600',1,NULL,577,9,1,265,0,'Cash',NULL,'2022-11-14 16:26:00','2022-11-14 16:26:00'),(978,'spr-20221115-063818',1,NULL,578,9,1,870,0,'Cash',NULL,'2022-11-15 16:38:18','2022-11-15 16:38:18'),(979,'spr-20221115-063939',1,NULL,579,9,1,275,0,'Cash',NULL,'2022-11-15 16:39:39','2022-11-15 16:39:39'),(980,'spr-20221115-064215',1,NULL,580,9,1,80,0,'Cash',NULL,'2022-11-15 16:42:15','2022-11-15 16:42:15'),(981,'spr-20221115-072645',1,NULL,581,9,1,440,0,'Cash',NULL,'2022-11-15 17:26:45','2022-11-15 17:26:45'),(982,'spr-20221117-073038',1,NULL,582,9,1,510,0,'Cash',NULL,'2022-11-17 05:30:38','2022-11-17 05:30:38'),(983,'spr-20221117-073211',1,NULL,583,9,1,180,0,'Cash',NULL,'2022-11-17 05:32:11','2022-11-17 05:32:11'),(984,'spr-20221117-073929',1,NULL,585,9,1,450,0,'Cash',NULL,'2022-11-17 05:39:29','2022-11-17 05:39:29'),(985,'spr-20221117-051344',1,NULL,586,9,1,390,0,'Cash',NULL,'2022-11-17 15:13:44','2022-11-17 15:13:44'),(986,'spr-20221117-051513',1,NULL,587,9,1,95,0,'Cash',NULL,'2022-11-17 15:15:13','2022-11-17 15:15:13'),(987,'spr-20221117-053018',1,NULL,588,9,1,425,0,'Cash',NULL,'2022-11-17 15:30:18','2022-11-17 15:30:18'),(988,'spr-20221117-053539',1,NULL,591,9,1,505,0,'Cash',NULL,'2022-11-17 15:35:39','2022-11-17 15:35:39'),(989,'spr-20221117-053657',1,NULL,592,9,1,145,0,'Cash',NULL,'2022-11-17 15:36:57','2022-11-17 15:36:57'),(990,'spr-20221119-041941',1,NULL,554,9,1,530,0,'Cash',NULL,'2022-11-19 14:19:41','2022-11-19 14:19:41'),(991,'spr-20221119-061750',1,NULL,593,9,1,100,0,'Cash',NULL,'2022-11-19 16:17:50','2022-11-19 16:17:50'),(992,'spr-20221120-123041',1,NULL,594,9,1,995,0,'Cash',NULL,'2022-11-20 10:30:41','2022-11-20 10:30:41'),(993,'spr-20221122-023414',1,NULL,596,9,1,340,0,'Cash',NULL,'2022-11-22 12:34:14','2022-11-22 12:34:14'),(994,'spr-20221123-083140',1,NULL,600,9,1,180,0,'Cash',NULL,'2022-11-23 06:31:40','2022-11-23 06:31:40'),(995,'spr-20221123-125858',1,NULL,601,9,1,180,0,'Cash',NULL,'2022-11-23 10:58:58','2022-11-23 10:58:58'),(996,'spr-20221123-020812',1,NULL,602,9,1,170,0,'Cash',NULL,'2022-11-23 12:08:12','2022-11-23 12:08:12'),(997,'spr-20221123-021141',1,NULL,603,9,1,80,0,'Cash',NULL,'2022-11-23 12:11:41','2022-11-23 12:11:41'),(998,'spr-20221123-041416',1,NULL,604,9,1,300,140,'Cash',NULL,'2022-11-23 14:14:16','2022-11-23 14:14:16'),(999,'spr-20221123-041459',1,NULL,605,9,1,160,0,'Cash',NULL,'2022-11-23 14:14:59','2022-11-23 14:14:59'),(1000,'spr-20221124-084004',1,NULL,606,9,1,145,0,'Cash',NULL,'2022-11-24 06:40:04','2022-11-24 06:40:04'),(1001,'spr-20221124-103103',1,NULL,558,9,1,650,0,'Cash',NULL,'2022-11-24 08:31:03','2022-11-24 08:31:03'),(1002,'spr-20221124-072616',1,NULL,607,9,1,80,0,'Cash',NULL,'2022-11-24 17:26:16','2022-11-24 17:26:16'),(1003,'spr-20221128-123806',1,NULL,608,9,1,270,0,'Cash',NULL,'2022-11-28 10:38:06','2022-11-28 10:38:06'),(1006,'spr-20221130-110254',1,NULL,547,9,1,355,0,'Cash',NULL,'2022-11-30 09:02:54','2022-11-30 09:02:54'),(1007,'spr-20221130-110325',1,NULL,597,9,1,645,65,'Cash',NULL,'2022-11-30 09:03:25','2022-11-30 09:03:25'),(1008,'spr-20221130-112053',1,NULL,568,9,1,200,640,'Cash',NULL,'2022-11-30 09:20:53','2022-11-30 09:20:53'),(1010,'spr-20221203-061817',1,NULL,616,9,1,80,0,'Cash',NULL,'2022-12-03 16:18:17','2022-12-03 16:18:17'),(1011,'spr-20221208-083254',1,NULL,609,9,1,1005,0,'Cash',NULL,'2022-12-08 06:32:54','2022-12-08 06:32:54'),(1012,'spr-20221208-083304',1,NULL,613,9,1,270,0,'Cash',NULL,'2022-12-08 06:33:04','2022-12-08 06:33:04'),(1013,'spr-20221208-083350',1,NULL,599,9,1,375,70,'Cash',NULL,'2022-12-08 06:33:50','2022-12-08 06:33:50'),(1014,'spr-20221208-083404',1,NULL,595,9,1,475,0,'Cash',NULL,'2022-12-08 06:34:04','2022-12-08 06:34:04'),(1015,'spr-20221208-083430',1,NULL,539,9,1,300,150,'Cash',NULL,'2022-12-08 06:34:30','2022-12-08 06:34:30'),(1016,'spr-20221208-083602',1,NULL,537,9,1,100,0,'Cash',NULL,'2022-12-08 06:36:02','2022-12-08 06:36:02'),(1017,'spr-20221208-083625',1,NULL,341,9,1,100,330,'Cash',NULL,'2022-12-08 06:36:25','2022-12-08 06:36:25'),(1018,'spr-20221208-104449',1,NULL,617,9,1,75,0,'Cash',NULL,'2022-12-08 08:44:49','2022-12-08 08:44:49'),(1019,'spr-20221208-104851',1,NULL,618,9,1,54,0,'Cash',NULL,'2022-12-08 08:48:51','2022-12-08 08:48:51'),(1020,'spr-20221208-105211',1,NULL,619,9,1,24,0,'Cash',NULL,'2022-12-08 08:52:11','2022-12-08 08:52:11'),(1021,'spr-20221208-105731',1,NULL,620,9,1,390,0,'Cash',NULL,'2022-12-08 08:57:31','2022-12-08 08:57:31'),(1022,'spr-20221208-110200',1,NULL,621,9,1,60,0,'Cash',NULL,'2022-12-08 09:02:00','2022-12-08 09:02:00'),(1023,'spr-20221208-112436',1,NULL,622,9,1,400,1443,'Cash',NULL,'2022-12-08 09:24:36','2022-12-08 09:24:36'),(1024,'spr-20221208-112602',1,NULL,623,9,1,560,0,'Cash',NULL,'2022-12-08 09:26:02','2022-12-08 09:26:02'),(1025,'spr-20221208-122806',1,NULL,624,9,1,80,0,'Cash',NULL,'2022-12-08 10:28:06','2022-12-08 10:28:06'),(1026,'spr-20221208-122902',1,NULL,625,9,1,66,0,'Cash',NULL,'2022-12-08 10:29:02','2022-12-08 10:29:02'),(1027,'spr-20221208-123141',1,NULL,627,9,1,365,0,'Cash',NULL,'2022-12-08 10:31:41','2022-12-08 10:31:41'),(1028,'spr-20221208-124118',1,NULL,628,9,1,330,0,'Cash',NULL,'2022-12-08 10:41:18','2022-12-08 10:41:18'),(1029,'spr-20221208-124311',1,NULL,629,9,1,233,0,'Cash',NULL,'2022-12-08 10:43:11','2022-12-08 10:43:11'),(1030,'spr-20221208-124710',1,NULL,630,9,1,195,0,'Cash',NULL,'2022-12-08 10:47:10','2022-12-08 10:47:10'),(1031,'spr-20221208-125300',1,NULL,631,9,1,156,0,'Cash',NULL,'2022-12-08 10:53:00','2022-12-08 10:53:00'),(1032,'spr-20221208-125352',1,NULL,632,9,1,260,0,'Cash',NULL,'2022-12-08 10:53:52','2022-12-08 10:53:52'),(1033,'spr-20221208-010047',1,NULL,633,9,1,377,0,'Cash',NULL,'2022-12-08 11:00:47','2022-12-08 11:00:47'),(1034,'spr-20221208-010305',1,NULL,634,9,1,108,0,'Cash',NULL,'2022-12-08 11:03:05','2022-12-08 11:03:05'),(1035,'spr-20221208-011219',1,NULL,637,9,1,60,0,'Cash',NULL,'2022-12-08 11:12:19','2022-12-08 11:12:19'),(1036,'spr-20221208-011424',1,NULL,638,9,1,240,0,'Cash',NULL,'2022-12-08 11:14:24','2022-12-08 11:14:24'),(1037,'spr-20221208-011625',1,NULL,639,9,1,290,0,'Cash',NULL,'2022-12-08 11:16:25','2022-12-08 11:16:25'),(1038,'spr-20221208-012502',1,NULL,641,9,1,278,174,'Cash',NULL,'2022-12-08 11:25:02','2022-12-08 11:25:02'),(1039,'spr-20221208-012818',1,NULL,642,9,1,708,0,'Cash',NULL,'2022-12-08 11:28:18','2022-12-08 11:28:18'),(1040,'spr-20221208-013044',1,NULL,643,9,1,230,0,'Cash',NULL,'2022-12-08 11:30:44','2022-12-08 11:30:44'),(1041,'spr-20221208-013805',1,NULL,314,9,1,205,0,'Cash',NULL,'2022-12-08 11:38:05','2022-12-08 11:38:05'),(1042,'spr-20221208-051635',1,NULL,590,9,1,500,350,'Cash',NULL,'2022-12-08 15:16:35','2022-12-08 15:16:35'),(1043,'spr-20221208-053600',1,NULL,644,9,1,54,0,'Cash',NULL,'2022-12-08 15:36:00','2022-12-08 15:36:00'),(1044,'spr-20221208-053641',1,NULL,645,9,1,24,0,'Cash',NULL,'2022-12-08 15:36:41','2022-12-08 15:36:41'),(1045,'spr-20221208-053747',1,NULL,646,9,1,90,0,'Cash',NULL,'2022-12-08 15:37:47','2022-12-08 15:37:47'),(1046,'spr-20221208-054020',1,NULL,647,9,1,170,0,'Cash',NULL,'2022-12-08 15:40:20','2022-12-08 15:40:20'),(1047,'spr-20221210-011352',1,NULL,648,9,1,630,0,'Cash',NULL,'2022-12-10 11:13:52','2022-12-10 11:13:52'),(1048,'spr-20221211-041616',1,NULL,649,9,1,500,0,'Cash',NULL,'2022-12-11 14:16:16','2022-12-11 14:16:16'),(1049,'spr-20221212-010357',1,NULL,562,9,1,600,0,'Cash',NULL,'2022-12-12 11:03:57','2022-12-12 11:03:57'),(1051,'spr-20221215-011957',1,NULL,652,9,1,234,0,'Cash',NULL,'2022-12-15 11:19:57','2022-12-15 11:19:57'),(1052,'spr-20221215-042330',1,NULL,622,9,1,250,1193,'Cash',NULL,'2022-12-15 14:23:30','2022-12-15 14:23:30'),(1053,'spr-20221215-042359',1,NULL,614,9,1,75,0,'Cash',NULL,'2022-12-15 14:23:59','2022-12-15 14:23:59'),(1054,'spr-20221215-042418',1,NULL,568,9,1,125,515,'Cash',NULL,'2022-12-15 14:24:18','2022-12-15 14:24:18'),(1055,'spr-20221215-042658',1,NULL,653,9,1,25,0,'Cash',NULL,'2022-12-15 14:26:58','2022-12-15 14:26:58'),(1056,'spr-20221219-123936',1,NULL,654,9,1,720,0,'Cash',NULL,'2022-12-19 10:39:36','2022-12-19 10:39:36'),(1057,'spr-20221220-082309',1,NULL,236,9,1,550,0,'Cash',NULL,'2022-12-20 18:23:09','2022-12-20 18:23:09'),(1058,'spr-20221226-030552',1,NULL,622,9,1,300,893,'Cash',NULL,'2022-12-26 13:05:52','2022-12-26 13:05:52'),(1059,'spr-20221226-030641',1,NULL,640,9,1,281,0,'Cash',NULL,'2022-12-26 13:06:41','2022-12-26 13:06:41'),(1060,'spr-20221226-030747',1,NULL,447,9,1,100,0,'Cash',NULL,'2022-12-26 13:07:47','2022-12-26 13:07:47'),(1061,'spr-20221226-030853',1,NULL,589,9,1,265,0,'Cash',NULL,'2022-12-26 13:08:53','2022-12-26 13:08:53'),(1062,'spr-20221226-031016',1,NULL,532,9,1,200,265,'Cash',NULL,'2022-12-26 13:10:16','2022-12-26 13:10:16'),(1063,'spr-20221227-054351',1,NULL,657,9,1,19154,0,'Cash',NULL,'2022-12-27 15:43:51','2022-12-27 15:43:51'),(1064,'spr-20221227-055029',1,NULL,658,9,1,478,0,'Cash',NULL,'2022-12-27 15:50:29','2022-12-27 15:50:29'),(1065,'spr-20221228-030039',1,NULL,622,9,1,400,493,'Cash',NULL,'2022-12-28 13:00:39','2022-12-28 13:00:39'),(1066,'spr-20221228-030059',1,NULL,568,9,1,200,315,'Cash',NULL,'2022-12-28 13:00:59','2022-12-28 13:00:59'),(1067,'spr-20221228-030114',1,NULL,649,9,1,10,0,'Cash',NULL,'2022-12-28 13:01:14','2022-12-28 13:01:14'),(1068,'spr-20221228-030147',1,NULL,635,9,1,270,0,'Cash',NULL,'2022-12-28 13:01:47','2022-12-28 13:01:47'),(1069,'spr-20221228-030221',1,NULL,590,9,1,350,0,'Cash',NULL,'2022-12-28 13:02:21','2022-12-28 13:02:21'),(1070,'spr-20221229-014338',1,NULL,659,9,1,17990,0,'Cash',NULL,'2022-12-29 11:43:38','2022-12-29 11:43:38'),(1071,'spr-20230105-102221',1,NULL,660,9,1,455,0,'Cash',NULL,'2023-01-05 08:22:21','2023-01-05 08:22:21'),(1072,'spr-20230105-044535',1,NULL,664,9,1,270,0,'Cash',NULL,'2023-01-05 14:45:35','2023-01-05 14:45:35'),(1073,'spr-20230107-083725',1,NULL,665,9,1,1440,0,'Cash',NULL,'2023-01-07 06:37:25','2023-01-07 06:37:25'),(1074,'spr-20230107-115630',1,NULL,667,9,1,900,0,'Cash',NULL,'2023-01-07 09:56:30','2023-01-07 09:56:30'),(1075,'spr-20230107-045841',1,NULL,668,9,1,1500,0,'Cash',NULL,'2023-01-07 14:58:41','2023-01-07 14:58:41'),(1076,'spr-20230107-050019',1,NULL,669,9,1,500,665,'Cash',NULL,'2023-01-07 15:00:19','2023-01-07 15:00:19'),(1077,'spr-20230107-050218',1,NULL,568,9,1,200,115,'Cash',NULL,'2023-01-07 15:02:18','2023-01-07 15:02:18'),(1079,'spr-20230107-050504',1,NULL,671,9,1,195,0,'Cash',NULL,'2023-01-07 15:05:04','2023-01-07 15:05:04'),(1080,'spr-20230107-050550',1,NULL,598,9,1,200,200,'Cash',NULL,'2023-01-07 15:05:50','2023-01-07 15:05:50'),(1081,'spr-20230108-085607',1,NULL,674,9,1,825,0,'Cash',NULL,'2023-01-08 06:56:07','2023-01-08 06:56:07'),(1082,'spr-20230108-090847',1,NULL,673,9,1,550,0,'Cash',NULL,'2023-01-08 07:08:47','2023-01-08 07:08:47'),(1083,'spr-20230108-100006',1,NULL,676,9,1,80,0,'Cash',NULL,'2023-01-08 08:00:06','2023-01-08 08:00:06'),(1084,'spr-20230108-051146',1,NULL,663,9,1,2450,0,'Cash',NULL,'2023-01-08 15:11:46','2023-01-08 15:11:46'),(1085,'spr-20230109-022925',1,NULL,678,9,1,35,0,'Cash',NULL,'2023-01-09 12:29:25','2023-01-09 12:29:25'),(1086,'spr-20230109-061338',1,NULL,679,9,1,2500,450,'Cash',NULL,'2023-01-09 16:13:38','2023-01-09 16:13:38'),(1087,'spr-20230109-061440',1,NULL,680,9,1,70,0,'Cash',NULL,'2023-01-09 16:14:40','2023-01-09 16:14:40'),(1088,'spr-20230109-061624',1,NULL,681,9,1,290,0,'Cash',NULL,'2023-01-09 16:16:24','2023-01-09 16:16:24'),(1089,'spr-20230110-014927',1,NULL,683,9,1,70,0,'Cash',NULL,'2023-01-10 11:49:27','2023-01-10 11:49:27'),(1090,'spr-20230110-045912',1,NULL,684,9,1,145,0,'Cash',NULL,'2023-01-10 14:59:12','2023-01-10 14:59:12'),(1091,'spr-20230110-050413',1,NULL,686,9,1,490,0,'Cash',NULL,'2023-01-10 15:04:13','2023-01-10 15:04:13'),(1092,'spr-20230110-050501',1,NULL,687,9,1,650,0,'Cash',NULL,'2023-01-10 15:05:01','2023-01-10 15:05:01'),(1093,'spr-20230110-050705',1,NULL,688,9,1,55,0,'Cash',NULL,'2023-01-10 15:07:05','2023-01-10 15:07:05'),(1094,'spr-20230110-051108',1,NULL,689,9,1,965,0,'Cash',NULL,'2023-01-10 15:11:08','2023-01-10 15:11:08'),(1095,'spr-20230110-051631',1,NULL,690,9,1,1030,850,'Cash',NULL,'2023-01-10 15:16:31','2023-01-10 15:16:31'),(1096,'spr-20230110-052856',1,NULL,568,9,1,115,0,'Cash',NULL,'2023-01-10 15:28:56','2023-01-10 15:28:56'),(1097,'spr-20230111-023412',1,NULL,692,9,1,35,0,'Cash',NULL,'2023-01-11 12:34:12','2023-01-11 12:34:12'),(1098,'spr-20230111-050054',1,NULL,693,9,1,105,0,'Cash',NULL,'2023-01-11 15:00:54','2023-01-11 15:00:54'),(1099,'spr-20230111-050431',1,NULL,694,9,1,315,100,'Cash',NULL,'2023-01-11 15:04:31','2023-01-11 15:04:31'),(1100,'spr-20230111-050657',1,NULL,695,9,1,310,0,'Cash',NULL,'2023-01-11 15:06:57','2023-01-11 15:06:57'),(1101,'spr-20230111-051129',1,NULL,696,9,1,490,0,'Cash',NULL,'2023-01-11 15:11:29','2023-01-11 15:11:29'),(1102,'spr-20230111-051328',1,NULL,697,9,1,110,0,'Cash',NULL,'2023-01-11 15:13:28','2023-01-11 15:13:28'),(1103,'spr-20230111-051512',1,NULL,698,9,1,805,0,'Cash',NULL,'2023-01-11 15:15:12','2023-01-11 15:15:12'),(1104,'spr-20230111-051629',1,NULL,699,9,1,965,0,'Cash',NULL,'2023-01-11 15:16:29','2023-01-11 15:16:29'),(1105,'spr-20230111-051858',1,NULL,641,9,1,174,0,'Cash',NULL,'2023-01-11 15:18:58','2023-01-11 15:18:58'),(1106,'spr-20230112-012727',1,NULL,532,9,1,100,165,'Cash',NULL,'2023-01-12 11:27:27','2023-01-12 11:27:27'),(1107,'spr-20230112-040943',1,NULL,702,9,1,450,100,'Cash',NULL,'2023-01-12 14:09:43','2023-01-12 14:09:43'),(1108,'spr-20230112-045122',1,NULL,703,9,1,255,0,'Cash',NULL,'2023-01-12 14:51:22','2023-01-12 14:51:22'),(1109,'spr-20230112-045433',1,NULL,704,9,1,180,0,'Cash',NULL,'2023-01-12 14:54:33','2023-01-12 14:54:33'),(1110,'spr-20230114-044712',1,NULL,599,9,1,70,0,'Cash',NULL,'2023-01-14 14:47:12','2023-01-14 14:47:12'),(1111,'spr-20230114-054807',1,NULL,677,9,1,750,0,'Cash',NULL,'2023-01-14 15:48:07','2023-01-14 15:48:07'),(1112,'spr-20230115-043812',1,NULL,707,9,1,1200,0,'Cash',NULL,'2023-01-15 14:38:12','2023-01-15 14:38:12'),(1113,'spr-20230115-044854',1,NULL,708,9,1,55,0,'Cash',NULL,'2023-01-15 14:48:54','2023-01-15 14:48:54'),(1114,'spr-20230115-044931',1,NULL,709,9,1,275,0,'Cash',NULL,'2023-01-15 14:49:31','2023-01-15 14:49:31'),(1115,'spr-20230115-045115',1,NULL,710,9,1,165,0,'Cash',NULL,'2023-01-15 14:51:15','2023-01-15 14:51:15'),(1116,'spr-20230115-045222',1,NULL,711,9,1,185,0,'Cash',NULL,'2023-01-15 14:52:22','2023-01-15 14:52:22'),(1117,'spr-20230115-045905',1,NULL,712,9,1,150,0,'Cash',NULL,'2023-01-15 14:59:05','2023-01-15 14:59:05'),(1118,'spr-20230115-050022',1,NULL,604,9,1,140,0,'Cash',NULL,'2023-01-15 15:00:22','2023-01-15 15:00:22'),(1119,'spr-20230115-050148',1,NULL,690,9,1,850,0,'Cash',NULL,'2023-01-15 15:01:48','2023-01-15 15:01:48'),(1120,'spr-20230116-043631',1,NULL,713,9,1,1500,0,'Cash',NULL,'2023-01-16 14:36:31','2023-01-16 14:36:31'),(1121,'spr-20230116-043955',1,NULL,714,9,1,310,0,'Cash',NULL,'2023-01-16 14:39:55','2023-01-16 14:39:55'),(1122,'spr-20230116-044306',1,NULL,715,9,1,480,0,'Cash',NULL,'2023-01-16 14:43:06','2023-01-16 14:43:06'),(1123,'spr-20230116-044649',1,NULL,716,9,1,185,0,'Cash',NULL,'2023-01-16 14:46:49','2023-01-16 14:46:49'),(1124,'spr-20230116-044843',1,NULL,679,9,1,450,0,'Cash',NULL,'2023-01-16 14:48:43','2023-01-16 14:48:43'),(1125,'spr-20230116-044903',1,NULL,650,9,1,520,0,'Cash',NULL,'2023-01-16 14:49:03','2023-01-16 14:49:03'),(1127,'spr-20230117-123828',1,NULL,718,9,1,275,0,'Cash',NULL,'2023-01-17 10:38:28','2023-01-17 10:38:28'),(1128,'spr-20230117-013031',1,NULL,719,9,1,535,0,'Cash',NULL,'2023-01-17 11:30:31','2023-01-17 11:30:31'),(1129,'spr-20230117-013156',1,NULL,720,9,1,190,0,'Cash',NULL,'2023-01-17 11:31:56','2023-01-17 11:31:56'),(1130,'spr-20230117-013405',1,NULL,721,9,1,835,0,'Cash',NULL,'2023-01-17 11:34:05','2023-01-17 11:34:05'),(1131,'spr-20230117-013849',1,NULL,722,9,1,110,0,'Cash',NULL,'2023-01-17 11:38:49','2023-01-17 11:38:49'),(1132,'spr-20230117-025904',1,NULL,723,9,1,540,0,'Cash',NULL,'2023-01-17 12:59:04','2023-01-17 12:59:04'),(1133,'spr-20230117-042330',1,NULL,724,9,1,3155,0,'Cash',NULL,'2023-01-17 14:23:30','2023-01-17 14:23:30'),(1134,'spr-20230119-010749',1,NULL,705,9,1,450,0,'Cash',NULL,'2023-01-19 11:07:49','2023-01-19 11:07:49'),(1135,'spr-20230119-010805',1,NULL,706,9,1,2735,0,'Cash',NULL,'2023-01-19 11:08:05','2023-01-19 11:08:05'),(1136,'spr-20230119-011231',1,NULL,726,9,1,500,410,'Cash',NULL,'2023-01-19 11:12:31','2023-01-19 11:12:31'),(1137,'spr-20230119-013640',1,NULL,727,9,1,110,0,'Cash',NULL,'2023-01-19 11:36:40','2023-01-19 11:36:40'),(1138,'spr-20230119-013841',1,NULL,728,9,1,135,0,'Cash',NULL,'2023-01-19 11:38:41','2023-01-19 11:38:41'),(1139,'spr-20230121-101551',1,NULL,729,9,1,200,0,'Cash',NULL,'2023-01-21 08:15:51','2023-01-21 08:15:51'),(1140,'spr-20230121-102132',1,NULL,730,9,1,310,0,'Cash',NULL,'2023-01-21 08:21:32','2023-01-21 08:21:32'),(1141,'spr-20230121-102905',1,NULL,731,9,1,2600,0,'Cash',NULL,'2023-01-21 08:29:05','2023-01-21 08:29:05'),(1142,'spr-20230121-104314',1,NULL,733,9,1,35,0,'Cash',NULL,'2023-01-21 08:43:14','2023-01-21 08:43:14'),(1143,'spr-20230121-112024',1,NULL,734,9,1,70,0,'Cash',NULL,'2023-01-21 09:20:24','2023-01-21 09:20:24'),(1144,'spr-20230121-041455',1,NULL,736,9,1,110,0,'Cash',NULL,'2023-01-21 14:14:55','2023-01-21 14:14:55'),(1145,'spr-20230122-082148',1,NULL,737,9,1,240,0,'Cash',NULL,'2023-01-22 06:21:48','2023-01-22 06:21:48'),(1146,'spr-20230122-112059',1,NULL,738,9,1,630,0,'Cash',NULL,'2023-01-22 09:20:59','2023-01-22 09:20:59'),(1147,'spr-20230122-040052',1,NULL,739,9,1,220,0,'Cash',NULL,'2023-01-22 14:00:52','2023-01-22 14:00:52'),(1148,'spr-20230123-115448',1,NULL,741,9,1,500,0,'Cash',NULL,'2023-01-23 09:54:48','2023-01-23 09:54:48'),(1149,'spr-20230123-022037',1,NULL,726,9,1,410,0,'Cash',NULL,'2023-01-23 12:20:37','2023-01-23 12:20:37'),(1150,'spr-20230124-110213',1,NULL,742,9,1,55,0,'Cash',NULL,'2023-01-24 09:02:13','2023-01-24 09:02:13'),(1151,'spr-20230124-122246',1,NULL,743,9,1,150,0,'Cash',NULL,'2023-01-24 10:22:46','2023-01-24 10:22:46'),(1152,'spr-20230124-011041',1,NULL,744,9,1,140,0,'Cash',NULL,'2023-01-24 11:10:41','2023-01-24 11:10:41'),(1153,'spr-20230124-032158',1,NULL,745,9,1,225,0,'Cash',NULL,'2023-01-24 13:21:58','2023-01-24 13:21:58'),(1154,'spr-20230124-043654',1,NULL,746,9,1,300,500,'Cash',NULL,'2023-01-24 14:36:54','2023-01-24 14:36:54'),(1155,'spr-20230124-081448',1,NULL,748,9,1,145,0,'Cash',NULL,'2023-01-24 18:14:48','2023-01-24 18:14:48'),(1156,'spr-20230124-081640',1,NULL,749,9,1,200,0,'Cash',NULL,'2023-01-24 18:16:40','2023-01-24 18:16:40'),(1157,'spr-20230125-115728',1,NULL,750,9,1,75,0,'Cash',NULL,'2023-01-25 09:57:28','2023-01-25 09:57:28'),(1158,'spr-20230125-115829',1,NULL,691,9,1,300,150,'Cash',NULL,'2023-01-25 09:58:29','2023-01-25 09:58:29'),(1160,'spr-20230125-122532',1,NULL,752,9,1,500,400,'Cash',NULL,'2023-01-25 10:25:32','2023-01-25 10:25:32'),(1161,'spr-20230126-021448',1,NULL,735,9,1,550,0,'Cash',NULL,'2023-01-26 12:14:48','2023-01-26 12:14:48'),(1162,'spr-20230126-022021',1,NULL,691,9,1,150,0,'Cash',NULL,'2023-01-26 12:20:21','2023-01-26 12:20:21'),(1163,'spr-20230126-022838',1,NULL,669,9,1,300,365,'Cash',NULL,'2023-01-26 12:28:38','2023-01-26 12:28:38'),(1164,'spr-20230126-024104',1,NULL,432,9,1,250,370,'Cash',NULL,'2023-01-26 12:41:04','2023-01-26 12:41:04'),(1165,'spr-20230126-024248',1,NULL,662,9,1,12070,0,'Cash',NULL,'2023-01-26 12:42:48','2023-01-26 12:42:48'),(1166,'spr-20230126-073054',1,NULL,725,9,1,305,0,'Cash',NULL,'2023-01-26 17:30:54','2023-01-26 17:30:54'),(1167,'spr-20230129-082026',1,NULL,753,9,1,945,0,'Cash',NULL,'2023-01-29 06:20:26','2023-01-29 06:20:26'),(1168,'spr-20230129-082546',1,NULL,755,9,1,110,0,'Cash',NULL,'2023-01-29 06:25:46','2023-01-29 06:25:46'),(1169,'spr-20230129-082753',1,NULL,756,9,1,360,0,'Cash',NULL,'2023-01-29 06:27:53','2023-01-29 06:27:53'),(1170,'spr-20230129-082930',1,NULL,757,9,1,310,0,'Cash',NULL,'2023-01-29 06:29:30','2023-01-29 06:29:30'),(1171,'spr-20230129-083037',1,NULL,758,9,1,70,0,'Cash',NULL,'2023-01-29 06:30:37','2023-01-29 06:30:37'),(1172,'spr-20230129-061608',1,NULL,759,9,1,315,0,'Cash',NULL,'2023-01-29 16:16:08','2023-01-29 16:16:08'),(1173,'spr-20230129-061709',1,NULL,760,9,1,115,0,'Cash',NULL,'2023-01-29 16:17:09','2023-01-29 16:17:09'),(1174,'spr-20230130-123551',1,NULL,761,9,1,1085,0,'Cash',NULL,'2023-01-30 10:35:51','2023-01-30 10:35:51'),(1175,'spr-20230130-022729',1,NULL,762,9,1,605,0,'Cash',NULL,'2023-01-30 12:27:29','2023-01-30 12:27:29'),(1176,'spr-20230131-053205',1,NULL,763,9,1,550,0,'Cash',NULL,'2023-01-31 15:32:05','2023-01-31 15:32:05'),(1177,'spr-20230131-053636',1,NULL,764,9,1,300,2525,'Cash',NULL,'2023-01-31 15:36:36','2023-01-31 15:36:36'),(1178,'spr-20230201-014802',1,NULL,765,9,1,55,0,'Cash',NULL,'2023-02-01 11:48:02','2023-02-01 11:48:02'),(1179,'spr-20230201-023541',1,NULL,766,9,1,460,0,'Cash',NULL,'2023-02-01 12:35:41','2023-02-01 12:35:41'),(1180,'spr-20230201-032948',1,NULL,767,9,1,55,0,'Cash',NULL,'2023-02-01 13:29:48','2023-02-01 13:29:48'),(1181,'spr-20230201-042104',1,NULL,768,9,1,600,0,'Cash',NULL,'2023-02-01 14:21:04','2023-02-01 14:21:04'),(1182,'spr-20230202-012707',1,NULL,702,9,1,100,0,'Cash',NULL,'2023-02-02 11:27:07','2023-02-02 11:27:07'),(1183,'spr-20230202-012752',1,NULL,669,9,1,365,0,'Cash',NULL,'2023-02-02 11:27:52','2023-02-02 11:27:52'),(1184,'spr-20230202-070158',1,NULL,432,9,1,150,220,'Cash',NULL,'2023-02-02 17:01:58','2023-02-02 17:01:58'),(1185,'spr-20230207-092156',1,NULL,772,9,1,435,0,'Cash',NULL,'2023-02-07 07:21:56','2023-02-07 07:21:56'),(1186,'spr-20230207-092855',1,NULL,773,9,1,525,0,'Cash',NULL,'2023-02-07 07:28:55','2023-02-07 07:28:55'),(1187,'spr-20230207-070531',1,NULL,774,9,1,350,0,'Cash',NULL,'2023-02-07 17:05:31','2023-02-07 17:05:31'),(1188,'spr-20230207-070825',1,NULL,764,9,1,450,2075,'Cash',NULL,'2023-02-07 17:08:25','2023-02-07 17:08:25'),(1189,'spr-20230208-051304',1,NULL,775,9,1,110,0,'Cash',NULL,'2023-02-08 15:13:04','2023-02-08 15:13:04'),(1190,'spr-20230208-051340',1,NULL,776,9,1,110,0,'Cash',NULL,'2023-02-08 15:13:40','2023-02-08 15:13:40'),(1191,'spr-20230208-061948',1,NULL,764,9,1,450,1625,'Cash',NULL,'2023-02-08 16:19:48','2023-02-08 16:19:48'),(1192,'spr-20230208-062011',1,NULL,747,9,1,100,175,'Cash',NULL,'2023-02-08 16:20:11','2023-02-08 16:20:11'),(1193,'spr-20230208-062049',1,NULL,770,9,1,630,300,'Cash',NULL,'2023-02-08 16:20:49','2023-02-08 16:20:49'),(1194,'spr-20230208-062136',1,NULL,740,9,1,2145,0,'Cash',NULL,'2023-02-08 16:21:36','2023-02-08 16:21:36'),(1195,'spr-20230208-062537',1,NULL,342,9,1,30,0,'Cash',NULL,'2023-02-08 16:25:37','2023-02-08 16:25:37'),(1196,'spr-20230208-071920',1,NULL,777,9,1,75,0,'Cash',NULL,'2023-02-08 17:19:20','2023-02-08 17:19:20'),(1197,'spr-20230209-103630',1,NULL,701,9,1,150,120,'Cash',NULL,'2023-02-09 08:36:30','2023-02-09 08:36:30'),(1198,'spr-20230209-105112',1,NULL,622,9,1,493,0,'Cash',NULL,'2023-02-09 08:51:12','2023-02-09 08:51:12'),(1199,'spr-20230209-105355',1,NULL,539,9,1,150,0,'Cash',NULL,'2023-02-09 08:53:55','2023-02-09 08:53:55'),(1200,'spr-20230212-114957',1,NULL,780,9,1,140,300,'Cash',NULL,'2023-02-12 09:49:57','2023-02-12 09:49:57'),(1201,'spr-20230212-120513',1,NULL,781,9,1,415,0,'Cash',NULL,'2023-02-12 10:05:13','2023-02-12 10:05:13'),(1202,'spr-20230213-043604',1,NULL,771,9,1,495,0,'Cash',NULL,'2023-02-13 14:36:04','2023-02-13 14:36:04'),(1203,'spr-20230213-043817',1,NULL,779,9,1,310,0,'Cash',NULL,'2023-02-13 14:38:17','2023-02-13 14:38:17'),(1204,'spr-20230213-043924',1,NULL,764,9,1,1000,625,'Cash',NULL,'2023-02-13 14:39:24','2023-02-13 14:39:24'),(1205,'spr-20230214-065308',1,NULL,784,9,1,295,0,'Cash',NULL,'2023-02-14 16:53:08','2023-02-14 16:53:08'),(1206,'spr-20230214-065450',1,NULL,785,9,1,165,0,'Cash',NULL,'2023-02-14 16:54:50','2023-02-14 16:54:50'),(1207,'spr-20230214-065926',1,NULL,786,9,1,110,0,'Cash',NULL,'2023-02-14 16:59:26','2023-02-14 16:59:26'),(1208,'spr-20230215-052334',1,NULL,788,9,1,300,0,'Cash',NULL,'2023-02-15 15:23:34','2023-02-15 15:23:34'),(1209,'spr-20230215-052452',1,NULL,789,9,1,180,0,'Cash',NULL,'2023-02-15 15:24:52','2023-02-15 15:24:52'),(1210,'spr-20230215-052619',1,NULL,790,9,1,75,0,'Cash',NULL,'2023-02-15 15:26:19','2023-02-15 15:26:19'),(1211,'spr-20230215-052710',1,NULL,791,9,1,105,0,'Cash',NULL,'2023-02-15 15:27:10','2023-02-15 15:27:10'),(1212,'spr-20230216-033156',1,NULL,792,9,1,165,0,'Cash',NULL,'2023-02-16 13:31:56','2023-02-16 13:31:56'),(1213,'spr-20230216-033422',1,NULL,793,9,1,755,0,'Cash',NULL,'2023-02-16 13:34:22','2023-02-16 13:34:22'),(1214,'spr-20230216-033509',1,NULL,794,9,1,325,0,'Cash',NULL,'2023-02-16 13:35:09','2023-02-16 13:35:09'),(1215,'spr-20230216-033918',1,NULL,795,9,1,790,0,'Cash',NULL,'2023-02-16 13:39:18','2023-02-16 13:39:18'),(1217,'spr-20230218-024626',1,NULL,797,9,1,930,945,'Cash',NULL,'2023-02-18 12:46:26','2023-02-18 12:46:26'),(1218,'spr-20230219-101059',1,NULL,770,9,1,153,147,'Cash',NULL,'2023-02-19 08:10:59','2023-02-19 08:10:59'),(1219,'spr-20230219-015028',1,NULL,798,9,1,70,0,'Cash',NULL,'2023-02-19 11:50:28','2023-02-19 11:50:28'),(1220,'spr-20230220-014311',1,NULL,799,9,1,295,0,'Cash',NULL,'2023-02-20 11:43:11','2023-02-20 11:43:11'),(1221,'spr-20230220-042047',1,NULL,754,9,1,1000,195,'Cash',NULL,'2023-02-20 14:20:47','2023-02-20 14:20:47'),(1222,'spr-20230220-042106',1,NULL,701,9,1,100,20,'Cash',NULL,'2023-02-20 14:21:06','2023-02-20 14:21:06'),(1223,'spr-20230221-031539',1,NULL,802,9,1,180,0,'Cash',NULL,'2023-02-21 13:15:39','2023-02-21 13:15:39'),(1224,'spr-20230221-042528',1,NULL,803,9,1,35,0,'Cash',NULL,'2023-02-21 14:25:28','2023-02-21 14:25:28'),(1225,'spr-20230221-045707',1,NULL,804,9,1,350,0,'Cash',NULL,'2023-02-21 14:57:07','2023-02-21 14:57:07'),(1226,'spr-20230221-050857',1,NULL,805,9,1,130,0,'Cash',NULL,'2023-02-21 15:08:57','2023-02-21 15:08:57'),(1227,'spr-20230222-015247',1,NULL,806,9,1,55,0,'Cash',NULL,'2023-02-22 11:52:47','2023-02-22 11:52:47'),(1228,'spr-20230222-025640',1,NULL,807,9,1,65,0,'Cash',NULL,'2023-02-22 12:56:40','2023-02-22 12:56:40'),(1229,'spr-20230222-064409',1,NULL,764,9,1,625,0,'Cash',NULL,'2023-02-22 16:44:09','2023-02-22 16:44:09'),(1230,'spr-20230222-071339',1,NULL,808,9,1,700,0,'Cash',NULL,'2023-02-22 17:13:39','2023-02-22 17:13:39'),(1231,'spr-20230223-123341',1,NULL,809,9,1,1095,2000,'Cash',NULL,'2023-02-23 10:33:41','2023-02-23 10:33:41'),(1232,'spr-20230223-123920',1,NULL,810,9,1,450,0,'Cash',NULL,'2023-02-23 10:39:20','2023-02-23 10:39:20'),(1233,'spr-20230223-035906',1,NULL,811,9,1,215,0,'Cash',NULL,'2023-02-23 13:59:06','2023-02-23 13:59:06'),(1234,'spr-20230228-115819',1,NULL,812,9,1,90,0,'Cash',NULL,'2023-02-28 09:58:19','2023-02-28 09:58:19'),(1235,'spr-20230228-115901',1,NULL,813,9,1,130,0,'Cash',NULL,'2023-02-28 09:59:01','2023-02-28 09:59:01'),(1236,'spr-20230228-120222',1,NULL,814,9,1,120,0,'Cash',NULL,'2023-02-28 10:02:22','2023-02-28 10:02:22'),(1237,'spr-20230228-121800',1,NULL,815,9,1,220,0,'Cash',NULL,'2023-02-28 10:18:00','2023-02-28 10:18:00'),(1241,'spr-20230228-035219',1,NULL,820,9,1,70,40,'Cash',NULL,'2023-02-28 13:52:19','2023-02-28 13:52:19'),(1242,'spr-20230228-035938',1,NULL,821,9,1,280,0,'Cash',NULL,'2023-02-28 13:59:38','2023-02-28 13:59:38'),(1243,'spr-20230228-040805',1,NULL,822,9,1,440,50,'Cash',NULL,'2023-02-28 14:08:05','2023-02-28 14:08:05'),(1244,'spr-20230228-053121',1,NULL,823,9,1,170,400,'Cash',NULL,'2023-02-28 15:31:21','2023-02-28 15:31:21'),(1245,'spr-20230228-055353',1,NULL,824,9,1,65,0,'Cash',NULL,'2023-02-28 15:53:53','2023-02-28 15:53:53'),(1246,'spr-20230228-061619',1,NULL,825,9,1,500,200,'Cash',NULL,'2023-02-28 16:16:19','2023-02-28 16:16:19'),(1247,'spr-20230228-063205',1,NULL,826,9,1,320,0,'Cash',NULL,'2023-02-28 16:32:05','2023-02-28 16:32:05'),(1248,'spr-20230301-033159',1,NULL,797,9,1,700,245,'Cash',NULL,'2023-03-01 13:31:59','2023-03-01 13:31:59'),(1249,'spr-20230302-101134',1,NULL,800,9,1,2660,0,'Cash',NULL,'2023-03-02 08:11:34','2023-03-02 08:11:34'),(1250,'spr-20230302-101215',1,NULL,782,9,1,240,0,'Cash',NULL,'2023-03-02 08:12:15','2023-03-02 08:12:15'),(1251,'spr-20230302-101330',1,NULL,752,9,1,400,0,'Cash',NULL,'2023-03-02 08:13:30','2023-03-02 08:13:30'),(1252,'spr-20230302-101626',1,NULL,746,9,1,500,0,'Cash',NULL,'2023-03-02 08:16:26','2023-03-02 08:16:26'),(1253,'spr-20230302-112146',1,NULL,694,9,1,100,0,'Cash',NULL,'2023-03-02 09:21:46','2023-03-02 09:21:46'),(1254,'spr-20230302-065752',1,NULL,825,9,1,200,0,'Cash',NULL,'2023-03-02 16:57:52','2023-03-02 16:57:52'),(1255,'spr-20230302-065839',1,NULL,656,9,1,360,0,'Cash',NULL,'2023-03-02 16:58:39','2023-03-02 16:58:39'),(1256,'spr-20230302-070009',1,NULL,809,9,1,500,1500,'Cash',NULL,'2023-03-02 17:00:09','2023-03-02 17:00:09'),(1257,'spr-20230302-070212',1,NULL,828,9,1,485,0,'Cash',NULL,'2023-03-02 17:02:12','2023-03-02 17:02:12'),(1258,'spr-20230305-030406',1,NULL,829,9,1,90,0,'Cash',NULL,'2023-03-05 13:04:06','2023-03-05 13:04:06'),(1259,'spr-20230305-030702',1,NULL,830,9,1,55,0,'Cash',NULL,'2023-03-05 13:07:02','2023-03-05 13:07:02'),(1260,'spr-20230305-030805',1,NULL,831,9,1,70,0,'Cash',NULL,'2023-03-05 13:08:05','2023-03-05 13:08:05'),(1261,'spr-20230305-040754',1,NULL,832,9,1,930,0,'Cash',NULL,'2023-03-05 14:07:54','2023-03-05 14:07:54'),(1262,'spr-20230306-121649',1,NULL,833,9,1,490,0,'Cash',NULL,'2023-03-06 10:16:49','2023-03-06 10:16:49'),(1263,'spr-20230306-122139',1,NULL,834,9,1,175,0,'Cash',NULL,'2023-03-06 10:21:39','2023-03-06 10:21:39'),(1264,'spr-20230306-021331',1,NULL,835,9,1,245,0,'Cash',NULL,'2023-03-06 12:13:31','2023-03-06 12:13:31'),(1265,'spr-20230308-055255',1,NULL,432,9,1,220,0,'Cash',NULL,'2023-03-08 15:52:55','2023-03-08 15:52:55'),(1266,'spr-20230308-055403',1,NULL,809,9,1,500,1000,'Cash',NULL,'2023-03-08 15:54:03','2023-03-08 15:54:03'),(1267,'spr-20230311-020913',1,NULL,797,9,1,245,0,'Cash',NULL,'2023-03-11 12:09:13','2023-03-11 12:09:13'),(1268,'spr-20230314-042845',1,NULL,836,9,1,300,380,'Cash',NULL,'2023-03-14 14:28:45','2023-03-14 14:28:45'),(1269,'spr-20230315-074025',1,NULL,839,9,1,660,400,'Cash',NULL,'2023-03-15 17:40:25','2023-03-15 17:40:25'),(1270,'spr-20230315-074318',1,NULL,841,9,1,195,0,'Cash',NULL,'2023-03-15 17:43:18','2023-03-15 17:43:18'),(1271,'spr-20230315-074356',1,NULL,701,9,1,20,0,'Cash',NULL,'2023-03-15 17:43:56','2023-03-15 17:43:56'),(1272,'spr-20230315-074425',1,NULL,532,9,1,165,0,'Cash',NULL,'2023-03-15 17:44:25','2023-03-15 17:44:25'),(1273,'spr-20230315-074455',1,NULL,809,9,1,500,500,'Cash',NULL,'2023-03-15 17:44:55','2023-03-15 17:44:55'),(1274,'spr-20230316-025020',1,NULL,842,9,1,425,0,'Cash',NULL,'2023-03-16 12:50:20','2023-03-16 12:50:20'),(1275,'spr-20230316-025557',1,NULL,843,9,1,500,1030,'Cash',NULL,'2023-03-16 12:55:57','2023-03-16 12:55:57'),(1276,'spr-20230316-025947',1,NULL,844,9,1,835,0,'Cash',NULL,'2023-03-16 12:59:47','2023-03-16 12:59:47'),(1277,'spr-20230318-013004',1,NULL,780,9,1,300,0,'Cash',NULL,'2023-03-18 11:30:04','2023-03-18 11:30:04'),(1278,'spr-20230318-014507',1,NULL,685,9,1,35,0,'Cash',NULL,'2023-03-18 11:45:07','2023-03-18 11:45:07'),(1279,'spr-20230318-014527',1,NULL,597,9,1,65,0,'Cash',NULL,'2023-03-18 11:45:27','2023-03-18 11:45:27'),(1281,'spr-20230318-070444',1,NULL,862,9,1,180,0,'Cash',NULL,'2023-03-18 17:04:44','2023-03-18 17:04:44'),(1282,'spr-20230319-090847',1,NULL,863,9,1,385,510,'Cash',NULL,'2023-03-19 07:08:47','2023-03-19 07:08:47'),(1283,'spr-20230319-091122',1,NULL,864,9,1,600,0,'Cash',NULL,'2023-03-19 07:11:22','2023-03-19 07:11:22'),(1284,'spr-20230319-091602',1,NULL,865,9,1,250,0,'Cash',NULL,'2023-03-19 07:16:02','2023-03-19 07:16:02'),(1295,'spr-20230430-115122',1,NULL,5,9,1,600,0,'Cash',NULL,'2023-04-30 08:51:22','2023-04-30 08:51:22'),(1296,'ppr-20230502-094054',30,8,NULL,NULL,1,199500,0,'Cash',NULL,'2023-05-02 06:40:54','2023-05-02 06:40:54'),(1297,'ppr-20230502-094906',30,9,NULL,NULL,1,27500,0,'Cash',NULL,'2023-05-02 06:49:06','2023-05-02 06:49:06'),(1298,'ppr-20230502-100249',1,10,NULL,NULL,1,102592,0,'Cash',NULL,'2023-05-02 07:02:49','2023-05-02 07:02:49'),(1299,'ppr-20230502-100554',1,11,NULL,NULL,1,209000,0,'Cash',NULL,'2023-05-02 07:05:54','2023-05-02 07:05:54'),(1300,'ppr-20230502-100554',1,11,NULL,NULL,1,209000,0,'Cash',NULL,'2023-05-02 07:05:54','2023-05-02 07:05:54'),(1301,'ppr-20230502-103645',1,11,NULL,NULL,1,-209000,0,'Cash',NULL,'2023-05-02 07:36:45','2023-05-02 07:36:45'),(1302,'ppr-20230502-103658',1,12,NULL,NULL,1,54370,0,'Cash',NULL,'2023-05-02 07:36:58','2023-05-02 07:36:58'),(1303,'ppr-20230502-104049',1,13,NULL,NULL,1,109540,0,'Cash',NULL,'2023-05-02 07:40:49','2023-05-02 07:40:49'),(1304,'ppr-20230502-112156',1,14,NULL,NULL,1,221200,0,'Cash',NULL,'2023-05-02 08:21:56','2023-05-02 08:21:56'),(1307,'ppr-20230502-030618',1,16,NULL,NULL,1,5000,122340,'Cash',NULL,'2023-05-02 12:06:18','2023-05-02 12:06:18'),(1308,'ppr-20230502-030637',1,16,NULL,NULL,1,5000,117340,'Cash',NULL,'2023-05-02 12:06:37','2023-05-02 12:06:37'),(1309,'ppr-20230502-030701',1,16,NULL,NULL,1,4000,113340,'Cash',NULL,'2023-05-02 12:07:01','2023-05-02 12:07:01'),(1310,'ppr-20230502-030721',1,16,NULL,NULL,1,5000,108340,'Cash',NULL,'2023-05-02 12:07:21','2023-05-02 12:07:21'),(1311,'ppr-20230502-030907',1,16,NULL,NULL,1,3000,105340,'Cash',NULL,'2023-05-02 12:09:07','2023-05-02 12:09:07'),(1312,'ppr-20230502-031007',1,16,NULL,NULL,1,70000,35340,'Cash',NULL,'2023-05-02 12:10:07','2023-05-02 12:10:07'),(1313,'ppr-20230503-105308',32,19,NULL,NULL,1,6180,0,'Cash',NULL,'2023-05-03 07:53:08','2023-05-03 07:53:08');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payrolls`
--

DROP TABLE IF EXISTS `payrolls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payrolls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `paying_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payrolls`
--

LOCK TABLES `payrolls` WRITE;
/*!40000 ALTER TABLE `payrolls` DISABLE KEYS */;
/*!40000 ALTER TABLE `payrolls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES (4,'products-edit','web','2018-06-03 01:00:09','2018-06-03 01:00:09'),(5,'products-delete','web','2018-06-03 22:54:22','2018-06-03 22:54:22'),(6,'products-add','web','2018-06-04 00:34:14','2018-06-04 00:34:14'),(7,'products-index','web','2018-06-04 03:34:27','2018-06-04 03:34:27'),(8,'purchases-index','web','2018-06-04 08:03:19','2018-06-04 08:03:19'),(9,'purchases-add','web','2018-06-04 08:12:25','2018-06-04 08:12:25'),(10,'purchases-edit','web','2018-06-04 09:47:36','2018-06-04 09:47:36'),(11,'purchases-delete','web','2018-06-04 09:47:36','2018-06-04 09:47:36'),(12,'sales-index','web','2018-06-04 10:49:08','2018-06-04 10:49:08'),(13,'sales-add','web','2018-06-04 10:49:52','2018-06-04 10:49:52'),(14,'sales-edit','web','2018-06-04 10:49:52','2018-06-04 10:49:52'),(15,'sales-delete','web','2018-06-04 10:49:53','2018-06-04 10:49:53'),(16,'quotes-index','web','2018-06-04 22:05:10','2018-06-04 22:05:10'),(17,'quotes-add','web','2018-06-04 22:05:10','2018-06-04 22:05:10'),(18,'quotes-edit','web','2018-06-04 22:05:10','2018-06-04 22:05:10'),(19,'quotes-delete','web','2018-06-04 22:05:10','2018-06-04 22:05:10'),(20,'transfers-index','web','2018-06-04 22:30:03','2018-06-04 22:30:03'),(21,'transfers-add','web','2018-06-04 22:30:03','2018-06-04 22:30:03'),(22,'transfers-edit','web','2018-06-04 22:30:03','2018-06-04 22:30:03'),(23,'transfers-delete','web','2018-06-04 22:30:03','2018-06-04 22:30:03'),(24,'returns-index','web','2018-06-04 22:50:24','2018-06-04 22:50:24'),(25,'returns-add','web','2018-06-04 22:50:24','2018-06-04 22:50:24'),(26,'returns-edit','web','2018-06-04 22:50:25','2018-06-04 22:50:25'),(27,'returns-delete','web','2018-06-04 22:50:25','2018-06-04 22:50:25'),(28,'customers-index','web','2018-06-04 23:15:54','2018-06-04 23:15:54'),(29,'customers-add','web','2018-06-04 23:15:55','2018-06-04 23:15:55'),(30,'customers-edit','web','2018-06-04 23:15:55','2018-06-04 23:15:55'),(31,'customers-delete','web','2018-06-04 23:15:55','2018-06-04 23:15:55'),(32,'suppliers-index','web','2018-06-04 23:40:12','2018-06-04 23:40:12'),(33,'suppliers-add','web','2018-06-04 23:40:12','2018-06-04 23:40:12'),(34,'suppliers-edit','web','2018-06-04 23:40:12','2018-06-04 23:40:12'),(35,'suppliers-delete','web','2018-06-04 23:40:12','2018-06-04 23:40:12'),(36,'product-report','web','2018-06-24 23:05:33','2018-06-24 23:05:33'),(37,'purchase-report','web','2018-06-24 23:24:56','2018-06-24 23:24:56'),(38,'sale-report','web','2018-06-24 23:33:13','2018-06-24 23:33:13'),(39,'customer-report','web','2018-06-24 23:36:51','2018-06-24 23:36:51'),(40,'due-report','web','2018-06-24 23:39:52','2018-06-24 23:39:52'),(41,'users-index','web','2018-06-25 00:00:10','2018-06-25 00:00:10'),(42,'users-add','web','2018-06-25 00:00:10','2018-06-25 00:00:10'),(43,'users-edit','web','2018-06-25 00:01:30','2018-06-25 00:01:30'),(44,'users-delete','web','2018-06-25 00:01:30','2018-06-25 00:01:30'),(45,'profit-loss','web','2018-07-14 21:50:05','2018-07-14 21:50:05'),(46,'best-seller','web','2018-07-14 22:01:38','2018-07-14 22:01:38'),(47,'daily-sale','web','2018-07-14 22:24:21','2018-07-14 22:24:21'),(48,'monthly-sale','web','2018-07-14 22:30:41','2018-07-14 22:30:41'),(49,'daily-purchase','web','2018-07-14 22:36:46','2018-07-14 22:36:46'),(50,'monthly-purchase','web','2018-07-14 22:48:17','2018-07-14 22:48:17'),(51,'payment-report','web','2018-07-14 23:10:41','2018-07-14 23:10:41'),(52,'warehouse-stock-report','web','2018-07-14 23:16:55','2018-07-14 23:16:55'),(53,'product-qty-alert','web','2018-07-14 23:33:21','2018-07-14 23:33:21'),(54,'supplier-report','web','2018-07-30 03:00:01','2018-07-30 03:00:01'),(55,'expenses-index','web','2018-09-05 01:07:10','2018-09-05 01:07:10'),(56,'expenses-add','web','2018-09-05 01:07:10','2018-09-05 01:07:10'),(57,'expenses-edit','web','2018-09-05 01:07:10','2018-09-05 01:07:10'),(58,'expenses-delete','web','2018-09-05 01:07:11','2018-09-05 01:07:11'),(59,'general_setting','web','2018-10-19 23:10:04','2018-10-19 23:10:04'),(60,'mail_setting','web','2018-10-19 23:10:04','2018-10-19 23:10:04'),(61,'pos_setting','web','2018-10-19 23:10:04','2018-10-19 23:10:04'),(62,'hrm_setting','web','2019-01-02 10:30:23','2019-01-02 10:30:23'),(63,'purchase-return-index','web','2019-01-02 21:45:14','2019-01-02 21:45:14'),(64,'purchase-return-add','web','2019-01-02 21:45:14','2019-01-02 21:45:14'),(65,'purchase-return-edit','web','2019-01-02 21:45:14','2019-01-02 21:45:14'),(66,'purchase-return-delete','web','2019-01-02 21:45:14','2019-01-02 21:45:14'),(67,'account-index','web','2019-01-02 22:06:13','2019-01-02 22:06:13'),(68,'balance-sheet','web','2019-01-02 22:06:14','2019-01-02 22:06:14'),(69,'account-statement','web','2019-01-02 22:06:14','2019-01-02 22:06:14'),(70,'department','web','2019-01-02 22:30:01','2019-01-02 22:30:01'),(71,'attendance','web','2019-01-02 22:30:01','2019-01-02 22:30:01'),(72,'payroll','web','2019-01-02 22:30:01','2019-01-02 22:30:01'),(73,'employees-index','web','2019-01-02 22:52:19','2019-01-02 22:52:19'),(74,'employees-add','web','2019-01-02 22:52:19','2019-01-02 22:52:19'),(75,'employees-edit','web','2019-01-02 22:52:19','2019-01-02 22:52:19'),(76,'employees-delete','web','2019-01-02 22:52:19','2019-01-02 22:52:19'),(77,'user-report','web','2019-01-16 06:48:18','2019-01-16 06:48:18'),(78,'stock_count','web','2019-02-17 10:32:01','2019-02-17 10:32:01'),(79,'adjustment','web','2019-02-17 10:32:02','2019-02-17 10:32:02'),(80,'sms_setting','web','2019-02-22 05:18:03','2019-02-22 05:18:03'),(81,'create_sms','web','2019-02-22 05:18:03','2019-02-22 05:18:03'),(82,'print_barcode','web','2019-03-07 05:02:19','2019-03-07 05:02:19'),(83,'empty_database','web','2019-03-07 05:02:19','2019-03-07 05:02:19'),(84,'customer_group','web','2019-03-07 05:37:15','2019-03-07 05:37:15'),(85,'unit','web','2019-03-07 05:37:15','2019-03-07 05:37:15'),(86,'tax','web','2019-03-07 05:37:15','2019-03-07 05:37:15'),(87,'gift_card','web','2019-03-07 06:29:38','2019-03-07 06:29:38'),(88,'coupon','web','2019-03-07 06:29:38','2019-03-07 06:29:38'),(89,'holiday','web','2019-10-19 08:57:15','2019-10-19 08:57:15'),(90,'warehouse-report','web','2019-10-22 06:00:23','2019-10-22 06:00:23'),(91,'warehouse','web','2020-02-26 06:47:32','2020-02-26 06:47:32'),(92,'brand','web','2020-02-26 06:59:59','2020-02-26 06:59:59'),(93,'billers-index','web','2020-02-26 07:11:15','2020-02-26 07:11:15'),(94,'billers-add','web','2020-02-26 07:11:15','2020-02-26 07:11:15'),(95,'billers-edit','web','2020-02-26 07:11:15','2020-02-26 07:11:15'),(96,'billers-delete','web','2020-02-26 07:11:15','2020-02-26 07:11:15'),(97,'money-transfer','web','2020-03-02 05:41:48','2020-03-02 05:41:48'),(98,'category','web','2020-07-13 12:13:16','2020-07-13 12:13:16'),(99,'delivery','web','2020-07-13 12:13:16','2020-07-13 12:13:16'),(100,'send_notification','web','2020-10-31 06:21:31','2020-10-31 06:21:31'),(101,'today_sale','web','2020-10-31 06:57:04','2020-10-31 06:57:04'),(102,'today_profit','web','2020-10-31 06:57:04','2020-10-31 06:57:04'),(103,'currency','web','2020-11-09 00:23:11','2020-11-09 00:23:11'),(104,'backup_database','web','2020-11-15 00:16:55','2020-11-15 00:16:55');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_setting`
--

DROP TABLE IF EXISTS `pos_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_setting` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `biller_id` int(11) NOT NULL,
  `product_number` int(11) NOT NULL,
  `keybord_active` tinyint(1) NOT NULL,
  `stripe_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_secret_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `pos_setting_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_setting`
--

LOCK TABLES `pos_setting` WRITE;
/*!40000 ALTER TABLE `pos_setting` DISABLE KEYS */;
INSERT INTO `pos_setting` (`id`, `customer_id`, `warehouse_id`, `biller_id`, `product_number`, `keybord_active`, `stripe_public_key`, `stripe_secret_key`, `created_at`, `updated_at`) VALUES (1,1,2,1,4,0,'pk_test_ITN7KOYiIsHSCQ0UMRcgaYUB','sk_test_TtQQaawhEYRwa3mU9CzttrEy','2018-09-02 03:17:04','2023-03-19 10:43:42');
/*!40000 ALTER TABLE `pos_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_adjustments`
--

DROP TABLE IF EXISTS `product_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_adjustments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adjustment_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` double NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_adjustments`
--

LOCK TABLES `product_adjustments` WRITE;
/*!40000 ALTER TABLE `product_adjustments` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_adjustments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_purchases`
--

DROP TABLE IF EXISTS `product_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_purchases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `recieved` double NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `net_unit_cost` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_purchases`
--

LOCK TABLES `product_purchases` WRITE;
/*!40000 ALTER TABLE `product_purchases` DISABLE KEYS */;
INSERT INTO `product_purchases` (`id`, `purchase_id`, `product_id`, `variant_id`, `qty`, `recieved`, `purchase_unit_id`, `net_unit_cost`, `discount`, `tax_rate`, `tax`, `total`, `created_at`, `updated_at`) VALUES (8,8,11,NULL,300,300,1,45,0,0,0,13500,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(9,8,13,NULL,700,700,1,28,0,0,0,19600,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(10,8,14,NULL,300,300,1,70,0,0,0,21000,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(11,8,12,NULL,1800,1800,1,42,0,0,0,75600,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(12,8,6,NULL,150,150,1,65,0,0,0,9750,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(13,8,10,NULL,500,500,1,25,0,0,0,12500,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(14,8,9,NULL,600,600,1,15,0,0,0,9000,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(15,8,8,NULL,500,500,1,15,0,0,0,7500,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(16,8,7,NULL,50,50,1,110,0,0,0,5500,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(17,8,15,NULL,300,300,1,83,0,0,0,24900,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(18,9,16,NULL,20,20,12,1365,0,0,0,27300,'2023-05-02 06:48:45','2023-05-02 06:48:45'),(19,10,17,NULL,300,300,1,280,0,0,0,84000,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(20,10,18,NULL,40,40,1,96,0,0,0,3840,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(21,10,19,NULL,15,15,1,216,0,0,0,3240,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(22,10,20,NULL,9,9,1,384,0,0,0,3456,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(23,10,21,NULL,6,6,1,600,0,0,0,3600,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(24,10,22,NULL,4,4,1,864,0,0,0,3456,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(25,11,155,NULL,4,4,12,4300,0,0,0,17200,'2023-05-02 07:05:36','2023-05-02 07:05:36'),(26,11,156,NULL,45,45,12,3900,0,0,0,175500,'2023-05-02 07:05:36','2023-05-02 07:05:36'),(27,11,157,NULL,4,4,12,3900,0,0,0,15600,'2023-05-02 07:05:36','2023-05-02 07:05:36'),(28,12,166,NULL,28,28,12,975,0,0,0,27300,'2023-05-02 07:16:07','2023-05-02 07:16:07'),(29,12,169,NULL,5,5,12,1120,0,0,0,5600,'2023-05-02 07:16:07','2023-05-02 07:16:07'),(30,12,167,NULL,5,5,12,840,0,0,0,4200,'2023-05-02 07:16:07','2023-05-02 07:16:07'),(31,12,165,NULL,20,20,12,325,0,0,0,6500,'2023-05-02 07:16:07','2023-05-02 07:16:07'),(32,12,164,NULL,10,10,12,325,0,0,0,3250,'2023-05-02 07:16:07','2023-05-02 07:16:07'),(33,12,171,NULL,25,25,12,300,0,0,0,7500,'2023-05-02 07:16:07','2023-05-02 07:16:07'),(34,13,166,NULL,50,50,12,975,0,0,0,48750,'2023-05-02 07:40:40','2023-05-02 07:40:40'),(35,13,169,NULL,10,10,12,1120,0,0,0,11200,'2023-05-02 07:40:40','2023-05-02 07:40:40'),(36,13,167,NULL,20,20,12,840,0,0,0,16800,'2023-05-02 07:40:40','2023-05-02 07:40:40'),(37,13,165,NULL,40,40,12,325,0,0,0,13000,'2023-05-02 07:40:40','2023-05-02 07:40:40'),(38,13,172,NULL,20,20,12,325,0,0,0,6500,'2023-05-02 07:40:40','2023-05-02 07:40:40'),(39,13,171,NULL,15,15,12,310,0,0,0,4650,'2023-05-02 07:40:40','2023-05-02 07:40:40'),(40,13,170,NULL,24,24,1,250,0,0,0,6000,'2023-05-02 07:40:40','2023-05-02 07:40:40'),(41,13,168,NULL,48,48,1,55,0,0,0,2640,'2023-05-02 07:40:40','2023-05-02 07:40:40'),(42,14,102,NULL,71,71,1,950,0,0,0,67450,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(43,14,103,NULL,50,50,1,280,0,0,0,14000,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(44,14,90,NULL,104,104,7,1000,0,0,0,104000,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(45,14,50,NULL,10,10,14,1900,0,0,0,19000,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(46,14,51,NULL,10,10,14,800,0,0,0,8000,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(47,14,52,NULL,10,10,14,875,0,0,0,8750,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(57,15,179,NULL,6,6,12,160,0,0,0,960,'2023-05-02 09:04:16','2023-05-02 09:04:16'),(58,15,180,NULL,6,6,12,280,0,0,0,1680,'2023-05-02 09:04:16','2023-05-02 09:04:16'),(59,15,181,NULL,24,24,1,70,0,0,0,1680,'2023-05-02 09:04:16','2023-05-02 09:04:16'),(60,15,182,NULL,6,6,1,85,0,0,0,510,'2023-05-02 09:04:16','2023-05-02 09:04:16'),(61,15,183,NULL,40,40,12,250,0,0,0,10000,'2023-05-02 09:04:16','2023-05-02 09:04:16'),(62,15,186,NULL,400,400,1,8,0,0,0,3200,'2023-05-02 09:04:16','2023-05-02 09:04:16'),(63,15,187,NULL,400,400,1,9,0,0,0,3600,'2023-05-02 09:04:16','2023-05-02 09:04:16'),(64,15,184,NULL,190,190,12,100,0,0,0,19000,'2023-05-02 09:04:16','2023-05-02 09:04:16'),(65,15,185,NULL,59,59,12,82,0,0,0,4838,'2023-05-02 09:04:16','2023-05-02 09:04:16'),(66,16,30,NULL,500,500,1,12.4,0,0,0,6200,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(67,16,31,NULL,140,140,1,16.5,0,0,0,2310,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(68,16,32,NULL,200,200,1,18.6,0,0,0,3720,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(69,16,23,NULL,200,200,1,21.4,0,0,0,4280,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(70,16,24,NULL,30,30,1,105,0,0,0,3150,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(71,16,25,NULL,30,30,1,115,0,0,0,3450,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(72,16,27,NULL,200,200,1,3.25,0,0,0,650,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(73,16,29,NULL,200,200,1,5.1,0,0,0,1020,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(74,16,28,NULL,200,200,1,5.55,0,0,0,1110,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(75,16,26,NULL,200,200,1,6.85,0,0,0,1370,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(76,16,34,NULL,1000,1000,1,14.5,0,0,0,14500,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(77,16,35,NULL,1000,1000,1,14.5,0,0,0,14500,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(78,16,36,NULL,1000,1000,1,14.5,0,0,0,14500,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(79,16,39,NULL,1000,1000,1,16,0,0,0,16000,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(80,16,37,NULL,1000,1000,1,16,0,0,0,16000,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(81,16,38,NULL,1000,1000,1,16,0,0,0,16000,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(82,16,33,NULL,600,600,1,14.3,0,0,0,8580,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(83,17,158,NULL,10,10,1,1900,0,0,0,19000,'2023-05-03 05:17:54','2023-05-03 05:17:54'),(84,18,94,NULL,1,1,14,2700,0,0,0,2700,'2023-05-03 06:03:34','2023-05-03 06:03:34'),(85,19,133,NULL,60,60,1,103,0,0,0,6180,'2023-05-03 07:24:11','2023-05-03 07:24:11'),(86,20,134,NULL,13,13,1,95,0,0,0,1235,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(87,20,135,NULL,19,19,1,155,0,0,0,2945,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(88,20,136,NULL,1,1,12,1800,0,0,0,1800,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(89,20,137,NULL,1,1,1,358,0,0,0,358,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(90,20,138,NULL,59,59,1,66,0,0,0,3894,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(91,20,139,NULL,20,20,1,255,0,0,0,5100,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(92,20,140,NULL,12,12,1,35,0,0,0,420,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(93,20,141,NULL,4,4,1,255,0,0,0,1020,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(94,20,142,NULL,11,11,1,275,0,0,0,3025,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(95,20,143,NULL,50,50,1,45,0,0,0,2250,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(96,20,144,NULL,18,18,1,425,0,0,0,7650,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(97,20,146,NULL,228,228,1,25,0,0,0,5700,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(98,20,147,NULL,120,120,1,25,0,0,0,3000,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(99,20,148,NULL,120,120,1,25,0,0,0,3000,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(100,20,149,NULL,30,30,1,172,0,0,0,5160,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(101,20,151,NULL,50,50,1,29,0,0,0,1450,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(102,20,152,NULL,50,50,1,22,0,0,0,1100,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(103,20,153,NULL,9,9,1,95,0,0,0,855,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(104,20,154,NULL,60,60,1,197.5,0,0,0,11850,'2023-05-03 08:27:21','2023-05-03 08:27:21');
/*!40000 ALTER TABLE `product_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_quotation`
--

DROP TABLE IF EXISTS `product_quotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_quotation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `sale_unit_id` int(11) NOT NULL,
  `net_unit_price` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_quotation`
--

LOCK TABLES `product_quotation` WRITE;
/*!40000 ALTER TABLE `product_quotation` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_quotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_returns`
--

DROP TABLE IF EXISTS `product_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_returns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `return_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `sale_unit_id` int(11) NOT NULL,
  `net_unit_price` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_returns`
--

LOCK TABLES `product_returns` WRITE;
/*!40000 ALTER TABLE `product_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_sales`
--

DROP TABLE IF EXISTS `product_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_sales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `sale_unit_id` int(11) NOT NULL,
  `net_unit_price` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_sales`
--

LOCK TABLES `product_sales` WRITE;
/*!40000 ALTER TABLE `product_sales` DISABLE KEYS */;
INSERT INTO `product_sales` (`id`, `sale_id`, `product_id`, `variant_id`, `qty`, `sale_unit_id`, `net_unit_price`, `discount`, `tax_rate`, `tax`, `total`, `created_at`, `updated_at`) VALUES (5,5,5,NULL,5,1,120,0,0,0,600,'2023-04-30 08:51:22','2023-04-30 08:51:22');
/*!40000 ALTER TABLE `product_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_transfer`
--

DROP TABLE IF EXISTS `product_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_transfer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `net_unit_cost` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_transfer`
--

LOCK TABLES `product_transfer` WRITE;
/*!40000 ALTER TABLE `product_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_variants`
--

DROP TABLE IF EXISTS `product_variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_variants` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `item_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `additional_price` double DEFAULT NULL,
  `qty` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_variants`
--

LOCK TABLES `product_variants` WRITE;
/*!40000 ALTER TABLE `product_variants` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_variants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_warehouse`
--

DROP TABLE IF EXISTS `product_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_warehouse` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) NOT NULL,
  `qty` double NOT NULL,
  `price` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_warehouse`
--

LOCK TABLES `product_warehouse` WRITE;
/*!40000 ALTER TABLE `product_warehouse` DISABLE KEYS */;
INSERT INTO `product_warehouse` (`id`, `product_id`, `variant_id`, `warehouse_id`, `qty`, `price`, `created_at`, `updated_at`) VALUES (1,'1',NULL,2,0,NULL,'2023-03-19 11:04:03','2023-04-26 22:55:24'),(2,'2',NULL,2,0,NULL,'2023-04-26 23:02:56','2023-04-28 11:59:28'),(3,'3',NULL,2,0,NULL,'2023-04-28 12:18:45','2023-04-28 12:47:31'),(4,'4',NULL,2,0,NULL,'2023-04-30 07:47:16','2023-04-30 08:17:26'),(5,'5',NULL,2,-5,NULL,'2023-04-30 08:43:49','2023-05-02 06:23:52'),(6,'11',NULL,2,300,NULL,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(7,'13',NULL,2,700,NULL,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(8,'14',NULL,2,300,NULL,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(9,'12',NULL,2,1800,NULL,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(10,'6',NULL,2,150,NULL,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(11,'10',NULL,2,500,NULL,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(12,'9',NULL,2,600,NULL,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(13,'8',NULL,2,500,NULL,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(14,'7',NULL,2,50,NULL,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(15,'15',NULL,2,300,NULL,'2023-05-02 06:23:18','2023-05-02 06:23:18'),(16,'16',NULL,2,20,NULL,'2023-05-02 06:48:45','2023-05-02 06:48:45'),(17,'17',NULL,2,300,NULL,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(18,'18',NULL,2,40,NULL,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(19,'19',NULL,2,15,NULL,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(20,'20',NULL,2,9,NULL,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(21,'21',NULL,2,6,NULL,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(22,'22',NULL,2,4,NULL,'2023-05-02 07:02:39','2023-05-02 07:02:39'),(23,'155',NULL,2,4,NULL,'2023-05-02 07:05:36','2023-05-02 07:05:36'),(24,'156',NULL,2,45,NULL,'2023-05-02 07:05:36','2023-05-02 07:05:36'),(25,'157',NULL,2,4,NULL,'2023-05-02 07:05:36','2023-05-02 07:05:36'),(26,'166',NULL,2,78,NULL,'2023-05-02 07:16:07','2023-05-02 07:40:40'),(27,'169',NULL,2,15,NULL,'2023-05-02 07:16:07','2023-05-02 07:40:40'),(28,'167',NULL,2,25,NULL,'2023-05-02 07:16:07','2023-05-02 07:40:40'),(29,'165',NULL,2,60,NULL,'2023-05-02 07:16:07','2023-05-02 07:40:40'),(30,'164',NULL,2,10,NULL,'2023-05-02 07:16:07','2023-05-02 07:16:07'),(31,'171',NULL,2,40,NULL,'2023-05-02 07:16:07','2023-05-02 07:40:40'),(32,'172',NULL,2,20,NULL,'2023-05-02 07:40:40','2023-05-02 07:40:40'),(33,'170',NULL,2,24,NULL,'2023-05-02 07:40:40','2023-05-02 07:40:40'),(34,'168',NULL,2,48,NULL,'2023-05-02 07:40:40','2023-05-02 07:40:40'),(35,'102',NULL,2,71,NULL,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(36,'103',NULL,2,50,NULL,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(37,'90',NULL,2,104,NULL,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(38,'50',NULL,2,10,NULL,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(39,'51',NULL,2,10,NULL,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(40,'52',NULL,2,10,NULL,'2023-05-02 08:21:46','2023-05-02 08:21:46'),(41,'179',NULL,2,6,NULL,'2023-05-02 08:59:56','2023-05-02 09:04:16'),(42,'180',NULL,2,6,NULL,'2023-05-02 08:59:56','2023-05-02 09:04:16'),(43,'181',NULL,2,24,NULL,'2023-05-02 08:59:56','2023-05-02 09:04:16'),(44,'182',NULL,2,6,NULL,'2023-05-02 08:59:56','2023-05-02 09:04:16'),(45,'183',NULL,2,40,NULL,'2023-05-02 08:59:56','2023-05-02 09:04:16'),(46,'186',NULL,2,400,NULL,'2023-05-02 08:59:56','2023-05-02 09:04:16'),(47,'187',NULL,2,400,NULL,'2023-05-02 08:59:56','2023-05-02 09:04:16'),(48,'184',NULL,2,190,NULL,'2023-05-02 08:59:56','2023-05-02 09:04:16'),(49,'185',NULL,2,59,NULL,'2023-05-02 08:59:56','2023-05-02 09:04:16'),(50,'30',NULL,2,500,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(51,'31',NULL,2,140,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(52,'32',NULL,2,200,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(53,'23',NULL,2,200,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(54,'24',NULL,2,30,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(55,'25',NULL,2,30,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(56,'27',NULL,2,200,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(57,'29',NULL,2,200,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(58,'28',NULL,2,200,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(59,'26',NULL,2,200,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(60,'34',NULL,2,1000,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(61,'35',NULL,2,1000,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(62,'36',NULL,2,1000,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(63,'39',NULL,2,1000,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(64,'37',NULL,2,1000,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(65,'38',NULL,2,1000,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(66,'33',NULL,2,600,NULL,'2023-05-02 09:18:33','2023-05-02 09:18:33'),(67,'158',NULL,2,10,NULL,'2023-05-03 05:17:54','2023-05-03 05:17:54'),(68,'94',NULL,2,1,NULL,'2023-05-03 06:03:34','2023-05-03 06:03:34'),(69,'133',NULL,2,60,NULL,'2023-05-03 07:24:11','2023-05-03 07:24:11'),(70,'134',NULL,2,13,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(71,'135',NULL,2,19,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(72,'136',NULL,2,1,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(73,'137',NULL,2,1,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(74,'138',NULL,2,59,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(75,'139',NULL,2,20,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(76,'140',NULL,2,12,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(77,'141',NULL,2,4,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(78,'142',NULL,2,11,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(79,'143',NULL,2,50,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(80,'144',NULL,2,18,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(81,'146',NULL,2,228,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(82,'147',NULL,2,120,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(83,'148',NULL,2,120,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(84,'149',NULL,2,30,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(85,'151',NULL,2,50,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(86,'152',NULL,2,50,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(87,'153',NULL,2,9,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21'),(88,'154',NULL,2,60,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21');
/*!40000 ALTER TABLE `product_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode_symbology` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `sale_unit_id` int(11) NOT NULL,
  `cost` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` double DEFAULT NULL,
  `alert_quantity` double DEFAULT NULL,
  `promotion` tinyint(4) DEFAULT NULL,
  `promotion_price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `starting_date` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_date` date DEFAULT NULL,
  `tax_id` int(11) DEFAULT NULL,
  `tax_method` int(11) DEFAULT NULL,
  `image` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_variant` tinyint(1) DEFAULT NULL,
  `is_diffPrice` tinyint(1) DEFAULT NULL,
  `featured` tinyint(4) DEFAULT NULL,
  `product_list` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty_list` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_list` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id`, `name`, `code`, `type`, `barcode_symbology`, `brand_id`, `category_id`, `unit_id`, `purchase_unit_id`, `sale_unit_id`, `cost`, `price`, `qty`, `alert_quantity`, `promotion`, `promotion_price`, `starting_date`, `last_date`, `tax_id`, `tax_method`, `image`, `file`, `is_variant`, `is_diffPrice`, `featured`, `product_list`, `qty_list`, `price_list`, `product_details`, `is_active`, `created_at`, `updated_at`) VALUES (1,'منتج تجريبي','12026689','standard','C128',NULL,1,1,1,1,'80','100',0,5,NULL,NULL,NULL,NULL,NULL,1,'1679230854925Capture.PNG',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,'2023-03-19 11:01:42','2023-04-26 22:55:24'),(2,'منتج تجريبي','02337651','standard','C128',NULL,1,1,1,1,'100','120',0,1,NULL,NULL,NULL,NULL,NULL,1,'1682560840917Capture-removebg-preview.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>منتج تجريبي</p>',0,'2023-04-26 23:01:25','2023-04-28 11:59:28'),(3,'منتج  تجربيبي','15213912','standard','C128',8,1,1,1,1,'100','120',0,1,NULL,NULL,NULL,NULL,NULL,1,'1682694903143Capture-removebg-preview.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>منتج&nbsp; عالي&nbsp; الجوده</p>',0,'2023-04-28 12:15:20','2023-04-28 12:47:31'),(4,'mma- 315 sv ماكينة لحام 315 أمبير','101','standard','C128',8,2,1,1,1,'4200','5000',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,'2023-04-30 07:01:01','2023-04-30 08:17:46'),(5,'ماكينة لحام 315 أمبير','31582041','standard','C128',11,3,1,1,1,'4200','5005',0,1,NULL,NULL,NULL,NULL,NULL,1,'1682854766981R.jpg',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-04-30 08:39:38','2023-05-02 06:23:52'),(6,'حجر 12*3 Robtec','06719316','standard','C128',26,3,1,1,1,'65','72',150,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:29:26','2023-05-02 06:23:18'),(7,'حجر 16*4 Robtec','28762500','standard','C128',26,3,1,1,1,'110','125',50,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:30:41','2023-05-02 06:23:18'),(8,'حجر 5*1.2 Robtec','46758154','standard','C128',26,3,1,1,1,'15','18',500,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:31:39','2023-05-02 06:23:18'),(9,'حجر 5*3 Robtec','73404093','standard','C128',26,3,1,1,1,'15','17',600,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:32:42','2023-05-02 06:23:18'),(10,'حجر 5*6 Robtec','18543149','standard','C128',26,3,1,1,1,'25','30',500,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:34:14','2023-05-02 06:23:18'),(11,'حجر 7*6 Robtec','52337458','standard','C128',26,3,1,1,1,'45','55',300,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:35:23','2023-05-02 06:23:18'),(12,'حجر 9*1 Robtec','75583216','standard','C128',26,3,1,1,1,'42','46',1800,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:36:09','2023-05-02 06:23:18'),(13,'حجر 9*3 Robtec','84861579','standard','C128',26,3,1,1,1,'28','33',700,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:37:13','2023-05-02 06:23:18'),(14,'حجر 9*6 Robtec','88746236','standard','C128',26,3,1,1,1,'70','80',300,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:38:11','2023-05-02 06:23:18'),(15,'حجر14*3 Robtec','00693192','standard','C128',26,3,1,1,1,'83','93',300,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:39:07','2023-05-02 06:23:18'),(16,'سلك لحام 3 مم Ethab (E.S)','44505929','standard','C128',21,3,12,12,12,'1365','1435',20,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:41:17','2023-05-02 06:48:45'),(17,'مكنة تسليب كونتنر 3 طن 10 متر','35118995','standard','C128',29,2,1,1,1,'280','320',300,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:45:28','2023-05-02 07:02:39'),(18,'واير تسليب صبانى حرير 2 طن 2 متر','81599247','standard','C128',29,2,1,1,1,'96','116',40,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:46:58','2023-05-02 07:02:39'),(19,'واير تسليب صبانى حرير 3طن 3 متر','90107357','standard','C128',29,2,1,1,1,'216','261',15,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:49:56','2023-05-02 07:02:39'),(20,'واير تسليب صبانى حرير 4 طن 4 متر','08043824','standard','C128',29,2,1,1,1,'384','464',9,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:51:57','2023-05-02 07:02:39'),(21,'واير تسليب صبانى حرير 5 طن 5 متر','15639222','standard','C128',29,2,1,1,1,'600','725',6,3,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:53:07','2023-05-02 07:02:39'),(22,'واير تسليب صبانى حرير 6 طن 6 متر','25199000','standard','C128',29,2,1,1,1,'864','1044',4,3,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:53:59','2023-05-02 07:02:39'),(23,'بنطة 10مم*160مم','28603993','standard','C128',32,2,1,1,1,'21.4','25',200,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-04-30 10:55:17','2023-05-02 09:18:33'),(24,'بنطة 12مم*340سم هيلتى ماكس','15803182','standard','C128',32,4,1,1,1,'105','120',30,15,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 10:58:51','2023-05-02 09:18:33'),(25,'بنطة 14مم*340سم هيلتى ماكس','03014229','standard','C128',32,4,1,1,1,'115','130',30,15,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:00:24','2023-05-02 09:18:33'),(26,'بنطة 2.4مم كوبلت ألبن','08870925','standard','C128',32,2,1,1,1,'6.85','8',200,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-04-30 11:01:15','2023-05-02 09:18:33'),(27,'بنطة 2مم كوبلت ألبن','10899725','standard','C128',32,4,1,1,1,'3.25','5',200,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-04-30 11:01:55','2023-05-02 09:18:33'),(28,'بنطة 3.5مم كوبلت ألبن','39056467','standard','C128',32,4,1,1,1,'5.55','7',200,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-04-30 11:02:45','2023-05-02 09:18:33'),(29,'بنطة 3مم كوبلن ألبن','19706478','standard','C128',32,4,1,1,1,'5.1','6',200,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:03:32','2023-05-02 09:18:33'),(30,'بنطة 6مم*110مم','97804675','standard','C128',32,4,1,1,1,'12.4','14',500,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:05:03','2023-05-02 09:18:33'),(31,'بنطة 6مم*160 مم','91320046','standard','C128',32,4,1,1,1,'16.5','20',140,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:07:29','2023-05-02 09:18:33'),(32,'بنطة 8 مم*160مم','59726851','standard','C128',32,4,1,1,1,'18.6','22',200,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:08:49','2023-05-02 09:18:33'),(33,'صنفرة مروحية 4.5 tnt إستانلس','16306543','standard','C128',33,6,1,1,1,'14.3','16',600,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:11:40','2023-05-02 09:18:33'),(34,'صنفرة مروحية 4.5 كثافة عالية ألبن خشانة 40','22316709','standard','C128',32,6,1,1,1,'14.5','16',1000,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:12:58','2023-05-02 09:18:33'),(35,'صنفرة مروحية 4.5 كثافة عالية ألبن خشانة60','50176140','standard','C128',32,6,1,1,1,'14.5','16',1000,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:14:02','2023-05-02 09:18:33'),(36,'صنفرة مروحية 4.5 كثافة عالية ألبن خشانة80','78162033','standard','C128',32,6,1,1,1,'14.5','16',1000,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:15:11','2023-05-02 09:18:33'),(37,'صنفرة مروحية 5 حديد ألبن  خشانة60','14356798','standard','C128',32,6,1,1,1,'16','18',1000,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:17:22','2023-05-02 09:18:33'),(38,'صنفرة مروحية 5 حديد ألبن  خشانة80','46491635','standard','C128',32,6,1,1,1,'16','18',1000,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:17:55','2023-05-02 09:18:33'),(39,'صنفرة مروحية 5 حديد ألبن خشانة 40','34192907','standard','C128',32,6,1,1,1,'16','18',1000,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:18:27','2023-05-02 09:18:33'),(40,'ابرة أرجون 2.4 مم','58071691','standard','C128',30,3,1,1,1,'45','55',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-04-30 11:22:42','2023-05-02 08:08:12'),(41,'أسطوانة أكسجين 40لتر','24510395','standard','C128',8,3,1,1,1,'2300','2700',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:23:56','2023-04-30 11:23:56'),(42,'بكر فلاكسCO2DWT','21651310','standard','C128',11,3,12,12,12,'1100','1400',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:25:05','2023-04-30 11:25:05'),(43,'بلاور هواء 480وات','45122063','standard','C128',15,7,1,1,1,'748','865',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:26:37','2023-04-30 11:26:37'),(44,'جركن تلميع إستانلس','02055760','standard','C128',23,3,1,1,1,'425','500',0,3,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:28:56','2023-04-30 11:28:56'),(45,'جوانتى انتى كت ANTI CUT','20996104','standard','C128',34,3,1,1,1,'20','25',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:31:46','2023-04-30 11:31:46'),(46,'جوانتى لحام باكستانى احمر','61925196','standard','C128',34,3,1,1,1,'70','85',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:32:49','2023-04-30 11:32:49'),(47,'جوانتى لحام باكستانى محبب ثقيل','42589350','standard','C128',34,3,1,1,1,'11','15',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:33:33','2023-04-30 11:33:33'),(48,'جوانتى لحام شرقية باكستانى خفيف','54808196','standard','C128',34,3,1,1,1,'32','40',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:34:16','2023-04-30 11:34:16'),(49,'حجر كربيد (فديا معدن ) E1220M06','60492415','standard','C128',19,3,1,1,1,'150','165',0,30,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:35:40','2023-04-30 11:35:40'),(50,'خرطوم مزدوج إيطالى','49374300','standard','C128',18,7,14,14,14,'2000','2200',10,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:39:37','2023-05-02 08:21:46'),(51,'خرطوم مفرد إيطالى أسود','90354026','standard','C128',18,7,14,14,14,'825','1000',10,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:40:29','2023-05-02 08:21:46'),(52,'خرطوم مفرد إيطالى كرتونة أنجرسو','84961595','standard','C128',18,7,14,14,14,'875','1050',10,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:41:37','2023-05-02 08:21:46'),(53,'راوتر 900 وات 8 مم','39854390','standard','C128',15,5,1,1,1,'1289','1500',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:42:53','2023-04-30 11:42:53'),(54,'زجاج أسود مقاس 10','97319445','standard','C128',35,3,1,1,1,'4','5.5',0,500,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:45:48','2023-04-30 11:45:48'),(55,'سلاح منشار ميكانيكى 14 - سن 6','69747156','standard','C128',23,4,1,1,1,'145','160',0,3,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:46:50','2023-04-30 11:46:50'),(56,'سلاح منشار ميكانيكى 16 - سن 10','39063141','standard','C128',23,4,1,1,1,'150','165',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:47:42','2023-04-30 11:47:42'),(57,'سلاح منشار ميكانيكى 18 - سن 10','85106899','standard','C128',23,4,1,1,1,'180','200',0,3,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:49:03','2023-04-30 11:49:03'),(58,'سلاح منشار ميكانيكى 20 - سن 10','26893310','standard','C128',23,4,1,1,1,'295','335',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:50:12','2023-04-30 11:50:12'),(59,'سلاح منشار ميكانيكى 24 - سن 6','16369131','standard','C128',23,4,1,1,1,'460','550',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:51:04','2023-04-30 11:51:04'),(60,'سلك لحام استانلس 2.5مم','68069719','standard','C128',23,3,7,7,7,'260','320',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:52:41','2023-04-30 11:52:41'),(61,'سلك لحام استانلس 3مم','50373598','standard','C128',23,3,7,7,7,'250','310',0,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:53:22','2023-04-30 11:53:22'),(62,'سلك لحام مصرى تقليد تركى - أسلاك 2.5مم','57140004','standard','C128',21,3,12,12,12,'1250','1400',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-04-30 11:55:19','2023-04-30 11:59:05'),(63,'سلك لحام مصرى تقليد تركى - أسلاك 3 مم','09731486','standard','C128',21,3,12,12,12,'1175','1350',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-04-30 11:56:10','2023-04-30 11:59:39'),(64,'سلك لحام مصرى تقليد تركى - أسلاك2.5مم7018','77323586','standard','C128',21,3,12,12,12,'1255','1400',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 11:57:21','2023-04-30 11:57:21'),(65,'سلك لحام مصرى تقليد تركى - أسلاك3مم7018','96361022','standard','C128',21,3,12,12,12,'1225','1400',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:01:53','2023-04-30 12:01:53'),(66,'سلك لحام مصرى تقليد تركى - أسلاك4 مم','54873017','standard','C128',21,3,12,12,12,'1175','1325',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:03:08','2023-04-30 12:03:08'),(67,'سلك لحام نحاس 3مم','16991054','standard','C128',23,3,7,7,7,'460','550',0,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:13:42','2023-04-30 12:13:42'),(68,'سلك لحام مصرى تقليد تركى - أسلاك4مم7018','75393358','standard','C128',21,3,12,12,12,'1225','1400',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:23:31','2023-04-30 12:23:31'),(69,'سلك لحام هندى 2.4 ارجون حديد 70S6','65731815','standard','C128',23,3,7,7,7,'90','110',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:26:44','2023-04-30 12:26:44'),(70,'سلك لحام هندى أرجون 1.6 308','28966133','standard','C128',23,3,7,7,7,'275','325',0,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:27:34','2023-04-30 12:27:34'),(71,'سلك لحام هندى أرجون 1.6 316','83343410','standard','C128',23,3,7,7,7,'350','450',0,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:28:31','2023-04-30 12:28:31'),(72,'سلك لحام هندى أرجون 2.4 308','80685493','standard','C128',23,3,7,7,7,'275','325',0,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:29:32','2023-04-30 12:29:32'),(73,'سلك لحام هندى أرجون 2.4 316','53842782','standard','C128',23,3,7,7,7,'350','400',0,0,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:30:28','2023-04-30 12:30:28'),(74,'شنيور 13 مم 710 وات شمال ويمين وسرعات دقاق','20953081','standard','C128',15,5,1,1,1,'987','1200',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:31:32','2023-04-30 12:31:32'),(75,'شنيور بالبطاريه 10مم 12فولت بطاريه ليثم','45814028','standard','C128',15,5,1,1,1,'1504','1700',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:32:27','2023-04-30 12:32:27'),(76,'شنيور بالبطاريه(دقاق)13مم18فولت بطاريه ليثم','02664109','standard','C128',15,5,1,1,1,'3502','4000',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:34:18','2023-04-30 12:34:18'),(77,'شنيور بالبطاريه10مم14.4فولت بطاريه ليثم','39272525','standard','C128',15,5,1,1,1,'1632','1850',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:35:24','2023-04-30 12:35:24'),(78,'شيكارة بودرة','25792169','standard','C128',36,3,7,7,7,'1300','1450',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:38:06','2023-04-30 12:38:06'),(79,'صاروخ 4.5 - 710 وات','10436612','standard','C128',15,5,1,1,1,'760','900',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:38:59','2023-04-30 12:38:59'),(80,'صاروخ 5 - 1200 وات','84410920','standard','C128',15,5,1,1,1,'1250','1400',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:40:42','2023-04-30 12:40:42'),(81,'صاروخ 9 - 2200 وات موديل ماكيتا - 03','26590991','standard','C128',15,5,1,1,1,'1950','2200',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:41:33','2023-04-30 12:41:33'),(82,'صاروخ بوش 9 بوصة تقليد','01493397','standard','C128',19,5,1,1,1,'1650','2000',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:43:21','2023-04-30 12:43:21'),(83,'صنفرة مروحية  حمراء','29635296','standard','C128',37,6,1,1,1,'8','10',0,100,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:48:12','2023-04-30 12:48:12'),(84,'صينية جرانيت 7 بوصة تربو','00108131','standard','C128',15,4,1,1,1,'98','110',0,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:49:14','2023-04-30 12:49:14'),(85,'صينية جرانيت 7 بوصة مفتوحة','37708963','standard','C128',15,4,1,1,1,'95','105',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:50:08','2023-04-30 12:50:08'),(86,'صينية جرانيت 9 بوصة مفتوحة','27838503','standard','C128',15,4,1,1,1,'160','180',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:51:03','2023-04-30 12:51:03'),(87,'صينية جرلنيت 5 بوصة مفتوحة','02561139','standard','C128',15,4,1,1,1,'51','60',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:52:26','2023-04-30 12:52:26'),(88,'فارة 500 وات  8سم تفريز','22523498','standard','C128',15,5,1,1,1,'1281','1400',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:55:01','2023-04-30 12:55:01'),(89,'فخارة مقاس 5','27594021','standard','C128',15,3,1,1,1,'10','12',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 12:56:11','2023-04-30 12:56:11'),(90,'سلك لحام  ألمونيم 3 مم امريكى','35197093','standard','C128',25,3,7,7,7,'800','1100',104,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-04-30 12:57:50','2023-05-02 08:21:46'),(91,'كابل لحام إيطالى 1000  شعرة','07268796','standard','C128',18,3,14,14,14,'4750','6000',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 13:03:08','2023-04-30 13:03:08'),(92,'كابل لحام إيطالى 120مم1200  شعرة','21092803','standard','C128',18,3,14,14,14,'5500','6875',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 13:07:10','2023-04-30 13:07:10'),(93,'كابل لحام إيطالى 1500  شعرة','48637018','standard','C128',18,3,14,14,14,'6500','8125',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 13:08:15','2023-04-30 13:08:15'),(94,'كابل لحام إيطالى 50مم 400 شعرة','89239627','standard','C128',18,3,14,14,14,'2400','3000',1,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-04-30 13:09:34','2023-05-03 06:03:34'),(95,'كابل لحام إيطالى 600 شعرة','24968197','standard','C128',18,3,14,14,14,'3250','4000',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 04:06:17','2023-05-01 04:22:37'),(96,'كابل لحام إيطالى 70مم700 شعرة','09963421','standard','C128',18,3,14,14,14,'3500','4500',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 04:08:02','2023-05-01 04:24:34'),(97,'كابل لحام إيطالى70مم800 شعرة','96380929','standard','C128',18,3,14,14,14,'4150','5200',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 04:10:51','2023-05-01 04:10:51'),(98,'كسار 1240وات 15 ك + إجن','68991704','standard','C128',15,5,1,1,1,'5715','7000',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 04:28:27','2023-05-01 04:28:27'),(99,'كسار 1700 وات 45 19 ك','78134192','standard','C128',15,5,1,1,1,'10185','12000',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 04:30:10','2023-05-01 04:30:10'),(100,'كسار 6 ك1350وات +إجن','30031409','standard','C128',15,5,1,1,1,'2900','3500',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 04:31:26','2023-05-01 04:33:33'),(101,'كمبروسر 30لتر سير صينى 2','46131327','standard','C128',12,7,1,1,1,'4870','5800',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 04:44:58','2023-05-01 04:44:58'),(102,'لمبة قطعية تقليد','94112370','standard','C128',20,3,1,1,1,'900','1100',71,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 04:46:21','2023-05-02 08:21:46'),(103,'لمبة لحام تقليد','37842362','standard','C128',20,3,1,1,1,'275','450',50,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 04:47:12','2023-05-02 08:21:46'),(104,'ماتور جلخ 6 نحاس 250وات HEAVY DUTY','68187345','standard','C128',15,5,1,1,1,'1401','2000',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 04:49:49','2023-05-01 04:49:49'),(105,'ماتور جلخ 8 - 370وات خدمه شاقة','29015160','standard','C128',15,5,1,1,1,'2219','2500',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 04:51:02','2023-05-01 04:51:02'),(106,'ماكينة غسيل 130 بار واقفة','97116309','standard','C128',12,4,1,1,1,'4000','5000',0,NULL,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 04:52:17','2023-05-01 04:52:17'),(107,'ماكينة لحام 250 أمبير إنفرترMMA-250 I','91980743','standard','C128',11,3,1,1,1,'3450','4500',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 05:16:40','2023-05-01 05:17:48'),(108,'ماكينة لحام 400 أمير mma 400sv','40349719','standard','C128',11,3,1,1,1,'6000','7000',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 05:20:20','2023-05-01 05:20:20'),(109,'ماكينة لحام إنفرتر 220 فولت MMA-200 MINI','52983089','standard','C128',11,3,1,1,1,'1980','2500',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 05:23:32','2023-05-01 05:23:32'),(110,'مسدس دوكو مقلوب بلاستيك  AB17G1.4','01530319','standard','C128',30,7,1,1,1,'662','800',0,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:02:59','2023-05-01 07:02:59'),(111,'مسدس دوكو مقلوب معدن جانبى F75 Gفونيه 5','31243731','standard','C128',30,7,1,1,1,'353','450',0,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:03:52','2023-05-01 07:03:52'),(112,'مسدس دوكو مقلوب معدن من فوق 2.5  G80','41238891','standard','C128',30,7,1,1,1,'449','600',0,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:04:38','2023-05-01 07:04:38'),(113,'مسدس دوكو1/8 ك مقلوب بلاستيك  H2000','72180129','standard','C128',30,7,1,1,1,'359','500',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:05:37','2023-05-01 07:05:37'),(114,'مسدس دوكوعدل 1ك يد زرقاء بالزرجنية S4001','02027559','standard','C128',30,7,1,1,1,'640','800',0,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:06:23','2023-05-01 07:06:23'),(115,'مسدس دوكوعدل معدن S990S','91285302','standard','C128',30,7,1,1,1,'340','500',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:07:08','2023-05-01 07:07:08'),(116,'مسدس هواء','41202291','standard','C128',30,7,1,1,1,'72','85',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:07:49','2023-05-01 07:07:49'),(117,'مشحمة 16 كيلو إيطالى BONNEZZI','65621008','standard','C128',8,4,1,1,1,'2075','2500',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:09:09','2023-05-01 07:09:09'),(118,'مشحمة برميل يدوي 3ك ص - ABK','38123920','standard','C128',12,4,1,1,1,'750','900',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:10:19','2023-05-01 07:10:19'),(119,'مشحمة برميل يدوي6ك  - ABK','36243186','standard','C128',12,4,1,1,1,'780','1000',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:11:18','2023-05-01 07:11:18'),(120,'منشار صينيه 1/4 7 - 1500 وات 5300 لفة فى الدقيقة','94837532','standard','C128',15,5,1,1,1,'1385','1600',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:12:24','2023-05-01 07:12:24'),(121,'منشار صينيه 1100 وات 1/4 7 - 4900 لفة فى الدقيقة','10123356','standard','C128',15,5,1,1,1,'1767','2000',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:13:14','2023-05-01 07:13:14'),(122,'منظم  CO2 ماجلى إيطالى','15822265','standard','C128',18,3,1,1,1,'650','800',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:14:18','2023-05-01 07:14:18'),(123,'منظم AC ماجلى موديل إطالى','21952139','standard','C128',18,3,4,4,4,'650','800',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:15:00','2023-05-01 07:15:00'),(124,'منظم OX المنيوم JO صينى','32273589','standard','C128',30,3,1,1,1,'200','250',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:15:47','2023-05-01 07:15:47'),(125,'منظم OX المنيوم جولد صينى','31037455','standard','C128',30,3,1,1,1,'200','250',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:16:32','2023-05-01 07:16:32'),(126,'منظم OX ماجلى إيطالى','55712629','standard','C128',18,3,1,1,1,'650','800',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:17:12','2023-05-01 07:17:12'),(127,'منظم نتروجين ماجلى إيطالى','16761590','standard','C128',18,3,1,1,1,'650','800',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:18:19','2023-05-01 07:18:19'),(128,'هيلتى 26 مم 1000 وات تقليد بوش','54171922','standard','C128',19,5,1,1,1,'1200','1400',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:18:54','2023-05-01 07:18:54'),(129,'هيلتى تخريم وتكسير 26مم750وات+إجن وبنط','87625162','standard','C128',15,5,1,1,1,'1663','1900',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:19:41','2023-05-01 07:19:41'),(130,'وش أرجون أتوماتيك علبة حمراء','75807544','standard','C128',30,3,1,1,1,'400','550',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:20:34','2023-05-01 07:20:34'),(131,'باكوليس ديجتال علبة بلاستيك 6','72455934','standard','C128',16,4,1,1,1,'125','175',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:21:56','2023-05-01 07:21:56'),(132,'بنسة جاز نيكل صلب يد عازل 10','20958913','standard','C128',16,4,1,1,1,'57','75',0,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:23:47','2023-05-01 07:23:47'),(133,'بنسة كلابة صلب فامية 10','30018759','standard','C128',16,4,1,1,1,'64','100',60,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:38:09','2023-05-03 07:24:11'),(134,'بنسة لحام  قلب معدن 800 أمبير','68514909','standard','C128',16,4,1,1,1,'75','100',13,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 07:56:35','2023-05-03 08:27:21'),(135,'خرطوم هواء مرن قدرة شاقة 15متر PU','64134870','standard','C128',16,7,1,1,1,'120','160',19,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 08:00:34','2023-05-03 08:27:21'),(136,'سلاح بحد واحد صلب bl- metal برتقالى12بالعلبة','60749902','standard','C128',16,4,12,12,12,'1200','1400',1,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:05:21','2023-05-03 08:27:21'),(137,'شريط متر ضد الكسر قدرة شاقة الوان 5م','94338271','standard','C128',30,4,1,1,1,'358','450',1,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:06:27','2023-05-03 08:27:21'),(138,'طاقم ألن كى مسدس مطفى صلب 9 قطعة','50130228','standard','C128',16,4,1,1,1,'43','65',59,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:13:17','2023-05-03 08:27:21'),(139,'طاقم بنس تيل 4 قطعة','94810167','standard','C128',16,4,1,1,1,'135','170',20,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:16:05','2023-05-03 08:27:21'),(140,'طقم حجر شنيور 5 قطعة','00785035','standard','C128',16,4,1,1,1,'21','30',12,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:16:55','2023-05-03 08:27:21'),(141,'طقم خرطوم+مسدس هواء +مشتملات كارت','83270856','standard','C128',16,7,1,1,1,'115','140',4,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:18:23','2023-05-03 08:27:21'),(142,'طقم مفتاح بيبة لوكس صلب 6 ق من17:8 مم','43955438','standard','C128',16,4,1,1,1,'145','350',11,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:20:00','2023-05-03 08:27:21'),(143,'طقم مفك علبة بلاستيك 32 قطعة','72081571','standard','C128',16,4,1,1,1,'25','50',50,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:20:39','2023-05-03 08:27:21'),(144,'طقم يد سيستم +اللقم قدرة شاقة من24:8م12ق','39267305','standard','C128',16,4,1,1,1,'190','500',18,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:21:49','2023-05-03 08:27:21'),(145,'فرشة كوباية شعر ذهبى حرة 4','78135920','standard','C128',16,4,1,1,1,'22.5','50',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:22:45','2023-05-01 08:22:45'),(146,'كاتر مطواة بلاستيك م kn02','10915074','standard','C128',16,4,1,1,1,'230','300',228,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:24:10','2023-05-03 08:27:21'),(147,'كاتر معدن ببكرة  م kn-1919-1','87279486','standard','C128',16,4,1,1,1,'195','250',120,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:26:05','2023-05-03 08:27:21'),(148,'كاتر معدن جرار م 2- KN-1919A','27529391','standard','C128',16,4,1,1,1,'190','250',120,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:26:56','2023-05-03 08:27:21'),(149,'مسدس غسيل يد برتقالى ثقيل','04953316','standard','C128',16,4,1,1,1,'86','100',30,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:28:30','2023-05-03 08:27:21'),(150,'مفتاح بيبة لوكس نيكل 10 مم','02140798','standard','C128',16,4,1,1,1,'14','20',0,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:29:47','2023-05-01 08:29:47'),(151,'مفتاح بيبة لوكس نيكل 13 مم','19087892','standard','C128',16,4,1,1,1,'18','25',50,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:30:26','2023-05-03 08:27:21'),(152,'مفتاح بيبة لوكس نيكل 8 مم','21019240','standard','C128',16,4,1,1,1,'12','15',50,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:31:06','2023-05-03 08:27:21'),(153,'مقاس تزويد كاوتش 12 بار','24073113','standard','C128',16,4,1,1,1,'55','75',9,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:32:11','2023-05-03 08:27:21'),(154,'يد سيستم كاوتش نيكل 1/2','64069210','standard','C128',16,4,1,1,1,'57.5','100',60,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:32:57','2023-05-03 08:27:21'),(155,'سلك لحام 2.5 مم RB ماليزى','07419149','standard','C128',17,3,12,12,12,'4300','5000',4,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 08:36:03','2023-05-02 07:05:36'),(156,'سلك لحام 3 مم RB ماليزى','25567947','standard','C128',17,3,12,12,12,'3900','4400',45,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:38:45','2023-05-02 07:05:36'),(157,'سلك لحام 4 مم RB ماليزى','80215096','standard','C128',17,3,12,12,12,'3900','4400',4,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:40:22','2023-05-02 07:05:36'),(158,'طقم لقمه ياتو ايطالى من مقاس 8 ل 32','95701130','standard','C128',18,4,1,1,1,'1900','2500',10,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:42:01','2023-05-03 05:17:54'),(159,'حجر كيداس 14*3','76938780','standard','C128',28,3,1,1,1,'178','200',0,NULL,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 08:45:28','2023-05-01 08:46:47'),(160,'حجر كيداس 5*3','03672932','standard','C128',19,3,1,1,1,'37','38',0,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:49:09','2023-05-01 08:49:09'),(161,'حجر كيداس 9*3','88791097','standard','C128',19,3,1,1,1,'61','67',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:50:37','2023-05-01 08:50:37'),(162,'حجر كيداس 9*6','11523108','standard','C128',19,3,1,1,1,'138','145',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:56:17','2023-05-01 08:56:17'),(163,'اسبراى اماراتى ابيض (12 عبوه)','20668733','standard','C128',22,8,12,12,12,'310','350',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 08:57:58','2023-05-02 07:57:15'),(164,'أكاى','43234636','standard','C128',21,8,12,12,12,'325','375',10,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,'2023-05-01 08:58:56','2023-05-02 07:54:50'),(165,'سلكاسول','53967242','standard','C128',21,8,12,12,12,'325','375',60,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 08:59:46','2023-05-02 07:40:40'),(166,'سليكون 2100','13022099','standard','C128',22,8,12,12,12,'975','1100',78,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 09:00:45','2023-05-02 07:40:40'),(167,'سليكون عضم','74935070','standard','C128',36,8,12,12,12,'21000','25000',25,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 09:02:01','2023-05-02 07:40:40'),(168,'سوبر جلو هندى','01199348','standard','C128',23,8,1,1,1,'55','65',48,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 09:04:19','2023-05-02 07:40:40'),(169,'فوم رودكس','38520113','standard','C128',36,8,12,12,12,'1120','1400',15,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 09:08:58','2023-05-02 07:40:40'),(170,'فيفيكول ايبوكسى هندى','29134928','standard','C128',23,8,1,1,1,'250','350',24,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 09:10:07','2023-05-02 07:40:40'),(171,'إسبراي','42230480','standard','C128',22,8,12,12,12,'300','400',40,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,'2023-05-01 09:11:56','2023-05-02 07:55:22'),(172,'اسبراى جاف (12 عبوه) AKAI ازرق','10033216','standard','C128',21,8,12,12,12,'325','360',20,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 09:15:01','2023-05-02 08:07:21'),(173,'حجارة كيين بسكوته','42681240','standard','C128',30,3,1,1,1,'6','8',0,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 09:16:17','2023-05-01 09:16:17'),(174,'فرشة كوباية شعر ذهبى مجدولة 4','37316900','standard','C128',30,4,1,1,1,'30','40',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 09:17:23','2023-05-01 09:17:23'),(175,'مكواة جيوت   100وات goot','20795198','standard','C128',30,3,1,1,1,'65','100',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 11:06:24','2023-05-01 11:06:24'),(176,'مكواة جيوت   60 وات goot','12320329','standard','C128',30,3,1,1,1,'65','85',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 11:07:19','2023-05-01 11:07:19'),(177,'شفاط قصدير','82760919','standard','C128',30,4,1,1,1,'30','40',0,2,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 11:19:09','2023-05-01 11:19:09'),(178,'فلاكس مكواة قصدير','69675810','standard','C128',30,3,1,1,1,'20','25',0,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 11:19:53','2023-05-02 08:09:12'),(179,'قطر روكى  ألوان (12 قطعه)','06543284','standard','C128',24,4,12,12,12,'160','200',6,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 11:23:31','2023-05-02 09:04:16'),(180,'قطر معدن روكى','27699105','standard','C128',24,4,12,12,12,'280','350',6,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 11:27:21','2023-05-02 09:04:16'),(181,'قطر مطواة روكى خدمة شاقه','13638059','standard','C128',24,4,1,1,1,'70','85',24,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 11:29:39','2023-05-02 09:04:16'),(182,'قطر معدن  روكى حجم كبير خدمة شاقة','42741865','standard','C128',24,4,1,1,1,'85','110',6,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 11:34:15','2023-05-02 09:04:16'),(183,'علبة سلاح معدن إستانلىSTANLE','37510962','standard','C128',9,4,12,12,12,'250','300',40,5,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 11:41:53','2023-05-02 09:04:16'),(184,'سلاح قطر ( جوكر - إكسترا - شارب - VIP)','28536074','standard','C128',30,4,12,12,12,'100','130',190,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 11:49:50','2023-05-02 09:04:16'),(185,'علبة سلاح 9 مم TOP','35708682','standard','C128',9,4,12,12,12,'82','100',59,10,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-01 11:51:03','2023-05-02 09:04:16'),(186,'صنفرة مروحية 4.5  Gatro flex _AFT خشانة 60','02728330','standard','C128',37,6,1,1,1,'8','9',400,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 12:07:18','2023-05-02 09:04:16'),(187,'صنفرة مروحية 5  بوصه  Gatro flex _ AFTخشانة 60','00965271','standard','C128',37,6,1,1,1,'9','10',400,50,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,0,0,NULL,NULL,NULL,'',1,'2023-05-01 12:07:52','2023-05-02 09:04:16'),(188,'اسبراى اماراتى احمر (12 عبوه)','91433826','standard','C128',22,8,12,12,12,'310','360',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-02 08:00:12','2023-05-02 08:00:12'),(189,'اسبراى اماراتى بيج (12 عبوه)','51379600','standard','C128',22,8,12,12,12,'310','360',0,20,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-02 08:03:03','2023-05-02 08:03:03'),(190,'سيليكون( بيج )','46083791','standard','C128',22,8,12,12,12,'1000','1100',0,1,NULL,NULL,NULL,NULL,NULL,1,'zummXD2dvAtI.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,'2023-05-02 08:04:45','2023-05-02 08:04:45');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_product_return`
--

DROP TABLE IF EXISTS `purchase_product_return`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_product_return` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `return_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `net_unit_cost` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_product_return`
--

LOCK TABLES `purchase_product_return` WRITE;
/*!40000 ALTER TABLE `purchase_product_return` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_product_return` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_cost` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `order_discount` double DEFAULT NULL,
  `shipping_cost` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `paid_amount` double NOT NULL,
  `status` int(11) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` (`id`, `reference_no`, `user_id`, `warehouse_id`, `supplier_id`, `item`, `total_qty`, `total_discount`, `total_tax`, `total_cost`, `order_tax_rate`, `order_tax`, `order_discount`, `shipping_cost`, `grand_total`, `paid_amount`, `status`, `payment_status`, `document`, `note`, `created_at`, `updated_at`) VALUES (8,'pr-20230502-092318',30,2,7,10,5200,0,0,198850,0,0,NULL,650,199500,199500,1,2,NULL,NULL,'2023-05-02 06:23:18','2023-05-02 06:40:54'),(9,'pr-20230502-094845',30,2,7,1,20,0,0,27300,0,0,NULL,200,27500,27500,1,2,NULL,NULL,'2023-05-02 06:48:45','2023-05-02 06:49:06'),(10,'pr-20230502-100239',1,2,5,6,374,0,0,101592,0,0,NULL,1000,102592,102592,1,2,NULL,NULL,'2023-05-02 07:02:39','2023-05-02 07:02:49'),(11,'pr-20230502-100536',1,2,10,3,53,0,0,208300,0,0,NULL,700,209000,209000,1,2,NULL,NULL,'2023-05-02 07:05:36','2023-05-02 07:36:45'),(12,'pr-20230502-101607',1,2,8,6,93,0,0,54350,0,0,NULL,20,54370,54370,1,2,NULL,NULL,'2023-05-02 07:16:07','2023-05-02 07:36:58'),(13,'pr-20230502-104040',1,2,8,8,227,0,0,109540,0,0,NULL,NULL,109540,109540,1,2,NULL,NULL,'2023-05-02 07:40:40','2023-05-02 07:40:49'),(14,'pr-20230502-112146',1,2,4,6,255,0,0,221200,0,0,NULL,NULL,221200,221200,1,2,NULL,NULL,'2023-05-02 08:21:46','2023-05-02 08:21:56'),(15,'pr-20230502-115956',1,2,9,9,1131,0,0,45468,0,0,0,NULL,45468,0,1,1,NULL,NULL,'2023-05-02 08:59:56','2023-05-02 12:10:32'),(16,'pr-20230502-121833',1,2,11,17,8500,0,0,127340,0,0,NULL,NULL,127340,92000,1,1,NULL,NULL,'2023-05-02 09:18:33','2023-05-02 12:10:07'),(17,'pr-20230503-081753',1,2,12,1,10,0,0,19000,0,0,NULL,NULL,19000,0,1,1,NULL,NULL,'2023-05-03 05:17:53','2023-05-03 05:17:53'),(18,'pr-20230503-090334',32,2,13,1,1,0,0,2700,0,0,NULL,NULL,2700,0,1,1,NULL,NULL,'2023-05-03 06:03:34','2023-05-03 06:03:34'),(19,'pr-20230503-102411',32,2,6,1,60,0,0,6180,0,0,NULL,NULL,6180,6180,1,2,NULL,NULL,'2023-05-03 07:24:11','2023-05-03 07:53:08'),(20,'pr-20230503-112721',32,2,6,19,875,0,0,61812,0,0,NULL,NULL,61812,0,1,1,NULL,NULL,'2023-05-03 08:27:21','2023-05-03 08:27:21');
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotations`
--

DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `biller_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_price` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `order_discount` double DEFAULT NULL,
  `shipping_cost` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `quotation_status` int(11) NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotations`
--

LOCK TABLES `quotations` WRITE;
/*!40000 ALTER TABLE `quotations` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return_purchases`
--

DROP TABLE IF EXISTS `return_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `return_purchases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_cost` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_purchases`
--

LOCK TABLES `return_purchases` WRITE;
/*!40000 ALTER TABLE `return_purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `return_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `returns`
--

DROP TABLE IF EXISTS `returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `returns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `cash_register_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `biller_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_price` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `returns`
--

LOCK TABLES `returns` WRITE;
/*!40000 ALTER TABLE `returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES (4,1),(4,2),(4,4),(4,6),(5,1),(5,2),(5,6),(6,1),(6,2),(6,4),(6,6),(7,1),(7,2),(7,4),(7,6),(8,1),(8,2),(8,4),(8,6),(9,1),(9,2),(9,4),(9,6),(10,1),(10,2),(10,6),(11,1),(11,2),(11,6),(12,1),(12,2),(12,4),(12,6),(13,1),(13,2),(13,4),(13,6),(14,1),(14,2),(14,6),(15,1),(15,2),(15,6),(16,1),(16,2),(17,1),(17,2),(18,1),(18,2),(19,1),(19,2),(20,1),(20,2),(20,4),(21,1),(21,2),(21,4),(22,1),(22,2),(22,4),(23,1),(23,2),(24,1),(24,2),(24,4),(25,1),(25,2),(25,4),(26,1),(26,2),(27,1),(27,2),(28,1),(28,2),(28,4),(29,1),(29,2),(29,4),(30,1),(30,2),(31,1),(31,2),(32,1),(32,2),(32,6),(33,1),(33,2),(33,6),(34,1),(34,2),(34,6),(35,1),(35,2),(35,6),(36,1),(36,2),(37,1),(37,2),(38,1),(38,2),(39,1),(39,2),(40,1),(40,2),(41,1),(41,2),(42,1),(42,2),(43,1),(43,2),(44,1),(44,2),(45,1),(45,2),(46,1),(46,2),(47,1),(47,2),(48,1),(48,2),(49,1),(49,2),(50,1),(50,2),(51,1),(51,2),(52,1),(52,2),(53,1),(53,2),(54,1),(54,2),(55,1),(55,2),(55,4),(55,6),(56,1),(56,2),(56,4),(56,6),(57,1),(57,2),(57,4),(57,6),(58,1),(58,2),(58,6),(59,1),(59,2),(60,1),(60,2),(61,1),(61,2),(62,1),(62,2),(63,1),(63,2),(63,4),(64,1),(64,2),(64,4),(65,1),(65,2),(66,1),(66,2),(67,1),(67,2),(68,1),(68,2),(69,1),(69,2),(70,1),(70,2),(71,1),(71,2),(72,1),(72,2),(73,1),(73,2),(74,1),(74,2),(75,1),(75,2),(76,1),(76,2),(77,1),(77,2),(78,1),(78,2),(79,1),(79,2),(80,1),(80,2),(81,1),(81,2),(82,1),(82,2),(83,1),(83,2),(84,1),(84,2),(85,1),(85,2),(86,1),(86,2),(87,1),(87,2),(88,1),(88,2),(89,1),(89,2),(90,1),(90,2),(91,1),(91,2),(92,1),(92,2),(93,1),(93,2),(94,1),(94,2),(95,1),(95,2),(96,1),(96,2),(97,1),(97,2),(98,1),(98,2),(99,1),(99,2),(100,1),(100,2),(101,1),(101,2),(102,1),(102,2),(103,1),(103,2),(104,1),(104,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `name`, `description`, `guard_name`, `is_active`, `created_at`, `updated_at`) VALUES (1,'Admin','admin can access all data...','web',1,'2018-06-01 23:46:44','2018-06-02 23:13:05'),(2,'Owner','Owner of shop...','web',1,'2018-10-22 02:38:13','2018-10-22 02:38:13'),(4,'staff','staff has specific acess...','web',1,'2018-06-02 00:05:27','2018-06-02 00:05:27'),(5,'Customer',NULL,'web',1,'2020-11-05 06:43:16','2020-11-15 00:24:15'),(6,'كاشير',NULL,'web',1,'2021-08-15 07:42:55','2021-08-15 07:42:55');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `cash_register_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `biller_id` int(11) DEFAULT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_price` double NOT NULL,
  `grand_total` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `order_discount` double DEFAULT NULL,
  `coupon_id` int(11) DEFAULT NULL,
  `coupon_discount` double DEFAULT NULL,
  `shipping_cost` double DEFAULT NULL,
  `sale_status` int(11) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double DEFAULT NULL,
  `sale_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` (`id`, `reference_no`, `user_id`, `cash_register_id`, `customer_id`, `warehouse_id`, `biller_id`, `item`, `total_qty`, `total_discount`, `total_tax`, `total_price`, `grand_total`, `order_tax_rate`, `order_tax`, `order_discount`, `coupon_id`, `coupon_discount`, `shipping_cost`, `sale_status`, `payment_status`, `document`, `paid_amount`, `sale_note`, `staff_note`, `created_at`, `updated_at`) VALUES (5,'sr-20230430-115122',1,9,3,2,1,1,5,0,0,600,600,0,0,NULL,NULL,NULL,NULL,1,4,NULL,600,NULL,NULL,'2023-04-30 08:51:22','2023-04-30 08:51:22');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_counts`
--

DROP TABLE IF EXISTS `stock_counts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_counts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `category_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `initial_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_adjusted` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_counts`
--

LOCK TABLES `stock_counts` WRITE;
/*!40000 ALTER TABLE `stock_counts` DISABLE KEYS */;
INSERT INTO `stock_counts` (`id`, `reference_no`, `warehouse_id`, `category_id`, `brand_id`, `user_id`, `type`, `initial_file`, `final_file`, `note`, `is_adjusted`, `created_at`, `updated_at`) VALUES (1,'scr-20190228-124939',2,NULL,NULL,1,'full','20190228-124939.csv',NULL,NULL,0,'2019-02-28 06:49:39','2019-02-28 06:49:39');
/*!40000 ALTER TABLE `stock_counts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vat_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` (`id`, `name`, `image`, `company_name`, `vat_number`, `email`, `phone_number`, `address`, `city`, `state`, `postal_code`, `country`, `is_active`, `created_at`, `updated_at`) VALUES (1,'مورد تجريبي',NULL,'مورد تجريبي',NULL,'s@s.com','.','.','..','.','.','.',0,'2023-03-19 11:03:23','2023-04-30 08:19:08'),(2,'مورد تجريبي 2',NULL,'..','0','SDFsd@sdf.com','23123123','...','...','..','5656','...',0,'2023-04-28 12:17:19','2023-04-30 08:18:59'),(3,'محمد جمال',NULL,'الجمهورية',NULL,'aaaa@aaa','01143218446','القاهره','القاهره',NULL,NULL,NULL,0,'2023-04-30 07:45:30','2023-04-30 08:19:17'),(4,'ياسر الرفاعي',NULL,'شركة الحرية للاستيراد والتصدير',NULL,'yaser@yeser.com','01008532687','ابيس الاسكندريه','الاسكندريه','---','656','...',1,'2023-04-30 08:22:56','2023-04-30 08:22:56'),(5,'الباز',NULL,'الباز',NULL,'mohamed@YAHOO.COM','01001063442','المنصورة','المنصورة','jkkk','222','المنصورة',1,'2023-04-30 09:43:23','2023-04-30 09:43:23'),(6,'بست تولز',NULL,'best tools',NULL,'besttolls@yahoo.com','01123547788','القاهره','القاهره','لل','111','القاهره',1,'2023-04-30 09:46:06','2023-04-30 09:46:06'),(7,'الاقتصاديه',NULL,'الاقتصاديه',NULL,'most@yahoo.com','01487786373783','قليوب','قليوب','الب','12','قليوب',1,'2023-04-30 09:49:30','2023-04-30 09:49:30'),(8,'عطالله',NULL,'عطالله',NULL,'atallah@yahoo.com','01285227510','atallah@yahoo.com','جسر السويس','00',NULL,'القاهره',1,'2023-04-30 09:55:14','2023-04-30 09:55:14'),(9,'رشوان خربوش',NULL,'رشوان خربوش',NULL,'rashwan@yahoo.com','01010681750','القاهره','القاهره','الا',NULL,'القاهره',1,'2023-04-30 09:58:30','2023-04-30 09:58:30'),(10,'حنين منير حنين',NULL,'القاهرة لادوات اللحام ( حنين منير حنين )',NULL,'hunein65@hotmail.com','01023553748','القاهره شارع المهدى ناصية الجمهورية  امام البنك المركزى المصرى الجديد','القاهره','يي',NULL,'القاهره',1,'2023-04-30 10:02:30','2023-04-30 10:03:30'),(11,'سالم',NULL,'الحجاز',NULL,'salem@hotmail.com','01101569906','القاهره','البراجيل','ى',NULL,'القاهره',1,'2023-04-30 10:06:17','2023-04-30 10:06:17'),(12,'احمد عطية رابيد',NULL,'رابيد',NULL,'ahmed@hotmail.com','01115686858565','العاشر من رمضان','العاشر','0',NULL,'بلبيس',1,'2023-04-30 10:08:51','2023-04-30 10:08:51'),(13,'المهندس مجدى الفقى',NULL,'الاصدقاء',NULL,'magdy@hotmail.com','01228918599','العاشر من رمضان','العاشر','اس',NULL,NULL,1,'2023-04-30 10:11:02','2023-04-30 10:11:02');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxes`
--

DROP TABLE IF EXISTS `taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` double NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxes`
--

LOCK TABLES `taxes` WRITE;
/*!40000 ALTER TABLE `taxes` DISABLE KEYS */;
INSERT INTO `taxes` (`id`, `name`, `rate`, `is_active`, `created_at`, `updated_at`) VALUES (1,'vat@10',10,0,'2018-05-12 09:58:30','2021-11-26 21:35:12'),(2,'vat@15',15,0,'2018-05-12 09:58:43','2021-11-26 21:35:08'),(3,'test',6,0,'2018-05-27 23:32:54','2018-05-27 23:34:44'),(4,'vat 20',20,0,'2018-09-01 00:58:57','2021-11-26 21:34:56'),(5,'القيمة المضافة',14,0,'2021-08-13 15:11:23','2021-11-26 21:35:02');
/*!40000 ALTER TABLE `taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfers`
--

DROP TABLE IF EXISTS `transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transfers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_cost` double NOT NULL,
  `shipping_cost` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfers`
--

LOCK TABLES `transfers` WRITE;
/*!40000 ALTER TABLE `transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `units` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `unit_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_unit` int(11) DEFAULT NULL,
  `operator` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operation_value` double DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` (`id`, `unit_code`, `unit_name`, `base_unit`, `operator`, `operation_value`, `is_active`, `created_at`, `updated_at`) VALUES (1,'pc','قطعه',NULL,'*',1,1,'2018-05-12 02:27:46','2021-08-18 19:53:50'),(2,'علبة 12','علبة 12',1,'*',12,1,'2018-05-12 09:57:05','2018-05-12 09:57:05'),(3,'علبة 24','علبة 24',1,'*',24,1,'2018-05-12 09:57:45','2020-03-11 10:36:59'),(4,'متر','meter',NULL,'*',1,1,'2018-05-12 09:58:07','2023-04-30 09:19:32'),(6,'test','test',NULL,'*',1,0,'2018-05-27 23:20:20','2018-05-27 23:20:25'),(7,'kg','kilogram',NULL,'*',1,1,'2018-06-25 00:49:26','2018-06-25 00:49:26'),(8,'20','ni33',8,'*',1,0,'2018-07-31 22:35:51','2018-07-31 22:40:54'),(9,'gm','gram',7,'/',1000,1,'2018-09-01 00:06:28','2018-09-01 00:06:28'),(10,'gz','goz',NULL,'*',1,0,'2018-11-29 03:40:29','2019-03-02 11:53:29'),(12,'كرتونة','كرتونة',NULL,'*',1,1,'2023-04-30 09:20:31','2023-04-30 09:21:02'),(13,'حجر','حجر',12,NULL,NULL,1,'2023-04-30 09:22:22','2023-04-30 09:22:22'),(14,'15','لفة',NULL,'*',1,1,'2023-04-30 11:37:21','2023-04-30 11:37:21');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `biller_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `phone`, `company_name`, `role_id`, `biller_id`, `warehouse_id`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES (1,'admin','admin@admin.com','$2y$10$MhnXkcIXaFJp3eLxV/aCbO8LWPXt/AAFvCTIqcpkbiFPr1FUbSpUW','48f7SuRZ06SwIaLS4QNqz0w0Z6AJQgDK3AzKu7et6crKFjPze8ikKuWRABRd','12112','lioncoders',1,NULL,NULL,1,0,'2018-06-02 03:24:15','2023-01-26 12:10:25'),(30,'mody','ahmedmahmoud8493@yahoo.com','$2y$10$Hg0eiVrntKpHXtlt1ogCR.9LFXLMBof59D7g84ATjAkVI.6g6vlVG',NULL,'01008532687','القا ئد للتةريدات العموميه',2,NULL,NULL,1,0,'2023-03-28 10:08:42','2023-04-30 10:18:23'),(31,'ahmed','ahmed@ahmed.com','$2y$10$qmzfJgG2lQnhG.jh.21vGO89.h0ActJqf0s.tiO/YYgd0yWmNeytK',NULL,'01008532687',NULL,1,NULL,NULL,1,0,'2023-04-28 12:30:13','2023-04-30 10:13:50'),(32,'محمد غنيم','mohamed@hotmail.com','$2y$10$WCrWftRObtwvivy98OPZUOBO7TK4ZptwITfkPaJf8.LAKAyZeEh3W',NULL,'01015563510',NULL,4,1,2,1,0,'2023-04-30 10:16:12','2023-04-30 10:16:12');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `variants`
--

DROP TABLE IF EXISTS `variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variants` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variants`
--

LOCK TABLES `variants` WRITE;
/*!40000 ALTER TABLE `variants` DISABLE KEYS */;
INSERT INTO `variants` (`id`, `name`, `created_at`, `updated_at`) VALUES (2,'Medium','2019-11-21 07:03:04','2019-11-24 08:43:52'),(3,'Small','2019-11-21 07:03:04','2019-11-24 08:43:52'),(5,'Large','2019-11-24 06:07:20','2019-11-24 08:44:56'),(9,'a','2020-05-18 16:44:14','2020-05-18 16:44:14'),(11,'b','2020-05-18 16:53:49','2020-05-18 16:53:49'),(12,'variant 1','2020-09-27 06:08:27','2020-09-27 06:08:27'),(13,'variant 2','2020-09-27 06:08:27','2020-09-27 06:08:27'),(15,'S','2020-11-16 06:09:33','2020-11-16 06:09:33'),(16,'M','2020-11-16 06:09:33','2020-11-16 06:09:33'),(17,'L','2020-11-16 06:09:33','2020-11-16 06:09:33'),(18,' ','2021-09-01 02:57:11','2021-09-01 02:57:11');
/*!40000 ALTER TABLE `variants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warehouses`
--

DROP TABLE IF EXISTS `warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouses`
--

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
INSERT INTO `warehouses` (`id`, `name`, `phone`, `email`, `address`, `is_active`, `created_at`, `updated_at`) VALUES (1,'warehouse 1','2312121','war1@lion.com','khatungonj, chittagong',0,'2018-05-12 07:51:44','2023-04-28 12:02:00'),(2,'القائد فرع العاشر','01008532687','info@pos.com','العاشر من رمضان',1,'2018-05-12 08:09:03','2023-04-28 12:02:23'),(3,'test',NULL,NULL,'dqwdeqw',0,'2018-05-30 00:14:23','2023-04-28 12:02:07'),(6,'gudam','2121','','gazipur',0,'2018-08-31 22:53:26','2023-04-28 12:01:52'),(7,'القائد فرع بلبيس','0365656','sad@sad.com','بلبيس',1,'2023-04-28 12:02:53','2023-04-28 12:02:53');
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mohamedebrahem_pos'
--

--
-- Dumping routines for database 'mohamedebrahem_pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-03 17:02:50
